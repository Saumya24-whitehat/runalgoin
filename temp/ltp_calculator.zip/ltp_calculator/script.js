function formatIndianNumber(num) {
    if (num === undefined || num === null || isNaN(num)) {
        return '';
    }
    return Number(num).toLocaleString('en-IN');
}

async function fetchData() {
    try {
        const response = await fetch('getOptionChainSupportResistance.json');
        const jsonData = await response.json();
        return jsonData.option_chain;
    } catch (error) {
        console.error('Error fetching data:', error);
        return null;
    }
}

async function generateTable() {
    const optionChain = await fetchData();
    if (!optionChain) return;

    const data = optionChain.data;
    if (!data || data.length === 0) {
        console.error('No option chain data available');
        return;
    }
    const strikeCountInput = document.getElementById('strike-count');
    const strikeCount = parseInt(strikeCountInput.value);
    const lotSizeInput = document.getElementById('lot-size');
    const lotSize = parseInt(lotSizeInput.value);
    const lotsBtn = document.getElementById('lots-btn');
    const quantityBtn = document.getElementById('quantity-btn');
    const displayAsLots = lotsBtn.classList.contains('active');

    const highlightCountInput = document.getElementById('highlight-count');
    const highlightCount = parseInt(highlightCountInput.value);

    const highlightPercentageInput = document.getElementById('highlight-percentage');
    const highlightPercentage = parseFloat(highlightPercentageInput.value);

    const spotPrice = data[0].underlying_spot_price;
    const spotPriceIndex = data.findIndex(row => parseFloat(row.strike_price) > spotPrice);
    const startIndex = Math.max(0, spotPriceIndex - strikeCount);
    const endIndex = Math.min(data.length, spotPriceIndex + strikeCount);
    const filteredData = data.slice(startIndex, endIndex);

    let totalCallOI = 0;
    let totalCallCOI = 0;
    let totalCallVolume = 0;
    let totalPutOI = 0;
    let totalPutCOI = 0;
    let totalPutVolume = 0;

    const getTopNValues = (data, key, n) => {
        const values = data.map(row => key(row)).sort((a, b) => b - a);
        return values.slice(0, n);
    };

    const topCallVolumes = getTopNValues(data, row => row.call_options.market_data.volume, highlightCount);
    const topPutVolumes = getTopNValues(data, row => row.put_options.market_data.volume, highlightCount);
    const topCallOIs = getTopNValues(data, row => row.call_options.market_data.oi, highlightCount);
    const topPutOIs = getTopNValues(data, row => row.put_options.market_data.oi, highlightCount);
    const topCallCOIs = getTopNValues(data, row => row.call_options.market_data.oi - row.call_options.market_data.prev_oi, highlightCount);
    const topPutCOIs = getTopNValues(data, row => row.put_options.market_data.oi - row.put_options.market_data.prev_oi, highlightCount);


    data.forEach(row => {
        totalCallOI += row.call_options.market_data.oi;
        totalCallCOI += (row.call_options.market_data.oi - row.call_options.market_data.prev_oi);
        totalCallVolume += row.call_options.market_data.volume;
        totalPutOI += row.put_options.market_data.oi;
        totalPutCOI += (row.put_options.market_data.oi - row.put_options.market_data.prev_oi);
        totalPutVolume += row.put_options.market_data.volume;
    });
    const tableContainer = document.querySelector('.table-container');
    let table = '<table>';
    table += `<thead>
        <tr >
            <th colspan="6" style="background-color: #993333; color: white; text-align: center;">CALL | Resistance: 26200</th>
            <th style="background-color: #333366; color: white;">IDV: -</th>
            <th colspan="6" style="background-color: #336633; color: white; text-align: center;">PUT | Support: 26000</th>
        </tr>
        <tr style="background-color: #2a2a2a;">
            <th>DELTA IV</th>
            <th>COI</th>
            <th>OI</th>
            <th>VOLUME</th>
            <th>LTP/CLTP</th>
            <th>S LEVEL/LTP LEV.</th>
            <th>Strike Pcr. OI(COI)</th>
            <th>S LEVEL/LTP LEV.</th>
            <th>LTP/CLTP</th>
            <th>VOLUME</th>
            <th>OI</th>
            <th>COI %</th>
            <th>DELTA IV</th>
        </tr>
    </thead>`;
    table += '<tbody>';
    
    data.sort((a, b) => parseFloat(a.strike_price) - parseFloat(b.strike_price));

    let spotRowInserted = false;
    filteredData.forEach(row => {
        const strikePrice = parseFloat(row.strike_price);

        if (!spotRowInserted && strikePrice > spotPrice) {
            table += `<tr class="spot-price-row">
                <td colspan="13">
                    <div class="spot-price-container">
                        <div class="spot-price-left">Ol: 83.34% Vol: 98.14%</div>
                        <div class="spot-price-center">SPOT: ${spotPrice} (-37.55)</div>
                        <div class="spot-price-right">Vol: 64.4% Ol: 50.41%</div>
                    </div>
                </td>
            </tr>`;
            spotRowInserted = true;
        }

        let callClass = '';
        if (strikePrice < spotPrice) {
            callClass = 'call-itm';
        } else {
            callClass = 'call-otm';
        }

        let putClass = '';
        if (strikePrice > spotPrice) {
            putClass = 'put-itm';
        } else {
            putClass = 'put-otm';
        }

        const callVolumePercent = topCallVolumes[0] > 0 ? (row.call_options.market_data.volume / topCallVolumes[0]) * 100 : 0;
        const putVolumePercent = topPutVolumes[0] > 0 ? (row.put_options.market_data.volume / topPutVolumes[0]) * 100 : 0;
        const callOIPercent = topCallOIs[0] > 0 ? (row.call_options.market_data.oi / topCallOIs[0]) * 100 : 0;
        const putOIPercent = topPutOIs[0] > 0 ? (row.put_options.market_data.oi / topPutOIs[0]) * 100 : 0;
        const callCOIPercent = topCallCOIs[0] > 0 ? ((row.call_options.market_data.oi - row.call_options.market_data.prev_oi) / topCallCOIs[0]) * 100 : 0;
        const putCOIPercent = topPutCOIs[0] > 0 ? ((row.put_options.market_data.oi - row.put_options.market_data.prev_oi) / topPutCOIs[0]) * 100 : 0;


        const getHighlightClass = (value, topValues, isPut) => {
            const index = topValues.indexOf(value);
            if (index === -1) return '';

            if (index === 0) {
                return isPut ? 'max-volume-put' : 'max-volume';
            }

            if (value >= topValues[0] * (highlightPercentage / 100)) {
                if (index === 1) return 'second-max-volume';
                if (index === 2) return 'third-max-volume';
                if (index === 3) return 'fourth-max-volume';
            }

            return '';
        };

        let callVolumeClass = getHighlightClass(row.call_options.market_data.volume, topCallVolumes, false);
        let putVolumeClass = getHighlightClass(row.put_options.market_data.volume, topPutVolumes, true);
        let callOIClass = getHighlightClass(row.call_options.market_data.oi, topCallOIs, false);
        let putOIClass = getHighlightClass(row.put_options.market_data.oi, topPutOIs, true);
        let callCOIClass = getHighlightClass(row.call_options.market_data.oi - row.call_options.market_data.prev_oi, topCallCOIs, false);
        let putCOIClass = getHighlightClass(row.put_options.market_data.oi - row.put_options.market_data.prev_oi, topPutCOIs, true);

        let callCOI = row.call_options.market_data.oi - row.call_options.market_data.prev_oi;
        let putCOI = row.put_options.market_data.oi - row.put_options.market_data.prev_oi;
        const pcrOfCoi = callCOI !== 0 ? (putCOI / callCOI).toFixed(2) : '-';

        let callVolume = row.call_options.market_data.volume;
        let putVolume = row.put_options.market_data.volume;
        let callOI = row.call_options.market_data.oi;
        let putOI = row.put_options.market_data.oi;

        if (displayAsLots) {
            callCOI = Math.round(callCOI / lotSize);
            putCOI = Math.round(putCOI / lotSize);
            callVolume = Math.round(callVolume / lotSize);
            putVolume = Math.round(putVolume / lotSize);
            callOI = Math.round(callOI / lotSize);
            putOI = Math.round(putOI / lotSize);
        }

        table += `<tr>
            <td class="${callClass} delta-iv-cell"><div>${row.call_options.option_greeks.delta}</div><div>${row.call_options.option_greeks.iv.toFixed(2)}</div></td>
            <td class="${callClass} red ${callCOIClass}"><div>${formatIndianNumber(callCOI)}</div><div class="volume-percent">${callCOIPercent.toFixed(2)}%</div></td>
            <td class="${callClass} ${callOIClass}"><div>${formatIndianNumber(callOI)}</div><div class="volume-percent">${callOIPercent.toFixed(2)}%</div></td>
            <td class="${callClass} volume-cell ${callVolumeClass}"><div>${formatIndianNumber(callVolume)}</div><div class="volume-percent">${callVolumePercent.toFixed(2)}%</div></td>
            <td class="${callClass}">${row.call_options.market_data.ltp}</td>
            <td class="${callClass} s-level-ltp-lev">-</td>
            <td class=\"highlight\">${row.strike_price}<br><small>${row.pcr ? row.pcr.toFixed(2) : '-'} (${pcrOfCoi})</small></td>
            <td class="${putClass} s-level-ltp-lev">-</td>
            <td class="${putClass}">${row.put_options.market_data.ltp}</td>
            <td class="${putClass} volume-cell ${putVolumeClass}"><div>${formatIndianNumber(putVolume)}</div><div class="volume-percent">${putVolumePercent.toFixed(2)}%</div></td>
            <td class="${putClass} ${putOIClass}"><div>${formatIndianNumber(putOI)}</div><div class="volume-percent">${putOIPercent.toFixed(2)}%</div></td>
            <td class="${putClass} ${putCOIClass}"><div>${formatIndianNumber(putCOI)}</div><div class="volume-percent">${putCOIPercent.toFixed(2)}%</div></td>
            <td class="${putClass} delta-iv-cell"><div>${row.put_options.option_greeks.delta}</div><div>${row.put_options.option_greeks.iv.toFixed(2)}</div></td>
        </tr>`;
    });

    if (!spotRowInserted) { // If spot price is highest
        table += `<tr class="spot-price-row">
            <td colspan="13">
                <div class="spot-price-container">
                    <div class="spot-price-left">Ol: 83.34% Vol: 98.14%</div>
                    <div class="spot-price-center">SPOT: ${spotPrice} (-37.55)</div>
                    <div class="spot-price-right">Vol: 64.4% Ol: 50.41%</div>
                </div>
            </td>
        </tr>`;
    }
    table += '</tbody>';
    table += `<tfoot>
        <tr>
            <td></td>
            <td class="red total-calls-bg">${formatIndianNumber(totalCallCOI)}</td>
            <td class="total-calls-bg">${formatIndianNumber(totalCallOI)}</td>
            <td class="total-calls-bg">${formatIndianNumber(totalCallVolume)}</td>
            <td></td>
            <td></td>
            <td class="highlight">Total</td>
            <td></td>
            <td></td>
            <td class="total-puts-bg">${formatIndianNumber(totalPutVolume)}</td>
            <td class="total-puts-bg">${formatIndianNumber(totalPutOI)}</td>
            <td class="total-puts-bg">${formatIndianNumber(totalPutCOI)}</td>
            <td></td>
        </tr>
    </tfoot>`;
    table += '</table>';
    tableContainer.innerHTML = table;

    const callHeader = document.querySelector('th[colspan="6"]:first-child');
    const putHeader = document.querySelector('th[colspan="6"]:last-child');
    const shiftingModal = document.getElementById('shifting-modal');
    const modalOverlay = document.getElementById('modal-overlay');

    callHeader.addEventListener('click', () => {
        shiftingModal.classList.remove('hidden');
        modalOverlay.classList.remove('hidden');
        populateShiftingModal();
    });

    const strikePriceCells = document.querySelectorAll('.highlight');
    const strikePriceModal = document.getElementById('strike-price-modal');

    strikePriceCells.forEach(cell => {
        cell.addEventListener('click', () => {
            populateStrikePriceModal();
            strikePriceModal.classList.remove('hidden');
            modalOverlay.classList.remove('hidden');
        });
    });

    putHeader.addEventListener('click', () => {
        shiftingModal.classList.remove('hidden');
        modalOverlay.classList.remove('hidden');
        populateShiftingModal();
    });
}



document.addEventListener('DOMContentLoaded', () => {
    generateTable();

    const settingsBtn = document.getElementById('settings-btn');
    const settingsModal = document.getElementById('settings-modal');
    const closeModalBtn = document.querySelector('.close-btn');
    const applySettingsBtn = document.getElementById('apply-settings-btn');
    const modalOverlay = document.getElementById('modal-overlay');
    const shiftingModal = document.getElementById('shifting-modal');
    const strikePriceModal = document.getElementById('strike-price-modal');
    const closeShiftingModalBtn = shiftingModal.querySelector('.close-btn');
    const closeStrikePriceModalBtn = strikePriceModal.querySelector('.close-btn');

    settingsBtn.addEventListener('click', () => {
        settingsModal.classList.remove('hidden');
        modalOverlay.classList.remove('hidden');
    });

    modalOverlay.addEventListener('click', () => {
        settingsModal.classList.add('hidden');
        shiftingModal.classList.add('hidden');
        strikePriceModal.classList.add('hidden');
        modalOverlay.classList.add('hidden');
    });

    if (strikePriceModal) {
        const tabButtons = strikePriceModal.querySelectorAll('.tab-btn');
        const tabContents = strikePriceModal.querySelectorAll('.tab-content');
        const copyButtons = strikePriceModal.querySelectorAll('.copy-btn');
        const modeButtons = strikePriceModal.querySelectorAll('.mode-btn');

        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const tabName = button.getAttribute('data-tab');

                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));

                button.classList.add('active');
                document.getElementById(tabName).classList.add('active');
            });
        });

        copyButtons.forEach(button => {
            button.addEventListener('click', () => {
                const textElement = button.previousElementSibling;
                if (textElement) {
                    const text = textElement.textContent || '';

                    navigator.clipboard.writeText(text).then(() => {
                        button.textContent = '✓';
                        button.style.color = '#27ae60';

                        setTimeout(() => {
                            button.textContent = '📋';
                            button.style.color = '';
                        }, 1000);
                    }).catch(err => {
                        console.error('Failed to copy:', err);
                        alert('Copy failed! Text: ' + text);
                    });
                }
            });
        });

        modeButtons.forEach(button => {
            button.addEventListener('click', () => {
                const parentGroup = button.closest('.button-group');
                if (parentGroup) {
                    const groupButtons = parentGroup.querySelectorAll('.mode-btn');
                    groupButtons.forEach(btn => btn.classList.remove('active'));
                }
                button.classList.add('active');
            });
        });
    }

    closeStrikePriceModalBtn.addEventListener('click', () => {
        strikePriceModal.classList.add('hidden');
        modalOverlay.classList.add('hidden');
    });

    const lotsBtn = document.getElementById('lots-btn');
    const quantityBtn = document.getElementById('quantity-btn');

    lotsBtn.addEventListener('click', () => {
        lotsBtn.classList.add('active');
        quantityBtn.classList.remove('active');
    });

    quantityBtn.addEventListener('click', () => {
        quantityBtn.classList.add('active');
        lotsBtn.classList.remove('active');
    });

    applySettingsBtn.addEventListener('click', () => {
        generateTable();
        settingsModal.classList.add('hidden');
        modalOverlay.classList.add('hidden');
    });
});

function populateShiftingModal() {
    const modalBody = document.querySelector('#shifting-modal tbody');
    modalBody.innerHTML = `
        <tr>
            <td>09:32:11 AM</td>
            <td>SFT : 26200 -> 26100</td>
            <td>-</td>
        </tr>
        <tr>
            <td>09:28:38 AM</td>
            <td>-</td>
            <td>SFT : 26000 -> 26100</td>
        </tr>
        <tr>
            <td>09:28:18 AM</td>
            <td>-</td>
            <td>SFT : 26100 -> 26000</td>
        </tr>
        <tr>
            <td>09:28:06 AM</td>
            <td>-</td>
            <td>SFT : 26000 -> 26100</td>
        </tr>
    `;
}

function populateStrikePriceModal() {
    document.getElementById('spot-content').innerHTML = `
        <div class="info-row">
            <div class="info-box">
                <span>Reversal For : 25,550</span>
                <button class="copy-btn">📋</button>
            </div>
            <div class="info-box">
                <span>Spot Price : 26,042.85</span>
                <button class="copy-btn">📋</button>
            </div>
        </div>

        <div class="data-grid">
            <div class="data-column resistance">
                <div class="header">Resistance</div>
                <div class="status">Status : Breaker Inactive</div>
                <div class="data-item">
                    <span>9:30 AM : 25,610.22</span>
                    <button class="copy-btn">📋</button>
                </div>
                <div class="data-item">
                    <span>Average : 25,619.31</span>
                    <button class="copy-btn">📋</button>
                </div>
                <div class="data-item">
                    <span>Current : 25,595.23</span>
                    <button class="copy-btn">📋</button>
                </div>
            </div>

            <div class="data-column support">
                <div class="header">Support</div>
                <div class="status">Status : Breaker Active</div>
                <div class="data-item">
                    <span>9:30 AM : 25,565.34</span>
                    <button class="copy-btn">📋</button>
                </div>
                <div class="data-item">
                    <span>Average : 25,518.9</span>
                    <button class="copy-btn">📋</button>
                </div>
                <div class="data-item">
                    <span>Current : 25,545.2</span>
                    <button class="copy-btn">📋</button>
                </div>
            </div>
        </div>
    `;

    document.getElementById('future-content').innerHTML = `
        <div class="info-row">
            <div class="info-box">
                <span>Reversal For : 25,550</span>
                <button class="copy-btn">📋</button>
            </div>
            <div class="info-box">
                <span>Future 1 Price : 26,056.6</span>
                <button class="copy-btn">📋</button>
            </div>
        </div>

        <div class="data-grid">
            <div class="data-column resistance">
                <div class="header">Resistance</div>
                <div class="data-item">
                    <span>9:30 AM : 25,616.42</span>
                    <button class="copy-btn">📋</button>
                </div>
                <div class="data-item">
                    <span>Average : 25,633.06</span>
                    <button class="copy-btn">📋</button>
                </div>
                <div class="data-item">
                    <span>Current : 25,608.98</span>
                    <button class="copy-btn">📋</button>
                </div>
            </div>

            <div class="data-column support">
                <div class="header">Support</div>
                <div class="data-item">
                    <span>9:30 AM : 25,571.54</span>
                    <button class="copy-btn">📋</button>
                </div>
                <div class="data-item">
                    <span>Average : 25,532.65</span>
                    <button class="copy-btn">📋</button>
                </div>
                <div class="data-item">
                    <span>Current : 25,558.95</span>
                    <button class="copy-btn">📋</button>
                </div>
            </div>
        </div>
    `;

    document.getElementById('ltp-content').innerHTML = `
        <div class="info-box single">
            <span>Option : 25,550</span>
        </div>

        <div class="info-row">
            <div class="info-box">
                <span>Spot Price : 26,042.85</span>
                <button class="copy-btn">📋</button>
            </div>
            <div class="info-box">
                <span>Future 1 Price : 26,056.6</span>
                <button class="copy-btn">📋</button>
            </div>
        </div>

        <div class="data-grid">
            <div class="data-column call">
                <div class="header">CALL</div>
                <div class="data-item">
                    <span>IV : 0.01</span>
                    <button class="copy-btn">📋</button>
                </div>
                <div class="data-item">
                    <span>Ltp : 510.15</span>
                    <button class="copy-btn">📋</button>
                </div>
            </div>

            <div class="data-column put">
                <div class="header">PUT</div>
                <div class="data-item">
                    <span>IV : 9.8</span>
                    <button class="copy-btn">📋</button>
                </div>
                <div class="data-item">
                    <span>Ltp : 2.4</span>
                    <button class="copy-btn">📋</button>
                </div>
            </div>
        </div>

        <div class="input-section">
            <input type="text" placeholder="Enter Target Price" class="target-input">
            <div class="button-group">
                <button class="mode-btn">Spot</button>
                <button class="mode-btn active">CE</button>
                <button class="mode-btn">PE</button>
            </div>
        </div>
    `;
}