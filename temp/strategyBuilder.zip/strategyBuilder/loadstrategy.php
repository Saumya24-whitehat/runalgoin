<?php
    session_start();
    $strategyFiles = './strategy/' . $_SESSION['user'] . '.txt';

    if (!file_exists($strategyFiles)) {
        // Create the file if it doesn't exist
        file_put_contents($strategyFiles, '[]');
    }

    $strategyData=json_decode(fread(fopen($strategyFiles,'r'),filesize($strategyFiles)));

    echo json_encode($strategyData);

    

    // print_r($_POST);

?>