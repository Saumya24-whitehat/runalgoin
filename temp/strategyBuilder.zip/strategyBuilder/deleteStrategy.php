<?php
    session_start();
    $strategyFiles = './strategy/' . $_SESSION['user'] . '.txt';

    if (!file_exists($strategyFiles)) {
        // Create the file if it doesn't exist
        file_put_contents($strategyFiles, '[]');
    }

    $strategyData=json_decode(fread(fopen($strategyFiles,'r'),filesize($strategyFiles)),true);
    $strategyName=$_GET['strategyName'];
    $strategyDataNew=[];
    foreach ($strategyData as $value){
        if($value['strategyName']!=$strategyName){
            $strategyDataNew[]=$value;
        }
    }

    fwrite(fopen($strategyFiles,'w'),json_encode($strategyDataNew));

    echo "Done";

    

    // print_r($_POST);

?>