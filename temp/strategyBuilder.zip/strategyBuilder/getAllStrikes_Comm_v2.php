
<?php
// header('Content-Type: application/json');

// Function to verify token
function verify_token($headers) {
    return true; // Replace with actual token verification logic
}

function toFixed($num, $decimals) {
    return number_format($num, $decimals, '.', '');
}

function convertExpiry($shortDate){

    $parsedDate = DateTime::createFromFormat('dMy', $shortDate);
    $formattedDate = $parsedDate->format('Y-m-d');
    return $formattedDate;
}
// Function to get the latest available time file in a directory
function get_latest_time($expiry_path) {
    try {
        $json_files = array_filter(scandir($expiry_path), function ($file) use ($expiry_path) {
            return is_file($expiry_path . '\\' . $file) && pathinfo($file, PATHINFO_EXTENSION) === 'json';
        });
        if (!empty($json_files)) {
            // Strip `.json` extension and return the latest file
            return max(array_map(function ($file) {
                return pathinfo($file, PATHINFO_FILENAME);
            }, $json_files));
        }
        return null;
    } catch (Exception $e) {
        return null;
    }

}
// Function to get the second latest available time file in a directory
function get_second_latest_time($expiry_path) {
    try {
        $json_files = array_filter(scandir($expiry_path), function ($file) use ($expiry_path) {
            return is_file($expiry_path . '\\' . $file) && pathinfo($file, PATHINFO_EXTENSION) === 'json';
        });

        if (count($json_files) < 2) {
            return null; // Not enough files to find a second latest
        }

        // Extract filenames without extensions
        $time_names = array_map(function ($file) {
            return pathinfo($file, PATHINFO_FILENAME);
        }, $json_files);

        // Sort in descending order
        rsort($time_names, SORT_NATURAL);

        // Return second item
        return $time_names[1];
    } catch (Exception $e) {
        return null;
    }
}


// Function to calculate the ATM (At The Money) strike price
function calculate_atm($underlying_spot_price, $strike_diff) {
    return round($underlying_spot_price / $strike_diff) * $strike_diff;
}

function getClosestStrikePrices($data) {
    // Extract the underlying spot price
    $underlyingSpotPrice = $data['data'][0]['underlying_spot_price'];

    // Extract all strike prices
    $strikePrices = array_map(function ($entry) {
        return $entry['strike_price'];
    }, $data['data']);

    // Sort the strike prices by their absolute difference from the underlying spot price
    usort($strikePrices, function ($a, $b) use ($underlyingSpotPrice) {
        return abs($a - $underlyingSpotPrice) - abs($b - $underlyingSpotPrice);
    });

    // print_r($strikePrices);
    // Return the two closest strike prices
    return array_slice($strikePrices, 0, 2);
}


// Function to get the latest available date
function get_latest_date($symbol_path) {
    try {
        $date_folders = array_filter(scandir($symbol_path), function ($name) use ($symbol_path) {
            return is_dir($symbol_path . '\\' . $name) && $name !== '.' && $name !== '..';
        });
        if (!empty($date_folders)) {
            // Return the latest date folder (assuming folders are named in a sortable format like YYYY-MM-DD)
            return max($date_folders);
        }
        return null;
    } catch (Exception $e) {
        return null;
    }
}
// Function to get expiry dates for a symbol
function get_expiry_dates() {
    $base_dir = "..\\aadata"; // Base directory
    $symbol = isset($_POST['optSymbol']) ? $_POST['optSymbol'] : null;
    
    if (!$symbol) {
        http_response_code(400);
        echo json_encode(["error" => "Symbol is required"]);
        return;
    }

    $symbol_path = $base_dir . '\\' . $symbol;

    if (verify_token(getallheaders())) {
        try {
            // Check if the symbol directory exists
            if (!is_dir($symbol_path)) {
                http_response_code(404);
                echo json_encode(["error" => "Symbol not found"]);
                return;
            }

            // Get the latest available date folder
            $latest_date = get_latest_date($symbol_path);
            if (!$latest_date) {
                http_response_code(404);
                echo json_encode(["error" => "No data available for the symbol"]);
                return;
            }

            // List all expiry dates under the latest date folder
            $date_path = $symbol_path . '\\' . $latest_date;
            $expiry_dates = array_filter(scandir($date_path), function ($name) use ($date_path) {
                return is_dir($date_path . '\\' . $name) && $name !== '.' && $name !== '..';
            });

            return $expiry_dates;
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["error" => $e->getMessage()]);
        }
    } else {
        http_response_code(401);
        echo json_encode(["error" => "Invalid token"]);
    }
}

// Function to get the option chain for a symbol, expiry date, and optionally a date and time
function get_option_chain() {
    $base_dir = "../aadata"; // Base directory
    $symbol = isset($_POST['optSymbol']) ? $_POST['optSymbol'] : null;
    $expiries=get_expiry_dates();
    // print_r($expiries);
    // $expiry_date = isset($_POST['optExpDateYmd']) ? $_POST['optExpDateYmd'] : null;
    $date = isset($_POST['date']) ? $_POST['date'] : null;
    $time = isset($_POST['time']) ? $_POST['time'] : null;

    
    // Strike differences for various symbols
    $strike_differences = [
        "Bankex" => 100,
        "Nifty 50" => 50,
        "Nifty Bank" => 100,
        "Nifty Fin Service" => 50,
        "Nifty Mid Select" => 25,
        "Sensex" => 100
    ];

    if (!$symbol) {
        http_response_code(400);
        echo json_encode(["error" => "Symbol and expiry date are required"]);
        return;
    }


    
    $CHANGESYMBOL=array(
        'Nifty 50'=>'NIFTY',
        'Nifty Bank'=>'BANKNIFTY',
        'Nifty Fin Service'=>'FINNIFTY',
        'Nifty Mid Select'=>'MIDCPNIFTY',
        'Sensex'=>'SENSEX',
        'Banlex'=>'BANKEX'
    );
    
    if(isset($CHANGESYMBOL[$symbol])){
        $symbolGiven=$CHANGESYMBOL[$symbol];
    }else{
        $symbolGiven=$symbol;
    }


    // $expiry_date=convertExpiry($expiry_dateGiven);

    $symbol_path = $base_dir . '\\' . $symbol;

    if (verify_token(getallheaders())) {
        try {
            // Check if the symbol directory exists
            if (!is_dir($symbol_path)) {
                http_response_code(404);
                echo json_encode(["error" => "Symbol not found"]);
                return;
            }

            // If no date is provided, get the latest available date
            if (!$date) {
                $date_folders = array_filter(scandir($symbol_path), function ($folder) use ($symbol_path) {
                    return is_dir($symbol_path . '\\' . $folder) && $folder !== '.' && $folder !== '..';
                });
                if (!empty($date_folders)) {
                    $date = max($date_folders);
                } else {
                    http_response_code(404);
                    echo json_encode(["error" => "No data available for the symbol"]);
                    return;
                }
            }


            $expiryWiseToken=[];
            $ceTokensAll=[];
            $peTokensAll=[];
            $allTokensAll=[];
            $strikesAll=[];
            $idsAll=[];
            $spotKeyAll=[];
            $Get_TokensAll=[];

            foreach($expiries as $expiry_date){
                
                
                $optionChainFinal = [];
                $ceTokens=[];
                $peTokens=[];
                $allTokens=[];
                $data=[];
                $strikes=[];
                $ids=[];
                $spotKey=[];
                $Get_Tokens=[];
                $expiryWiseTokenAll=[];
                $expiry_path = $symbol_path . '\\' . $date . '\\' . $expiry_date;

                // Check if the expiry date folder exists
                if (!is_dir($expiry_path)) {
                    http_response_code(404);
                    echo json_encode(["error" => "Expiry date not found"]);
                    return;
                }

                // If no time is provided, get the latest available time file
                if (!$time) {
                    $time = get_latest_time($expiry_path);
                    if (!$time) {
                        http_response_code(404);
                        echo json_encode(["error" => "No option chain data available for this expiry date"]);
                        return;
                    }
                }

                $time_file_path = $expiry_path . '\\' . $time . '.json';
                // print($time_file_path);
                // Check if the specific time file exists
                if (!file_exists($time_file_path)) {
                    http_response_code(404);
                    echo json_encode(["error" => "Option chain data not found for time $time"]);
                    return;
                }

                // Read the option chain JSON data
                $option_chain_data = json_decode(file_get_contents($time_file_path), true);
                // print_r($option_chain_data);
                if (!isset($option_chain_data['data'][0]['underlying_spot_price'])) {
                    http_response_code(500);
                    echo json_encode(["error" => "Invalid option chain data"]);
                    return;
                }
                
                if (array_key_exists($symbol, $strike_differences)) {
                    $strike_diff = $strike_differences[$symbol];
                }else{
                    $closestStrikes=getClosestStrikePrices($option_chain_data);
                    // print_r($closestStrikes);
                    // $strike_diff = 2;
                    if(count($closestStrikes)==2){
                        $strike_diff =abs($closestStrikes[1]-$closestStrikes[0]);
                    }else{
                        $strike_diff = 10;
                    }
                    
                }

                

                $underlying_price = $option_chain_data['data'][0]['underlying_spot_price'];
                $atm = calculate_atm($underlying_price, $strike_diff);

                
                $symbolLtp = json_decode(file_get_contents('../data/symbolLtp.txt'), true);
                $futureData=[];
                
                // Output the filtered list
                // print_r($filteredSymbols);
                // print_r();
                // Strike differences for various symbols
                $strike_differences = [
                    "Bankex" => 100,
                    "Nifty 50" => 50,
                    "Nifty Bank" => 100,
                    "Nifty Fin Service" => 50,
                    "Nifty Mid Select" => 25,
                    "Sensex" => 100
                ];

                if (array_key_exists($symbol, $strike_differences)) {
                    if($symbol=='Nifty 50'){
                        $symbolFuture='NIFTY';
                    }else if($symbol=='Nifty Bank'){
                        $symbolFuture='BANKNIFTY';
                    }else if($symbol=='Nifty Fin Service'){
                        $symbolFuture='FINNIFTY';
                    }else if($symbol=='Nifty Mid Select'){
                        $symbolFuture='MIDCPNIFTY';
                    }else{
                        $symbolFuture='';
                    }
                }else{
                    $symbolFuture=$symbol;
                }

                // echo $symbolFuture;
                $pattern = "/^" . preg_quote($symbolFuture, '/') . "\d.*FUT$/"; 
                $symbolExpiries=[];
                foreach ($symbolLtp as $key => $value) {
                    // Check if the symbol matches
                    $keyParts = explode(':', $key);
                    // print_r($keyParts);
                    if (isset($keyParts[1]) && preg_match($pattern, $keyParts[1])&& $keyParts[1] != $symbolFuture) { // Check if $keyParts[1] starts with $symbol
                        // Check if it exists in yesterday's data
                        preg_match("/^" . preg_quote($symbolFuture, '/') . "(\d.*)FUT$/", $keyParts[1], $matches);
                        $expiry = $matches[1]; // will give you '30MAY24'
                        $symbolExpiries[]=$expiry;
                        $futureData[]=[$key,$symbolLtp[$key]];
                    }
                }

                // Convert $time to HH:mm:ss format
                $timeFormatted = substr($time, 0, 2) . ":" . substr($time, 2, 2) . ":00";

                // Combine date and time
                $datetime = $date . " " . $timeFormatted;

                // Convert to a DateTime object
                $dateTimeObject = new DateTime($datetime);

                // Format the output as "d-M-Y_H:i:s"
                $output = $dateTimeObject->format('d-M-Y_H:i:s');

                // print_r();
                $strikeCount=5;
                foreach($option_chain_data['data'] as $option){

                    $data[]=$option;
                    $ceTokens[]=$option['call_options']['instrument_key'];
                    $peTokens[]=$option['put_options']['instrument_key'];
                    $allTokens[]=$option['call_options']['instrument_key'];
                    $allTokens[]=$option['put_options']['instrument_key'];

                    $Get_Tokens[]=explode('|',$option['call_options']['instrument_key'])[1].'_NFO';
                    $Get_Tokens[]=explode('|',$option['put_options']['instrument_key'])[1].'_NFO';

                    $strikes[]=toFixed($option['strike_price'],4);
                    $ids[]='OPTIDX_'.$symbolGiven.'_NFO_'.$expiry_date.'_'.$option['strike_price'].'_CE';
                    $ids[]='OPTIDX_'.$symbolGiven.'_NFO_'.$expiry_date.'_'.$option['strike_price'].'_PE';

                    $spotKey=$option['underlying_key'];

                    
                    $ceTokensAll[]=$option['call_options']['instrument_key'];
                    $peTokensAll[]=$option['put_options']['instrument_key'];
                    $allTokensAll[]=$option['call_options']['instrument_key'];
                    $allTokensAll[]=$option['put_options']['instrument_key'];
                    $strikesAll[]=toFixed($option['strike_price'],4);
                    $idsAll[]='OPTIDX_'.$symbolGiven.'_NFO_'.$expiry_date.'_'.$option['strike_price'].'_CE';
                    $idsAll[]='OPTIDX_'.$symbolGiven.'_NFO_'.$expiry_date.'_'.$option['strike_price'].'_PE';
                    $spotKeyAll[]=toFixed($option['strike_price'],4);

                    $Get_TokensAll[]=explode('|',$option['call_options']['instrument_key'])[1].'_NFO';
                    $Get_TokensAll[]=explode('|',$option['put_options']['instrument_key'])[1].'_NFO';
                }
                
                $expiryWiseToken[$expiry_date]=[
                    'strikes'=>$strikes,
                    'ceToken'=>$ceTokens,
                    'peToken'=>$peTokens,
                    'data'=>$data
                ];
                $ltp=$option['underlying_spot_price'];
            }
            // print_r();
            
            $converted = [];

            foreach ($symbolExpiries as $exp) {
                // Append dummy day and year to parse properly
                $date = DateTime::createFromFormat('dYM', '0120' . strtoupper($exp));
                if ($date) {
                    $converted[] = $date->format('Y-m'); // Convert to 'yyyy-mm'
                }
            }
            return [[explode('|',$futureData[0][1]['instrument_token'])[1],explode('|',$futureData[1][1]['instrument_token'])[1],explode('|',$futureData[2][1]['instrument_token'])[1]],$spotKey,join(',',$Get_Tokens),$idsAll,$strikesAll,$ceTokensAll,$peTokensAll,$allTokensAll,$expiry_date,$strike_diff,$expiryWiseToken,[explode(':',$futureData[0][0])[1],explode(':',$futureData[1][0])[1],explode(':',$futureData[2][0])[1]],$converted,$ltp];
            // echo json_encode($optionChainFinal, JSON_PRETTY_PRINT);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["error" => $e->getMessage()]);
        }
    } else {
        http_response_code(401);
        echo json_encode(["error" => "Invalid token"]);
    }
}

// Call the function
$data=get_option_chain();


echo json_encode(array(
  "TotalATMvalues"=> $data[4],
  "Id"=> $data[3],
  "UndId"=> "IDX_-1_NSE",
  "SpotToken_upstox"=> $data[1],
  "Get_Tokens"=> $data[2],
  "CE_Tokens"=> $data[5],
  "PE_Tokens"=> $data[6],
  "All_Tokens"=> $data[7],
  "optExpDateYmd"=> $data[8],
  "lot"=> "75",
  "FutureToken"=> $data[0],
  "FutureNames"=> $data[11],
  "FutureExpiry"=> $data[12],
  "multiplier"=> null,
  'strike_diff'=>$data[9],
  'expiryWise'=>$data[10],
  'ltp'=>$data[13]
));
?>


