<?php

$url = "https://service.upstox.com/jspan-margin-calculator-pub/v1/open/calculate-margin-basket";
$payload = [
    "isMtfMarginRequired" => false,
    "instruments" => $_POST['position']
];

$headers = [
    "accept: application/json, text/plain, */*",
    "accept-language: en-GB,en-US;q=0.9,en;q=0.8",
    "accept-version: v2.1",
    "content-type: application/json",
    "origin: https://upstox.com",
    "priority: u=1, i",
    "referer: https://upstox.com/",
    "sec-ch-ua: \"Not)A;Brand\";v=\"8\", \"Chromium\";v=\"138\", \"Google Chrome\";v=\"138\"",
    "sec-ch-ua-mobile: ?0",
    "sec-ch-ua-platform: \"Windows\"",
    "sec-fetch-dest: empty",
    "sec-fetch-mode: cors",
    "sec-fetch-site: same-site",
    "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
    "x-device-details: platform=WEB|osName=Windows/NT 10.0|osVersion=Chrome/138.0.0.0|appVersion=1|modelName=Chrome|manufacturer=unknown"
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

$response = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Output
header('Content-Type: application/json');
echo json_encode([
    "status" => $httpcode,
    "response" => json_decode($response, true)
], JSON_PRETTY_PRINT);
