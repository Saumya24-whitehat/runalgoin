
const DOM = {
    loader: null,
    symbolSelect: null,
    optionsTable: null,
    positionsTable: null,
    refreshBtn: null,
    chartContainer: null,
    notificationContainer: null,
    // Modified init function to check if elements exist
    init: function() {
        ////console.log('Initializing DOM cache');
        // Get the loading overlay
        this.loader = $('#loader').length ? $('#loader') : $('<div id="loader">Loading...</div>').appendTo('body');
        
        // Get the symbol selector, create if it doesn't exist
        this.symbolSelect = $('#symbol').length ? $('#symbol') : $('.selector select');
        
        // Option table might be referenced differently in the HTML
        const optionsTableSelector = '.options-table table tbody';
        this.optionsTable = $(optionsTableSelector).length ? 
            $(optionsTableSelector) : 
            $('.option-chain-table tbody, table.options-table tbody').first();
        
        ////console.log('Options table found:', this.optionsTable.length > 0);
        
        // Positions table
        this.positionsTable = $('.positions-table tbody').length ? 
            $('.positions-table tbody') : 
            $('table.positions-table tbody, .positions tbody').first();
        
        // Refresh button
        this.refreshBtn = $('.refresh-btn').length ? $('.refresh-btn') : $('.refresh-button, .reload-btn').first();
        
        // Chart container
        this.chartContainer = $('#highcharts-container').length ? 
            $('#highcharts-container') : 
            $('.chart-container').first();
        
        // Create notification container if it doesn't exist
        if (!$('#notification-container').length) {
            this.notificationContainer = $('<div id="notification-container" class="notification-container"></div>').appendTo('body');
        } else {
            this.notificationContainer = $('#notification-container');
        }
        
        ////console.log('DOM elements initialized');
    }
};



window.atm=0

// 5. Add initialization for the position map to the global STATE object
// Update the STATE object to include the positionMap
window.STATE = {
    wsInitialized: false,
    wsReady: false,
    dataLoaded: false,
    positions: [], // Store positions for P/L calculation
    positionMap: {}, // Map option identifiers to position indexes
    instrumentKeys: [],
    shouldReconnect: true,
    reconnectAttempts: 0,
    globalStrikeDiff: null,
    maxOICE: 0,
    maxOIPE: 0,
    maxVolumeCE: 0,
    maxVolumePE: 0,
    pendingUpdates: {},
    updateDebounceTimer: null
};


window.centerStrike={}
// Constants for application
window.CONSTANTS = {
    RECONNECT_INTERVAL: 1000,
    MAX_RECONNECT_INTERVAL: 30000,
    RECONNECT_DECAY: 1.5,
    UPDATE_DEBOUNCE_INTERVAL: 100, // ms to debounce UI updates
    CHART_UPDATE_INTERVAL: 500     // ms between chart updates
};

// Initialize variables needed by various functions
var lastUpdateTime = 0;

function openModal() {
    document.getElementById('portfolioModal').style.display = 'flex';
    document.getElementById('portfolioModalModal').style.display = 'block';
    
}

function closeModal() {
    document.getElementById('portfolioModalModal').style.display = 'none';
    document.getElementById('portfolioModal').style.display = 'none';
}
function saveStrategy(){
    strategyName=$('#strategyName')[0].value
    strategyDesc=$('#strategyDesc')[0].value
    strategyType=$('#strategyType')[0].value

    positions=STATE.positions
    // console.log(positions)
    postitionsToSave=[]
    
    $.post('savestrategy.php',{
        strategyName:strategyName,
        strategyDesc:strategyDesc,
        strategyType:strategyType,
        positions:positions
    },(data)=>{
        if(data=='Done'){
            showNotification('Strategy Saved', 'success');
            closeModal();
        }else{
            alert(data);
        }
    })
}
function saveStrategyOld(){
    strategyName=$('#strategyName')[0].value
    strategyDesc=$('#strategyDesc')[0].value
    strategyType=$('#strategyType')[0].value

    positions=STATE.positions
    // console.log(positions)
    postitionsToSave=[]
    
    $.post('saveStrategyOld.php',{
        strategyName:strategyName,
        strategyDesc:strategyDesc,
        strategyType:strategyType,
        positions:positions
    },(data)=>{
        if(data=='Done'){
            showNotification('Strategy Saved', 'success');
            closeModal();
        }else{
            alert(data);
        }
    })
}
function loadStrategy(){
    $.post('loadstrategy.php',(data)=>{
        jsonData=JSON.parse(data)
        html=''
        for(var i = 0;i<jsonData.length;i++){
            // console.log()
            pnl=0;
            postionsThis=jsonData[i]['positions']
            for(var j = 0; j<postionsThis.length; j++){
                if(postionsThis[j]['exitPrice']){
                    pnl+=(parseFloat(postionsThis[j]['exitPrice'])-parseFloat(postionsThis[j]['entryPrice']))*(postionsThis[j]['action']=='Buy'?1:-1)*parseFloat(postionsThis[j]['lots'])*parseFloat(postionsThis[j]['lotSize'])
                }else if(DataAllOptions[postionsThis[j]['instrumentToken']]){
                    pnl+=(DataAllOptions[postionsThis[j]['instrumentToken']]['market_data']['ltp']-parseFloat(postionsThis[j]['entryPrice']))*(postionsThis[j]['action']=='Buy'?1:-1)*parseFloat(postionsThis[j]['lots'])*parseFloat(postionsThis[j]['lotSize'])
                }else{
                    pnl+=0
                }
                
            }
            html+=`
                
            <tr id='Strategy_${i}' positions='${JSON.stringify(jsonData[i]['positions'])}' strategyName='${jsonData[i]['strategyName']}' strategyType='${jsonData[i]['strategyType']}' strategyDesc='${jsonData[i]['strategyDesc']}'>
                <td onclick='loadStrategySelected(${i})'>${jsonData[i]['strategyName']}</td>
                <td onclick='loadStrategySelected(${i})'>${jsonData[i]['strategyType']}</td>
                <td onclick='loadStrategySelected(${i})'>${jsonData[i]['strategyDesc']}</td>
                <td onclick='loadStrategySelected(${i})' class='${pnl>0?'profit':'loss'}'>${pnl}</td>
                
                <td onclick='deleteStrategy("${jsonData[i]['strategyName']}","${i}")'><i class="fas fa-trash"></i></td>
            </tr>
            `
        }
        $('#Strategies').html(html)

    })
}
function deleteStrategy(name,id){
    $.get('deleteStrategy.php?strategyName='+name,(data)=>{
        if(data=='Done'){
            $('#Strategy_' + id).remove();
        }
    })
}
function loadStrategySelected(id){
    positionsHTML=JSON.parse($('#Strategy_'+id)[0].getAttribute('positions'))
    positionMap={}
    positions=[]
    for(var i = 0;i<positionsHTML.length;i++){
        positionMap[`${positionsHTML[i]['strike']}${positionsHTML[i]['optType']}${positionsHTML[i]['expiry']}`]=[i]
        positions.push({
            "action": positionsHTML[i]['action'],
            "lots": parseFloat(positionsHTML[i]['lots']),
            "date": positionsHTML[i]['date'],
            "expiry": positionsHTML[i]['expiry'],
            "strike": parseFloat(positionsHTML[i]['strike']),
            "optType": positionsHTML[i]['optType'],
            "entryPrice": parseFloat(positionsHTML[i]['entryPrice']),
            "currentPrice": positionsHTML[i]['currentPrice']?parseFloat(positionsHTML[i]['currentPrice']):0,
            "exitPrice": positionsHTML[i]['exitPrice']?parseFloat(positionsHTML[i]['exitPrice']):undefined,
            "IV": parseFloat(positionsHTML[i]['IV']),
            "lotSize": parseFloat(positionsHTML[i]['lotSize']),
            "enabled": positionsHTML[i]['enabled'],
            'instrumentToken':positionsHTML[i]['instrumentToken'],
            "deltaOriginal": parseFloat(positionsHTML[i]['deltaOriginal']),
            "gammaOriginal": parseFloat(positionsHTML[i]['gammaOriginal']),
            "thetaOriginal": parseFloat(positionsHTML[i]['thetaOriginal']),
            "ivOriginal": parseFloat(positionsHTML[i]['ivOriginal']),
            "vegaOriginal": parseFloat(positionsHTML[i]['vegaOriginal']),
            "delta": parseFloat(positionsHTML[i]['delta']),
            "gamma": parseFloat(positionsHTML[i]['gamma']),
            "theta": parseFloat(positionsHTML[i]['theta']),
            "iv": parseFloat(positionsHTML[i]['iv']),
            "vega": parseFloat(positionsHTML[i]['vega'])
        })
    }
    $('#strategyName')[0].value=$('#Strategy_'+id)[0].getAttribute('strategyName')
    $('#strategyDesc')[0].value=$('#Strategy_'+id)[0].getAttribute('strategyDesc')
    $('#SaveOld')[0].style.display='block'
    STATE.positionMap=positionMap
    STATE.positions=positions
    updatePositionsTable(true)
    closeStrategyModal()
    showNotification('Strategy Loaded', 'success');
    updateGreeksTableFromState()
}

function openStrategyModal() {
    document.getElementById("loadStrategyModal").style.display = "flex";
    loadStrategy()

}

function closeStrategyModal() {
    document.getElementById("loadStrategyModal").style.display = "none";
}

// Setup action buttons in the header
function setupActionButtons() {
    // Save button
    $('.save-btn').on('click', function() {
        // //console.log()
        openModal()
        
    });

    // Export button
    $('.export-btn').on('click', function() {
        openStrategyModal()
    });

    // Refresh button
    $('.refresh-btn').on('click', function() {
        const symbol = $('#symbol').val();
        showNotification('Data refreshed', 'success');
    });

    // New strategy button
    $('.new-btn').on('click', function() {
        if (confirm('Create new strategy? Current strategy will be lost if not saved.')) {
            // Clear all positions
            STATE.positions = [];
            updatePositionsTable(true);
            updateChart();
            showNotification('New strategy created', 'success');
        }
    });

    // Copy button
    $('.copy-btn').on('click', function() {
        showNotification('Strategy copied to clipboard', 'success');
    });
    // Symbol selector change
$('.selector select').on('change', function() {
    const symbol = $(this).val();
    window.location.href = 'index.php?symbol=' + symbol;

    // Optional: show loading state
    // updateLoadingState(true);
    // showNotification(`Loading ${symbol} data...`, 'info');

    // Optional: Fetch new data via AJAX if staying on same page
    // fetchOptionChainData(symbol);
    // loadExpiryDates(symbol);
    // getSymbolType(symbol);
});

}

// Initialize tab functionality
function initializeTabs() {
    // Tab switching functionality
    $(document).on('click', '.tab-btn', function() {
        // Get the parent tab container
        const tabContainer = $(this).closest('.tab-container');
        
        // Remove active class from all buttons in this container
        tabContainer.find('.tab-btn').removeClass('active');
        
        // Add active class to clicked button
        $(this).addClass('active');
    });
    
    // Expiry tab functionality
    $(document).on('click', '.expiry-tab', function() {
        // Remove active class from all tabs
        $('.expiry-tab').removeClass('active');
        
        // Add active class to clicked tab
        $(this).addClass('active');
        
        // If we have real data loaded, update the chart based on new expiry
        if (STATE.dataLoaded) {
            scheduleChartUpdate();
        }
    });
    
    // Navigation arrows for expiry tabs
    $(document).on('click', '.nav-arrow', function() {
        const isLeft = $(this).text() === '←';
        const tabs = $('.expiry-tabs .expiry-tab');
        const activeIndex = tabs.index($('.expiry-tab.active'));
        
        if (isLeft && activeIndex > 0) {
            $(tabs[activeIndex - 1]).click();
        } else if (!isLeft && activeIndex < tabs.length - 1) {
            $(tabs[activeIndex + 1]).click();
        }
    });
}

// Initialize tables with placeholder data for faster perceived loading
function initializeTables() {
    // Option chain table with placeholders
    const placeholderRows = Array(10).fill().map((_, i) => {
        const strike = 22500 + (i * 50);
        return `
            <tr class="option-row ${i === 3 ? 'highlighted' : ''}">
                <td class="call-delta">-</td>
                <td class="call-iv">-</td>
                <td class="call-ltp">-</td>
                <td class="strike">${strike}</td>
                <td class="put-ltp">-</td>
                <td class="put-iv">-</td>
                <td class="put-delta">-</td>
            </tr>
        `;
    }).join('');
    
    for(var i=0;i<DOM.optionsTable.length;i++){
        // //console.log(placeholderRows)
        DOM.optionsTable[i].innerHTML=placeholderRows;
    }
    
    
    // Empty positions table
    DOM.positionsTable.html('');
}

// Function to load initial data (options chain, etc.)
function loadInitialData() {
    const symbol = DOM.symbolSelect.val() || 'NIFTY';
    
    // Start fetching option chain data
    fetchOptionChainData(symbol);
    
    // Independently load expiry dates
    loadExpiryDates(symbol);
    
    // Get symbol type in parallel
    getSymbolType(symbol);
}

// Asynchronously initialize WebSocket
async function initializeWebSocketAsync() {
    try {
        if (!accessToken) {
            showNotification('Login required. Redirecting...', 'error');
            setTimeout(() => {
                window.location.href = "/opt/broker_login.php";
            }, 3000);
            return;
        }
        
        showNotification('Connecting to market data feed...', 'info');
        
        // Initialize protobuf (can happen in parallel)
        initProtobuf();
        
        // Get WebSocket URL
        const url = await getWebSocketUrl(accessToken);
        
        if (url) {
            await connectWebSocket(url);
            STATE.wsInitialized = true;
            
            // Begin subscribing to data feeds, but don't wait for them
            subscribeToDataFeeds();
        }
    } catch (error) {
        console.error('Failed to initialize WebSocket:', error);
        showNotification('Connection to data feed failed. Retrying...', 'error');
        
        // Retry connection after delay
        setTimeout(initializeWebSocketAsync, CONSTANTS.RECONNECT_INTERVAL);
    }
}

// Optimized WebSocket URL fetching
async function getWebSocketUrl(token) {
    try {
        const response = await fetch("https://api.upstox.com/v3/feed/market-data-feed/authorize", {
            headers: {
                'Accept': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        return data.data.authorizedRedirectUri;
    } catch (error) {
        console.error('Error fetching WebSocket URL:', error);
        return null;
    }
}



// Process all pending updates in batch
function processAllPendingUpdates() {
    if (Object.keys(STATE.pendingUpdates).length === 0) return;
    
    streamCb({
        feeds: STATE.pendingUpdates
    });
    
    // Clear pending updates
    STATE.pendingUpdates = {};
}



// Use event delegation for better performance with trade buttons
function setupTradeButtonDelegation(optionsTable) {
    // Remove existing handlers to prevent duplicates
    optionsTable.off('click', '.trade-btn');
    
    // Add a single delegated handler
    optionsTable.on('click', '.trade-btn', function() {
        const strike = $(this).data('strike');
        const optType = $(this).data('type'); // 'CE' or 'PE'
        const action = $(this).hasClass('buy-btn') ? 'Buy' : 'Sell';
        
        // Get price from the correct cell
        const row = $(this).closest('tr');
        const price = optType === 'CE' 
            ? parseFloat(row.find('.call-ltp').text()) 
            : parseFloat(row.find('.put-ltp').text());
        
        // Get IV value
        const iv = optType === 'CE'
            ? parseFloat(row.find('.call-iv').text())
            : parseFloat(row.find('.put-iv').text());
            
        // Get current date
        const today = new Date();
        const currentDate = today.toISOString().split('T')[0];
        
        // Get expiry date from active tab
        const activeExpiry = $('.expiry-tab.active').text();
        // //console.log(activeExpiry)
        const expiryDate = formatExpiryDate(activeExpiry);
        //console.log(activeExpiry)
        //console.log(expiryDate)

        // Create new position
        addPosition({
            action,
            lots: 1,
            date: currentDate,
            expiry: expiryDate,
            strike,
            optType,
            entryPrice: price,
            currentPrice: price,
            IV: iv,
            lotSize: parseInt($('#lot').val() || 75),
            instrumentToken:row.attr(optType === 'CE'?'data-ce-token':'data-pe-token')
        });
        
        // Show notification
        showNotification(`${action} order for ${strike} ${optType} at ${price} added to positions`, 'success');
        
        // Update chart and metrics
        scheduleChartUpdate();
    });
}

// Use debouncedUpdateChart for better performance
let chartUpdateTimer = null;
function scheduleChartUpdate() {
    if (chartUpdateTimer) {
        clearTimeout(chartUpdateTimer);
    }
    
    chartUpdateTimer = setTimeout(() => {
        updateSpotPriceLine();
        chartUpdateTimer = null;
    }, CONSTANTS.CHART_UPDATE_INTERVAL);
}
// Function to handle tab navigation
function setupTabNavigation() {
    // Get all tab buttons
    const tabButtons = document.querySelectorAll('.expiry-tab');
    
    // Get all tab content panes
    const tabContents = document.querySelectorAll('.tab-pane');
    
    // Add click event listener to each tab button
    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        // //console.log('hi')
        // Remove active class from all buttons
        tabButtons.forEach(btn => {
          btn.classList.remove('active');
          btn.setAttribute('aria-selected', 'false');
        });
        
        // Remove active and show classes from all content panes
        tabContents.forEach(content => {
          content.classList.remove('active', 'show');
        });
        
        // Add active class to clicked button
        button.classList.add('active');
        button.setAttribute('aria-selected', 'true');
        
        // Get the target content id from the button's data attribute
        const targetId = button.getAttribute('data-bs-target').substring(1);
        
        // Add active and show classes to the target content
        const targetContent = document.getElementById(targetId);
        if (targetContent) {
          targetContent.classList.add('active', 'show');
        }
      });
    });
    
    // Handle navigation arrows
    const prevArrow = document.querySelector('.nav-arrow:first-child');
    const nextArrow = document.querySelector('.nav-arrow:last-child');
    
    if (prevArrow) {
      prevArrow.addEventListener('click', () => {
        const activeTab = document.querySelector('.expiry-tab.active');
        const prevTab = activeTab.previousElementSibling;
        if (prevTab && prevTab.classList.contains('expiry-tab')) {
          prevTab.click();
        }
      });
    }
    
    if (nextArrow) {
      nextArrow.addEventListener('click', () => {
        const activeTab = document.querySelector('.expiry-tab.active');
        const nextTab = activeTab.nextElementSibling;
        if (nextTab && nextTab.classList.contains('expiry-tab')) {
          nextTab.click();
        }
      });
    }
  }
  
  // Call the function when the DOM is fully loaded
//   document.addEventListener('DOMContentLoaded', );
  
  // Alternative initialization if the function needs to be called after dynamic content loading
  // setupTabNavigation();



// Helper functions for the optimized code
let positionsUpdateTimer = null;
function debouncePositionsTableUpdate() {
    if (positionsUpdateTimer) {
        clearTimeout(positionsUpdateTimer);
    }
    
    positionsUpdateTimer = setTimeout(() => {
        updatePositionsTable();
        positionsUpdateTimer = null;
    }, 500); // Update at most every 500ms
}

// Update loading state
function updateLoadingState(isLoading) {
    if (isLoading) {
        DOM.loader && DOM.loader.show();
    } else {
        DOM.loader && DOM.loader.hide();
    }
}

// Get symbol type from server
function getSymbolType(symbol) {
    if (!symbol) return;
    
    $.ajax({
        url: "getSymbolType_Comm.php",
        type: "POST",
        data: { optSymbol: symbol },
        success: function(data) {
            $("#SymbType").val(data);
        },
        error: function(error) {
            console.error("Error getting symbol type:", error);
            // Default to NSE
            $("#SymbType").val("NSE");
        }
    });
}

// Set future token based on symbol type
function setFutureToken(token,names,expiries) {
    const symbType = $("#SymbType").val();
    var FuturePricesHTML=''    
    for(var i = 0;i<token.length;i++){
        // console.log(names[i])
        FuturePricesHTML+='<option value="'+token[i]+'" expiry="'+expiries[i]+'">'+names[i]+'</option>'
    }
    $('#FuturePrices').html(FuturePricesHTML)
    // Format token based on symbol type
    if (symbType === "BSE") {
        $("#FutureToken").val("BSE_FO|" + token.join('&BSE_FO|'));
    } else if (symbType === "MCX") {
        $("#FutureToken").val("MCX_FO|" + token.join('&MCX_FO|'));
    } else if (symbType === "CUR") {
        $("#FutureToken").val("NCD_FO|" + token.join('&NCD_FO|'));
    } else {
        // Default to NSE
        $("#FutureToken").val("NSE_FO|" + token.join('&NSE_FO|'));
    }
}



// Update metrics display with calculated values
function updateMetricsDisplay() {
    if (!STATE.positions.length) return;
    var positions = STATE.positions.filter(pos => pos.enabled !== false); // Only use enabled positions
    
    //console.log(positions)
    // var ceLong = 
        
    let longCE = 0, longPE = 0, shortCE = 0, shortPE = 0;

    positions.forEach(item => {
        if (!item.enabled | item.exitPrice!=undefined) return; // Skip disabled trades

        const key = `${item.action}_${item.optType}`; // e.g. "Buy_CE"

        switch (key) {
            case "Buy_CE":
                longCE += item.lots;
                break;
            case "Buy_PE":
                longPE += item.lots;
                break;
            case "Sell_CE":
                shortCE += item.lots;
                break;
            case "Sell_PE":
                shortPE += item.lots;
                break;
        }
    });

    positionForMargin=[]
    positions.forEach(item=>{
        positionForMargin.push(
            {
                "instrumentKey" :item.instrumentToken,
                "side" : item.action=='Buy'?"B":'S',
                "quantity" : item.lots*item.lotSize,
                "product" : "D"
            }
        )
    })
    $.post('getMargin.php',{position:positionForMargin},(data)=>{
        $('#margin')[0].innerText='₹ '+data.response.data.finalMargin.toFixed(2)
    })
    // console.log(positionForMargin)


    // Generate new P/L data
    const plData = generatePLData();
    
    // Find maximum profit and loss from the P/L data
    let maxProfit = -Infinity;
    let maxLoss = Infinity;
    
    if(longCE == shortCE && longPE == shortPE ){
        plData.forEach(([price, pl]) => {
            if (pl > maxProfit) maxProfit = pl;
            if (pl < maxLoss) maxLoss = pl;
        });
    }else{
        if((longCE > shortCE && longPE < shortPE )||(longCE < shortCE && longPE > shortPE )){
            maxProfit='Undefined'
            maxLoss='Undefined'
        }else if((longCE > shortCE )||(longPE > shortPE )){
            maxProfit='Undefined'
            plData.forEach(([price, pl]) => {
                if (pl < maxLoss) maxLoss = pl;
            });
        }else if((longCE < shortCE )||(longPE < shortPE )){
            maxLoss='Undefined'
            plData.forEach(([price, pl]) => {
                if (pl > maxProfit) maxProfit = pl;
            });
        }
    }

    if(maxProfit!='Undefined'&&maxLoss!='Undefined'){
        rr=(Math.abs(maxProfit / maxLoss)).toFixed(2)
        maxProfit=`₹ ${formatIndianNumber(Math.round(maxProfit*100)/100)}`
        maxLoss=`₹ ${formatIndianNumber(Math.round(maxLoss*100)/100)}`
    }else{
        rr='-'
        if(maxProfit!='Undefined'){
            maxProfit=`₹ ${formatIndianNumber(Math.round(maxProfit*100)/100)}`
        }
        if(maxLoss!='Undefined'){
            maxLoss=`₹ ${formatIndianNumber(Math.round(maxLoss*100)/100)}`
        }
    }
    // Calculate net P/L
    let netPL = 0;
    // //console.log(STATE.positions)
    STATE.positions.forEach(position => {
        if(position.enabled) {

            if(position.exitPrice==undefined){
                pl = (position.currentPrice - position.entryPrice) * position.lots * position.lotSize * (position.action === 'Buy' ? 1 : -1);
            }else{
                pl = (position.exitPrice - position.entryPrice) * position.lots * position.lotSize * (position.action === 'Buy' ? 1 : -1);
            }
            netPL += pl;
        } 
    });
    
    // Update metrics in the DOM
    updateMetric('Max Profit:', maxProfit, "profit");
    updateMetric('Max Loss:', maxLoss, "loss");
    updateMetric('R:R:',rr , '');
    updateMetric('Net Credit:', maxProfit, '');
    updateMetric('Margin Required:', '₹ -', '');
    updateMetric('Funds Required:', '₹ -', '');
    updateMetric('Breakeven (Expiry):', findBreakeven(plData, 'expiry'), '');
    updateMetric('Current P/L:', `₹ ${formatIndianNumber(Math.round(netPL*100)/100)}`, netPL > 0 ? 'profit' : 'loss');
}

// Helper function to update a metric in the DOM
function updateMetric(title, value, className) {
    const metricCards = document.querySelectorAll('.metric-card');
    
    metricCards.forEach(card => {
        const titleElement = card.querySelector('.metric-title');
        if (titleElement && titleElement.textContent === title) {
            const valueElement = card.querySelector('.metric-value');
            if (valueElement) {
                valueElement.textContent = value;
                
                // Update classes
                valueElement.classList.remove('profit', 'loss');
                if (className) {
                    valueElement.classList.add(className);
                }
            }
        }
    });
}

// Helper function to find breakeven points
function findBreakeven(plData, type) {
    // Sort data by price
    const sortedData = [...plData].sort((a, b) => a[0] - b[0]);
    
    // Find price where P/L crosses zero
    let breakevenList = [];
    
    for (let i = 0; i < sortedData.length - 1; i++) {
        const [price1, pl1] = sortedData[i];
        const [price2, pl2] = sortedData[i + 1];
        
        // If P/L changes sign between these points, we have a breakeven
        if ((pl1 <= 0 && pl2 >= 0) || (pl1 >= 0 && pl2 <= 0)) {
            // Linear interpolation to find more accurate breakeven
            const ratio = Math.abs(pl1) / (Math.abs(pl1) + Math.abs(pl2));
            const breakeven = price1 + ratio * (price2 - price1);
            
            if(!Number.isNaN(breakeven)){
                breakevenList.push(breakeven.toFixed(2));
            }
        }
    }
    
    return breakevenList.length ? breakevenList.join('-') : 'N/A';
}


// Process future data updates
function processFutureData(data, symbType, digiToShow,token) {
    // console.log(data)
    if (!data.fullFeed?.marketFF) return;
    
    const marketData = data.fullFeed.marketFF;
    const futurePrice = marketData.ltpc?.ltp?.toFixed(digiToShow) || "";
    const timestamp = marketData.ltpc?.ltt ? formatTimestamp(marketData.ltpc.ltt) : "";
    
    let changeValue, changePercent;
    if (marketData.ltpc?.ltp && marketData.ltpc?.cp) {
        changeValue = (marketData.ltpc.ltp - marketData.ltpc.cp).toFixed(digiToShow);
        changePercent = ((changeValue / marketData.ltpc.cp) * 100).toFixed(2);
    }
    
    // Update UI elements
    if (futurePrice) {
        $("#FuturePriceDataNew").html(futurePrice);
        elements=$('.'+token.split('|')[0])
        for (i=0;i<elements.length;i++ ){
            elements[i].innerText=futurePrice
            id=parseFloat  (elements[i].replace('current',''))
            STATE.positions[id].currentPrice=futurePrice
            if(STATE.positions[id].exitPrice==undefined){
                $('#pnl'+id.toFixed(0))[0].innerText=(futurePrice-STATE.positions[id].entryPrice)*STATE.positions[id].lots*STATE.positions[id].lotSize*(STATE.positions[id].action=="Buy"?1:-1)
            }
            STATE.positions[id].currentPrice=futurePrice
            
        }
        updateFuturePrice(futurePrice,token);
    }
    
    if (changeValue && changePercent) {
        $("#FutureChangeDataNew").html(changeValue);
        $("#FutureChangePerDataNew").html(changePercent);
    }
    
    if (timestamp) {
        $("#FutureTime").html(timestamp);
    }
    
    updatePriceArrows();
}

// Update fair price in UI
function updateFairPrice(price) {
    if (!price) return;
    $(".price-info div:nth-child(1)").text(`Fair Price: ${price}`);
}

// Update future price in UI
function updateFuturePrice(price,token) {
    if (!price) return;
    var FuturePrice= $('#FuturePrices').val()
    // console.log(token)
    if(FuturePrice==token.split('|')[1]){
        $("#FuturePriceDataNew").html(price);
        $(".price-info div:nth-child(3)").text(`Future Price: ${price}`);
    }
    
}

// Update price arrows in UI based on change direction
function updatePriceArrows() {
    const spotChange = parseFloat($("#SpotChangeDataNew").text() || "0");
    
    // Update spot price badge
    if (spotChange > 0) {
        $(".price-badge.buy").show();
        $(".price-badge.sell").hide();
    } else if (spotChange < 0) {
        $(".price-badge.buy").hide();
        $(".price-badge.sell").show();
    } else {
        $(".price-badge.buy").show();
        $(".price-badge.sell").show();
    }
}

// Update price info in header
function updatePriceInfo() {
    const spotPrice = $("#SpotPriceDataNew").text() || "0";
    const futurePrice = $("#FuturePriceDataNew").text() || "0";
    const lot = $("#lot").val() || "75";
    
    // Update UI elements in the header
    $(".price-info div:nth-child(1)").text(`Fair Price: ${spotPrice}`);
    $(".price-info div:nth-child(3)").text(`Future Price: ${futurePrice}`);
    $(".price-info div:nth-child(4)").text(`Lot Size: ${lot}`);
    
    // Calculate and update IV
    const ivTotal = STATE.positions.reduce((sum, pos) => sum + parseFloat(pos.IV || 0), 0);
    const avgIV = STATE.positions.length ? (ivTotal / STATE.positions.length).toFixed(2) : "0.00";
    $(".price-info div:nth-child(5)").text(`IV: ${avgIV}`);
}

// Update last updated time
function updateLastUpdatedTime() {
    // Get current date and time
    const now = new Date();
    
    // Format date as DD-MMM-YYYY
    const dateStr = now.toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    });
    
    // Format time as HH:MM
    const timeStr = now.toLocaleTimeString('en-IN', {
        hour: '2-digit',
        minute: '2-digit'
    });
    
    // Update the status bar text
    $(".status-bar div:first-child").text(`Last Updated: ${dateStr} ${timeStr}`);
}

// Format timestamp for display
function formatTimestamp(ltt) {
    if (!ltt) return "";
    
    // Parse the timestamp from the input (assuming it's in milliseconds)
    const timestamp = parseInt(ltt.slice(0, -3)) * 1000;
    const date = new Date(timestamp);
    
    // Check if the date is valid
    if (isNaN(date.getTime())) {
        return "Invalid";
    }
    
    // Format as HH:MM:SS
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const seconds = date.getSeconds().toString().padStart(2, '0');
    
    return `${hours}:${minutes}:${seconds}`;
}

// Format expiry date from tab text
function formatExpiryDate(expiryText) {
    if (!expiryText) return "";
    return expiryText;
}

// Convert month abbreviation to number
function convertMonthToNumber(monthAbbr) {
    if (!monthAbbr) return "01";
    
    const months = {
        'JAN': '01', 'FEB': '02', 'MAR': '03', 'APR': '04', 
        'MAY': '05', 'JUN': '06', 'JUL': '07', 'AUG': '08',
        'SEP': '09', 'OCT': '10', 'NOV': '11', 'DEC': '12'
    };
    return months[monthAbbr.toUpperCase()] || "01";
}

// Protobuf initialization
async function initProtobuf() {
    if (!window.protobufRoot) {
        try {
            // Load the protocol buffer definition from the specified file
            window.protobufRoot = await protobuf.load('/LiveOptionChain/marketDataFeed.proto/');
            ////console.log("Protobuf initialization complete");
        } catch (error) {
            console.error("Error initializing Protobuf:", error);
            showNotification("Failed to initialize data feed protocol", "error");
        }
    }
}

// Convert blob to array buffer
async function blobToArrayBuffer(blob) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = (error) => reject(error);
        reader.readAsArrayBuffer(blob);
    });
}

// Decode protobuf message
function decodeProtobuf(buffer) {
    if (!window.protobufRoot) {
        console.error("Protobuf not initialized");
        return null;
    }
    
    try {
        const FeedResponse = window.protobufRoot.lookupType("com.upstox.marketdatafeeder.rpc.proto.FeedResponse");
        return FeedResponse.decode(buffer);
    } catch (error) {
        console.error("Error decoding protobuf:", error);
        return null;
    }
}

// Setup event handlers
function setupEventHandlers() {
    // Option row click handler with event delegation
    $(document).on('click', '.option-row', function(event) {
        // Don't trigger if clicking on a button
        if (event.target.tagName === 'BUTTON') return;
        
        // Update highlighted row
        $('.option-row').removeClass('highlighted');
        $(this).addClass('highlighted');
    });
    
    // Position action buttons with event delegation
    $(document).on('click', '.edit-btn', function() {
        openEditModal(this);
    });
    // Modified click handler for exit button
    $(document).on('click', '.exit-btn', function() {
        const $row = $(this).closest('tr');
        const index = $row.index();
        const position = STATE.positions[index];
        
        // Create a dialog for lot selection
        const totalLots = position.lots;
        const price=position.currentPrice
        
        // Create the dialog HTML
        const dialogHTML = `
            <div id="exit-dialog" class="modal">
                <div class="modal-content">
                    <h4>Exit Position</h4>
                    <p>Position: ${position.strike}  ${position.optType}  - ${position.action} - ${totalLots} lots at ${position.entryPrice}</p>
                    <div class="form-group">
                        <label for="exit-lots">Number of lots to exit (1-${totalLots}):</label>
                        <input type="number" id="exit-lots" min="1" max="${totalLots}" value="${totalLots}" class="form-control">
                    </div><div class="form-group">
                        <label for="exit-lots">Price to exit:</label>
                        <input type="number" id="exit-price"  value="${price}" class="form-control">
                    </div>
                    <div class="button-group">
                        <button id="confirm-exit" class="btn btn-primary">Exit Position</button>
                        <button id="cancel-exit" class="btn btn-secondary">Cancel</button>
                    </div>
                </div>
            </div>
        `;
        
        // Add the dialog to the page
        $('body').append(dialogHTML);
        
        // Show the dialog with fade-in effect
        $('#exit-dialog').css('display', 'block');
        
        // Handle confirm button click
        $('#confirm-exit').on('click', function() {
            const lotsToExit = parseInt($('#exit-lots').val());
            const priceExit = parseInt($('#exit-price').val());
            
            if (lotsToExit > 0 && lotsToExit <= totalLots) {
                exitPosition(index, lotsToExit,priceExit);
                updateChart();
                showNotification(`Exited ${lotsToExit} lots @ ${priceExit} of position`, 'success');
            } else {
                showNotification('Invalid number of lots', 'error');
            }
            
            // Close with fade-out effect and remove the dialog
            $('#exit-dialog').fadeOut(200, function() {
                $(this).remove();
            });
        });
        
        // Handle cancel button click
        $('#cancel-exit').on('click', function() {
            $('#exit-dialog').fadeOut(200, function() {
                $(this).remove();
            });
        });
        
        // Also close when clicking outside the modal
        $(document).on('click', '#exit-dialog', function(e) {
            if ($(e.target).is('#exit-dialog')) {
                $('#exit-dialog').fadeOut(200, function() {
                    $(this).remove();
                });
            }
        });
    });

    
    $(document).on('click', '.delete-btn', function() {
        if (confirm('Are you sure you want to delete this position?')) {
            // Remove the position from the analysis
            const index = $(this).closest('tr').index();
            deletePosition(index);
            updateChart();
            showNotification('Position deleted from analysis', 'success');
        }
    });
    
    // Modal handling
    $('.close-modal, #cancel-edit').on('click', function() {
        $('#editPositionModal').hide();
    });
    
    // Modal outside click
    $(window).on('click', function(event) {
        if (event.target === document.getElementById('editPositionModal')) {
            $('#editPositionModal').hide();
        }
    });
    
    // Form submission handler
    $('#editPositionForm').on('submit', function(event) {
        event.preventDefault();
        
        // Get form values
        const rowIndex = $('#edit-row-index').val();
        const action = $('#edit-action').val();
        const lots = $('#edit-lots').val();
        const strike = $('#edit-strike').val();
        const optType = $('#edit-opt-type').val();
        const entryPrice = $('#edit-entry-price').val();
        const iv = $('#edit-iv').val();
        
        // Update position
        updatePosition(rowIndex, {
            action,
            lots: parseFloat(lots),
            strike: parseFloat(strike),
            optType,
            entryPrice: parseFloat(entryPrice),
            IV: parseFloat(iv)
        });
        
        // Close modal
        $('#editPositionModal').hide();
        
        // Update chart
        updateChart();
        
        // Show notification
        showNotification('Position updated successfully', 'success');
    });
    
    // IV and price adjustment buttons
    $(document).on('click', '.inc-btn, .dec-btn', function() {
        const isIncrement = $(this).hasClass('inc-btn');
        const input = isIncrement ? $(this).prev() : $(this).next();
        
        if (input.val().includes('IV')) {
            // Adjust IV
            const currentIV = parseFloat(input.val().replace('IV ', ''));
            const newIV = currentIV + (isIncrement ? 1 : -1);
            input.val(`IV ${newIV}%`);
        } else {
            // Adjust price
            const match = input.val().match(/([0-9.]+)/);
            if (match) {
                const currentPrice = parseFloat(match[0]);
                const newPrice = currentPrice + (isIncrement ? 50 : -50);
                input.val(`${newPrice} 0%`);
            }
        }
        
        updateChart();
    });
}

// Open edit modal with position data
function openEditModal(button) {
    const row = $(button).closest('tr');
    const index = row.index();
    const position = STATE.positions[index];
    
    if (!position) return;
    
    // Populate form
    $('#edit-row-index').val(index);
    $('#edit-action').val(position.action);
    $('#edit-lots').val(position.lots);
    $('#edit-strike').val(position.strike);
    $('#edit-opt-type').val(position.optType);
    $('#edit-entry-price').val(position.entryPrice);
    $('#edit-iv').val(position.IV);
    
    // Show modal
    $('#editPositionModal').show();
}

// Handle WebSocket reconnection
async function handleReconnection() {
    if (!STATE.shouldReconnect) return;

    let reconnectDelay = CONSTANTS.RECONNECT_INTERVAL * Math.pow(CONSTANTS.RECONNECT_DECAY, STATE.reconnectAttempts);
    reconnectDelay = Math.min(reconnectDelay, CONSTANTS.MAX_RECONNECT_INTERVAL);

    ////console.log(`Reconnecting in ${reconnectDelay}ms...`);
    showNotification(`Attempting to reconnect in ${reconnectDelay/1000} seconds...`, 'info');

    setTimeout(async () => {
        try {
            STATE.reconnectAttempts += 1;
            const token = $('#Access_Token').val() || accessToken;
            const newUrl = await getWebSocketUrl(token);
            
            if (!newUrl) {
                throw new Error("Failed to get WebSocket URL");
            }
            
            await connectWebSocket(newUrl);
            
            // Resubscribe to all previous feeds
            if (STATE.instrumentKeys.length > 0) {
                subscribeTo(STATE.instrumentKeys);
            } else {
                // Fallback to subscribing to basic tokens
                subscribeToDataFeeds();
            }
            
            showNotification('Reconnected to market data feed', 'success');
        } catch (error) {
            console.error('Error during reconnection:', error);
            showNotification('Failed to reconnect, trying again...', 'error');
            handleReconnection(); // Try again
        }
    }, reconnectDelay);
}

function autoRoll(expiry){
    //console.log(centerStrike[expiry])
    //console.log()
   
    $('#nav-tabContent')[0].scrollTo({
        top:  $('#nav-tabContent')[0].scrollHeight *(centerStrike[expiry].indexOf(parseFloat(atm))-6)/centerStrike[expiry].length,
        behavior: "smooth",
      });
      
}
// Listen to Bootstrap's tab shown event
document.addEventListener('shown.bs.tab', function (event) {
    const expiry = event.target.id.replace('-tab', ''); // Get expiry from tab ID
    autoRoll(expiry); // Call your function
});

// Setup expiry tabs
function setupExpiryTabs(expiryDates) {
    if (!expiryDates || !expiryDates.length) return;
    
    // Clear current tabs
    const tabContainer = $(".expiry-tabs");
    tabContainer.find(".expiry-tab").remove();
    
    // Add tabs
    expiryDates.forEach((expiry, index) => {
        const tab = $(`<button class="expiry-tab" id="${expiry}-tab" data-bs-toggle="tab" data-bs-target="#${expiry}" type="button" role="tab" aria-controls="${expiry}" aria-selected="true" >${expiry}</button>`);
        if (index === 0) tab.addClass("active"); // Set the second tab (monthly) as active by default
        
        tabContainer.append(tab);
    });
    const tabElList = document.querySelectorAll('button[data-bs-toggle="tab"]');
    
    
    tabElList.forEach(function (tabEl) {
        tabEl.addEventListener('shown.bs.tab', function (event) {
            const expiry = event.target.id.replace('-tab', '');
            setTimeout(() => {
                autoRoll(expiry);
            }, 50); // slight delay ensures content is visible
        });
    });
    contentHTML=''
    
    // Add tabs
    expiryDates.forEach((expiry, index) => {
    
        // Generate the table header based on selected columns
        let headerHtml = '<tr>';
        
        // Add Call side headers
        STATE.userColumns.callSide.forEach(colId => {
            const column = COLUMN_OPTIONS.CALL_SIDE.find(col => col.id === colId);
            if (column) {
                headerHtml += `<th class="${colId}">${column.label}</th>`;
            }
        });
        
        // Add Strike header
        headerHtml += '<th class="strike">Strike</th>';
        
        // Add Put side headers
        STATE.userColumns.putSide.forEach(colId => {
            const column = COLUMN_OPTIONS.PUT_SIDE.find(col => col.id === colId);
            if (column) {
                headerHtml += `<th class="${colId}">${column.label}</th>`;
            }
        });
        
        headerHtml += '</tr>';
        if (index === 0){
            
            
            contentHTML+=`<div class="tab-pane fade show active" id="${expiry}" role="tabpanel" aria-labelledby="${expiry}-tab">
                    <div class="options-table" id="${expiry}_optionChain">
                        <table>
                            <thead>${headerHtml}
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div></div>`   
        }else{
            contentHTML+=`<div class="tab-pane fade  " id="${expiry}" role="tabpanel" aria-labelledby="${expiry}-tab">
                    <div class="options-table">
                        <table>
                            <thead>${headerHtml}
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div></div>`
        }
    });
    
    $('#nav-tabContent')[0].innerHTML=contentHTML
    
    const symbol = DOM.symbolSelect.val() || 'NIFTY';
    
    setupTabNavigation()
}

// Get available expiries (would typically come from API)
function getAvailableExpiries() {
    // For demo purposes, we'll use some hardcoded values
    return [
        "20MAR25(W)",
        "27MAR25(M)",
        "03APR25(W)",
        "09APR25(W)",
        "17APR25(W)"
    ];
}

// Load expiry dates from server
function loadExpiryDates(symbol, callback) {
    if (!symbol) {
        console.error("No symbol provided for loading expiry dates");
        if (callback) callback();
        return;
    }
    
    $.ajax({
        url: `/data/getExpiryDates2.php?symbol=${symbol}`,
        type: "GET",
        success: function(data) {
            try {
                const expiryDates = data.expiry_dates || getAvailableExpiries();
                
                // Update expiry tabs
                setupExpiryTabs(expiryDates);
                
                if (callback) callback();
            } catch (error) {
                console.error("Error parsing expiry dates:", error);
                showNotification("Failed to load expiry dates", "error");
                
                // Fallback to hardcoded expiry dates
                setupExpiryTabs(getAvailableExpiries());
                
                if (callback) callback();
            }
        },
        error: function(xhr, status, error) {
            console.error("Error fetching expiry dates:", error);
            showNotification("Failed to load expiry dates", "error");
            
            // Fallback to hardcoded expiry dates
            setupExpiryTabs(getAvailableExpiries());
            
            if (callback) callback();
        }
    });
}

// Better performance notification system
function createNotificationContainer() {
    // Create notification container if it doesn't exist
    if (!document.getElementById('notification-container')) {
        const container = document.createElement('div');
        container.className = 'notification-container';
        container.id = 'notification-container';
        document.body.appendChild(container);
        
        // Cache it
        DOM.notificationContainer = container;
    }
}

// More efficient notification system with limiting
const activeNotifications = new Set();
function showNotification(message, type = 'info', duration = 3000) {
    // Limit number of active notifications to prevent overwhelming the UI
    // if (activeNotifications.size > 5) {
    //     const oldestNotification = document.querySelector('.notification');
    //     if (oldestNotification) {
    //         closeNotification(oldestNotification);
    //     }
    // }
    
    // // Check for duplicate notifications
    // const existingNotifications = document.querySelectorAll('.notification-message');
    // for (let i = 0; i < existingNotifications.length; i++) {
    //     if (existingNotifications[i].textContent === message) {
    //         return; // Skip duplicates
    //     }
    // }
    
    // // Create notification element
    // const notification = document.createElement('div');
    // notification.className = `notification ${type}`;
    
    // // Create icon based on notification type
    // let iconHTML = '';
    // switch(type) {
    //     case 'success': iconHTML = '✓'; break;
    //     case 'error': iconHTML = '✗'; break;
    //     case 'warning': iconHTML = '⚠'; break;
    //     default: iconHTML = 'ℹ';
    // }
    
    // // Set notification content
    // notification.innerHTML = `
    //     <span class="notification-icon">${iconHTML}</span>
    //     <span class="notification-message">${message}</span>
    //     <button class="notification-close">×</button>
    // `;
    
    // // Track active notifications
    // activeNotifications.add(notification);
    
    // // Add to container
    // const container = document.getElementById('notification-container');
    // if (container) container.appendChild(notification);
    
    // // Force a reflow to make the transition work
    // notification.offsetHeight;
    
    // // Show notification
    // setTimeout(() => {
    //     notification.classList.add('show');
    // }, 10);
    
    // // Set up close button
    // const closeButton = notification.querySelector('.notification-close');
    // if (closeButton) {
    //     closeButton.addEventListener('click', () => {
    //         closeNotification(notification);
    //     });
    // }
    
    // // Auto close after duration
    // const timeoutId = setTimeout(() => {
    //     closeNotification(notification);
    // }, duration);
    
    // // Store the timeout ID on the notification element
    // notification.dataset.timeoutId = timeoutId;
    
    // return notification;
}

function closeNotification(notification) {
    if (!notification) return;
    
    // Clear the timeout to prevent duplicate close attempts
    clearTimeout(notification.dataset.timeoutId);
    
    // Start the hiding animation
    notification.classList.remove('show');
    
    // Remove from tracking set
    activeNotifications.delete(notification);
    
    // Remove the element after the animation completes
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 300); // Should match the transition duration in CSS
}
// Add this debugging function to track the flow of data
function debugLog(message, data) {
    ////console.log(`[DEBUG] ${message}`, data);
}






// Verify DOM element caching
document.addEventListener('DOMContentLoaded', function() {
    debugLog('DOM loaded, initializing DOM cache');
    // Verify DOM elements exist before caching
    debugLog('DOM elements availability check:', {
        optionsTable: $('.options-table table tbody').length > 0,
        positionsTable: $('.positions-table tbody').length > 0,
        symbolSelect: $('#symbol').length > 0,
        chartContainer: $('#highcharts-container').length > 0
    });
    
    // Now cache DOM elements
    DOM.init();
    
    // Verify the DOM cache was created successfully
    debugLog('DOM cache initialized:', {
        optionsTableCached: !!DOM.optionsTable,
        positionsTableCached: !!DOM.positionsTable,
        symbolSelectCached: !!DOM.symbolSelect,
        chartContainerCached: !!DOM.chartContainer
    });
});

// Verify WebSocket connection status
function verifyWebSocketStatus() {
    if (!window.ws) {
        debugLog('WebSocket not initialized');
        return;
    }
    
    const status = {
        0: 'CONNECTING',
        1: 'OPEN',
        2: 'CLOSING',
        3: 'CLOSED'
    };
    
    debugLog('WebSocket status:', status[window.ws.readyState]);
    return window.ws.readyState;
}

// Add periodic WebSocket status check
setInterval(verifyWebSocketStatus, 5000); // Check every 5 seconds

// Verify token subscription
function verifyTokenSubscription() {
    debugLog('Token subscription info:', {
        spotToken: $("#SpotToken").val(),
        futureToken: $("#FutureToken").val(),
        instrumentKeysLength: STATE.instrumentKeys.length,
        idValue: $("#Id").val()
    });
}

// Check subscription status after WebSocket connects
window.addEventListener('websocket_connected', function() {
    debugLog('WebSocket connected event fired');
    verifyTokenSubscription();
});




// Fixed WebSocket initialization
async function initializeWebSocketAsync() {
    try {
        ////console.log('Starting WebSocket initialization');
        
        if (!accessToken) {
            console.error('No access token available for WebSocket');
            showNotification('Login required. Redirecting...', 'error');
            setTimeout(() => {
                window.location.href = "/opt/broker_login.php";
            }, 3000);
            return;
        }
        
        showNotification('Connecting to market data feed...', 'info');
        
        // Initialize protobuf (can happen in parallel)
        await initProtobuf();
        
        // Get WebSocket URL
        const url = await getWebSocketUrl(accessToken);
        
        if (url) {
            ////console.log('WebSocket URL obtained, connecting...');
            await connectWebSocket(url);
            STATE.wsInitialized = true;
            STATE.wsReady = true;
            
            // If we already have data loaded, subscribe now
            if (STATE.dataLoaded || STATE.pendingSubscription) {
                ////console.log('Data already loaded, subscribing to feeds');
                subscribeToDataFeeds();
            }
            
            // Set flag to false now that we've handled it
            STATE.pendingSubscription = false;
        } else {
            console.error('Failed to get WebSocket URL');
            throw new Error('Failed to get WebSocket URL');
        }
    } catch (error) {
        console.error('Failed to initialize WebSocket:', error);
        showNotification('Connection to data feed failed. Retrying...', 'error');
        
        // Retry connection after delay
        setTimeout(initializeWebSocketAsync, CONSTANTS.RECONNECT_INTERVAL);
    }
}

// Fixed data processing with additional error handling
function processOptionData(token, data, digiToShow) {
    if (!data.fullFeed?.marketFF) {
        ////console.log('Invalid data format for token:', token);
        return;
    }
    
    const marketData = data.fullFeed.marketFF;
    const optionGreeks = marketData.optionGreeks;
    
    // Extract data
    const ltp = marketData.ltpc?.ltp?.toFixed(digiToShow) || "";
    
    // Find the row containing this token (could be CE or PE)
    const ceRows = $(`[data-ce-token="${token}"]`);
    const peRows = $(`[data-pe-token="${token}"]`);
    
    if (ceRows.length) {
        // Update Call option data
        ceRows.each(function() {
            const row = $(this);
            const strike = row.find('.strike').text();
            row.find('.call-ltp').html(`${ltp}<div class="trade-buttons">
                <button class="trade-btn buy-btn ce" data-strike="${strike}" data-type="CE">Buy</button>
                <button class="trade-btn sell-btn ce" data-strike="${strike}" data-type="CE">Sell</button>
            </div>`);
            
            if (optionGreeks) {
                row.find('.call-delta').text(optionGreeks.delta?.toFixed(2) || "-");
                row.find('.call-iv').text(optionGreeks.iv ? (optionGreeks.iv * 100).toFixed(2) : "-");
            }
        });
    }
    
    if (peRows.length) {
        // Update Put option data
        peRows.each(function() {
            const row = $(this);
            const strike = row.find('.strike').text();
            row.find('.put-ltp').html(`${ltp}<div class="trade-buttons">
                <button class="trade-btn buy-btn pe" data-strike="${strike}" data-type="PE">Buy</button>
                <button class="trade-btn sell-btn pe" data-strike="${strike}" data-type="PE">Sell</button>
            </div>`);
            
            if (optionGreeks) {
                row.find('.put-delta').text(optionGreeks.delta?.toFixed(2) || "-");
                row.find('.put-iv').text(optionGreeks.iv ? (optionGreeks.iv * 100).toFixed(2) : "-");
            }
        });
    }
}

window.OptionData=null
// Modified fetch function to handle errors better
function fetchOptionChainData(symbol, expiry) {
    ////console.log('Fetching option chain data for', symbol);
    updateLoadingState(true);
    
    // Show a notification to inform user
    showNotification(`Loading option chain data for ${symbol}...`, 'info');
    
    // Default date if not provided
    const expiryDate = expiry || '2025-03-20';
    
    // Get symbol type
    const symbType = $("#SymbType").val() || 'FNO';
    
    $.ajax({
        url: "getAllStrikes_Comm_v2.php",
        type: "POST",
        data: { 
            optSymbol: symbol, 
            SymbType: symbType
        },
        success: function(data) {
            ////console.log('Received option chain data');
            try {
                // Check if data is already an object (some Ajax implementations might auto-parse JSON)
                const parsedData = typeof data === 'string' ? JSON.parse(data) : data;
                // if()
                // document.getElementById()
                
                $("#SpotPriceDataNew").html(parsedData['ltp']);
                $("#indexLTP").html(parsedData['ltp']);
                $(".price-info div:nth-child(1)").text(`Fair Price: ${parsedData['ltp']}`);

                handleOptionChainData(parsedData);
                window.OptionData=parsedData.expiryWise
                showNotification(`${symbol} option chain loaded`, 'success');
            } catch (e) {
                console.error("Error parsing option chain data:", e);
                showNotification("Failed to parse option chain data", "error");
                // Try to display raw data for debugging
                ////console.log('Raw data:', typeof data === 'string' ? data.substring(0, 500) : data);
            }
            updateLoadingState(false);
        },
        error: function(xhr, status, error) {
            console.error("Error fetching option chain data:", error);
            console.error("Status:", status);
            console.error("Response:", xhr.responseText ? xhr.responseText.substring(0, 500) : 'No response text');
            
            updateLoadingState(false);
            
            // Provide more info to the user
            showNotification(`Failed to load data: ${status} - ${error}`, "error");
            
            // Create a fallback table with sample data if no real data
            createFallbackTable();
        }
    });
}

// Create a fallback table with sample data for testing
function createFallbackTable() {
    ////console.log('Creating fallback table with sample data');
    
    if (!DOM.optionsTable || DOM.optionsTable.length === 0) {
        console.error('Options table DOM element not found, re-initializing DOM');
        DOM.init();
    }
    
    // Sample strikes and tokens
    const sampleStrikes = [];
    const sampleCE_Tokens = [];
    const samplePE_Tokens = [];
    
    // Generate sample data
    const baseStrike = 22500;
    for (let i = 0; i < 10; i++) {
        const strike = baseStrike + (i * 50);
        sampleStrikes.push(strike);
        sampleCE_Tokens.push(`CE_TOKEN_${strike}`);
        samplePE_Tokens.push(`PE_TOKEN_${strike}`);
    }
    
    // Render with sample data
    if (DOM.optionsTable) {
        renderOptionsTable(sampleStrikes, sampleCE_Tokens, samplePE_Tokens);
    }
    
    // Store sample data in global state
    $("#StrikePriceArray").val(sampleStrikes.join(','));
    STATE.dataLoaded = true;
}

// Check if data has been loaded after timeout
function checkDataLoaded() {
    if (!STATE.dataLoaded) {
        console.warn('Data still not loaded after timeout, trying fallback method');
        createFallbackTable();
        
        // Try reconnecting WebSocket if it failed
        if (!STATE.wsReady) {
            ////console.log('WebSocket not ready, attempting to reconnect');
            initializeWebSocketAsync();
        }
    }
}

// Create a simple function to test if WebSocket messages are being received
let messageCount = 0;
let lastMessageTime = 0;

function logMessageStats() {
    const now = Date.now();
    const elapsed = now - lastMessageTime;
    const status = {
        messageCount,
        timeSinceLastMessage: lastMessageTime > 0 ? `${elapsed}ms` : 'No messages yet',
        wsReady: STATE.wsReady,
        wsReadyState: window.ws ? window.ws.readyState : 'No WebSocket'
    };
    
    ////console.log('WebSocket message stats:', status);
    
    if (messageCount === 0 && elapsed > 10000) {
        console.warn('No messages received in the last 10 seconds, connection may be inactive');
        // Try reconnecting if no messages are coming in
        if (STATE.wsReady && window.ws && window.ws.readyState === WebSocket.OPEN) {
            ////console.log('Attempting to resubscribe to data feeds');
            subscribeToDataFeeds();
        }
    }
}

// Log stats every 10 seconds
setInterval(logMessageStats, 10000);

// Modify throttled callback to track messages
function throttledStreamCallback(data) {
    // Update message stats
    messageCount++;
    lastMessageTime = Date.now();
    
    const now = Date.now();
    
    // Update at most every 100ms
    if (now - lastUpdateTime < 100) {
        // Queue updates for critical data rather than dropping them
        Object.assign(STATE.pendingUpdates, data.feeds);
        
        // Schedule a future update if not already scheduled
        if (!STATE.updateDebounceTimer) {
            STATE.updateDebounceTimer = setTimeout(() => {
                processAllPendingUpdates();
                STATE.updateDebounceTimer = null;
            }, CONSTANTS.UPDATE_DEBOUNCE_INTERVAL);
        }
        return;
    }
    
    // Reset the timer and pending updates
    lastUpdateTime = now;
    
    // Process the current data
    streamCb(data);
}

// Update formatted tokens function to handle different formats
function formatTokens(tokens) {
    if (!tokens) return [];
    
    const symbType = $("#SymbType").val() || 'NSE';
    
    // Handle different input formats
    let tokenArray;
    if (Array.isArray(tokens)) {
        tokenArray = tokens;
    } else if (typeof tokens === 'string') {
        tokenArray = tokens.split(',');
    } else {
        console.error('Invalid tokens format:', tokens);
        return [];
    }
    
    return tokenArray.map(value => {
        // Skip empty values
        if (!value) return null;
        
        let parts;
        if (typeof value === 'string' && value.includes('_')) {
            parts = value.split('_');
        } else {
            parts = [value];
        }
        
        const token = parts[0];
        if (!token) return null;
        
        if(token.includes('NSE_INDEX')) return token;
        if (symbType === "BSE") return 'BSE_FO|' + token;
        if (symbType === "CUR") return 'NCD_FO|' + token;
        if (symbType === "MCX") return 'MCX_FO|' + token;
        return 'NSE_FO|' + token;
    }).filter(token => token !== null); // Remove any nulls
}



// Add this debugging function to help find the token matching issue
function debugTokens() {
    ////console.log("Debugging token matches:");
    
    // Get tokens from state
    const id = $("#Id").val() ? JSON.parse($("#Id").val()) : [];
    ////console.log("Tokens from state:", id);
    
    // Check tokens in HTML
    const ceTokens = [];
    const peTokens = [];
    
    // Find all CE and PE tokens in the DOM
    $('[data-ce-token]').each(function() {
        ceTokens.push($(this).attr('data-ce-token'));
    });
    
    $('[data-pe-token]').each(function() {
        peTokens.push($(this).attr('data-pe-token'));
    });
    
    ////console.log("CE tokens in DOM:", ceTokens);
    ////console.log("PE tokens in DOM:", peTokens);
    
    // Check for token format issues
    if (id.length > 0) {
        ////console.log("Sample token format:", id[0]);
    }
    
    // Check token format in DOM
    if (ceTokens.length > 0) {
        ////console.log("Sample CE token format in DOM:", ceTokens[0]);
    }
    
    // Look for any format differences
    if (id.length > 0 && ceTokens.length > 0) {
        const stateToken = id[0];
        const domToken = ceTokens[0];
        
        if (stateToken !== domToken) {
            ////console.log("Token format mismatch detected!");
            ////console.log("State token:", stateToken);
            ////console.log("DOM token:", domToken);
            
            // Check if prefixing might solve the issue
            if (domToken && stateToken && stateToken.includes(domToken)) {
                ////console.log("State token contains DOM token - state token may have a prefix");
            } else if (domToken && stateToken && domToken.includes(stateToken)) {
                ////console.log("DOM token contains state token - DOM token may have a prefix");
            }
        }
    }
}

// Add this to your document ready function
setTimeout(debugTokens, 3000);


// Helper function to normalize token format
function getNormalizedToken(token) {
    // Remove exchange prefix if present
    if (token && token.includes('|')) {
        return token.split('|')[1];
    }
    return token;
}

// Modify the streamCb function to ensure it matches tokens correctly
function streamCb(feedData) {
    if (!feedData || !feedData.feeds) {
        return;
    }
    
    const symbType = $("#SymbType").val() || 'NSE';
    const digiToShow = symbType === "CUR" ? 4 : 2;
    const spotToken = $("#SpotToken").val();
    
    // Get tokens with better error handling
    let id = [];
    try {
        const idVal = $("#Id").val();
        id = idVal ? JSON.parse(idVal) : [];
    } catch (e) {
        console.error("Error parsing ID tokens:", e);
        // Try to recover
        const rawTokens = $("#Get_Tokens").val();
        id = Array.isArray(rawTokens) ? rawTokens : 
             (typeof rawTokens === 'string' ? rawTokens.split(',') : []);
    }
    // //console.log($("#SpotToken").val())
    // Process spot/index price
    if (feedData.feeds[spotToken]) {
        // //console.log(feedData.feeds[spotToken])
        processSpotData(feedData.feeds[spotToken], symbType, digiToShow);
    }
    
    // Process future token
    const futureTokens = $("#FutureToken").val().split('&');
    // console.log(futureTokens)
    // console.log(feedData)
    for(var i = 0;i<futureTokens.length;i++){
        futureToken=futureTokens[i]
        if (feedData.feeds[futureToken]) {
            processFutureData(feedData.feeds[futureToken], symbType, digiToShow,futureToken);
        }
    }
    // Create a batch of updates for option data
    let optionUpdates = [];
    
    // Process each option token with improved token matching
    Object.entries(feedData.feeds).forEach(([token, data]) => {
        // Try to match with id array
        let matched = id.includes(token);
        // console.log(matched)
        
        // If no match, try with normalized token
        if (!matched) {
            const normalizedToken = getNormalizedToken(token);
            matched = id.some(t => getNormalizedToken(t) === normalizedToken);
        }
        
        // console.log(id.length)
        // If matched or no id array, add to updates
        if (matched ) {
            optionUpdates.push({token, data, digiToShow});
        }
    });
    
    // console.log(optionUpdates)
    // Log token matching stats occasionally
    if (Math.random() < 0.01) { // Log only 1% of the time to avoid console spam
        ////console.log(`Token matching: ${optionUpdates.length} updates from ${Object.keys(feedData.feeds).length} feeds`);
    }
    
    // //////console.log(optionUpdates)
    // Apply all option updates in batch
    if (optionUpdates.length > 0) {
        batchProcessOptionData(optionUpdates);
    }
    
    // Update timestamp occasionally
    if (Math.random() < 0.1) {
        updateLastUpdatedTime();
    }
}

















// Add this debugging code to verify what's being subscribed
function debugSubscriptions() {
    //////console.log("===== SUBSCRIPTION DEBUG =====");
    
    // Check stored tokens
    const spotToken = $("#SpotToken").val();
    const futureToken = $("#FutureToken").val();
    const getTokens = $("#Get_Tokens").val();
    
    //////console.log("SpotToken:", spotToken);
    //////console.log("FutureToken:", futureToken);
    //////console.log("Get_Tokens:", getTokens);
    
    // Check the ID field which should contain options tokens
    const idValue = $("#Id").val();
    try {
        const parsedId = idValue ? JSON.parse(idValue) : [];
        //////console.log("Parsed ID tokens:", parsedId);
        //////console.log("Number of tokens in ID:", parsedId.length);
        
        // Show sample tokens if available
        if (parsedId.length > 0) {
            //////console.log("Sample tokens:", parsedId.slice(0, 3));
        }
    } catch (e) {
        console.error("Error parsing ID value:", e);
        //////console.log("Raw ID value:", idValue);
    }
    
    // Check WebSocket state
    if (window.ws) {
        const readyState = window.ws.readyState;
        const stateNames = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"];
        //////console.log("WebSocket state:", stateNames[readyState]);
    } else {
        //////console.log("WebSocket not initialized");
    }
    
    // Check STATE object for subscribed instruments
    if (window.STATE) {
        //////console.log("STATE.instrumentKeys:", window.STATE.instrumentKeys);
        //////console.log("Number of instruments in STATE:", window.STATE.instrumentKeys.length);
    }
    
    ////////console.log("==== END SUBSCRIPTION DEBUG ====");
}

// Run this debug after WebSocket connects
window.addEventListener('websocket_connected', debugSubscriptions);

// Fixed subscribeToDataFeeds function to properly handle option tokens
function subscribeToDataFeeds() {
    ////////console.log("Attempting to subscribe to data feeds");
    
    if (!window.ws || window.ws.readyState !== WebSocket.OPEN) {
        console.warn("WebSocket not ready, scheduling retry");
        setTimeout(subscribeToDataFeeds, 1000);
        return;
    }
    
    // Get tokens with better error handling
    const spotToken = $("#SpotToken").val();
    const futureToken = $("#FutureToken").val();
    
    // Get options tokens - this is the critical part that may be failing
    let optionTokens = [];
    try {
        // First try to get from Get_Tokens
        const getTokensValue = $("#Get_Tokens").val();
        
        if (getTokensValue) {
            if (Array.isArray(getTokensValue)) {
                optionTokens = getTokensValue;
            } else if (typeof getTokensValue === 'string') {
                // Could be a comma-separated string or a single token
                optionTokens = getTokensValue.includes(',') ? 
                    getTokensValue.split(',') : [getTokensValue];
            }
        }
        
        // If that didn't work, try from Id field
        if (optionTokens.length === 0) {
            const idValue = $("#Id").val();
            if (idValue) {
                const parsedId = JSON.parse(idValue);
                if (Array.isArray(parsedId)) {
                    optionTokens = parsedId;
                }
            }
        }
        
        // If we still don't have tokens, try one more method
        if (optionTokens.length === 0) {
            // Try to get from data attributes in the DOM
            const ceTokens = new Set();
            const peTokens = new Set();
            
            $('[data-ce-token]').each(function() {
                const token = $(this).attr('data-ce-token');
                if (token) ceTokens.add(token);
            });
            
            $('[data-pe-token]').each(function() {
                const token = $(this).attr('data-pe-token');
                if (token) peTokens.add(token);
            });
            
            optionTokens = [...ceTokens, ...peTokens].filter(t => t);
        }
    } catch (e) {
        console.error("Error processing option tokens:", e);
    }
    
    //////console.log(`Found tokens: Spot=${spotToken ? 'Yes' : 'No'}, Future=${futureToken ? 'Yes' : 'No'}, Options=${optionTokens.length}`);
    
    // Subscribe to spot token
    if (spotToken) {
        try {
            //////console.log("Subscribing to spot token:", spotToken);
            subscribeTo([spotToken]);
        } catch (e) {
            console.error("Error subscribing to spot token:", e);
        }
    }
    
    // Subscribe to future token after a small delay
    setTimeout(() => {
        if (futureToken) {
            futureTokenSplit=futureToken.split('&')
            for(var i = 0;i<futureTokenSplit.length;i++){
                try {
                    //////console.log("Subscribing to future token:", futureToken);
                    subscribeTo([futureTokenSplit[i]]);
                } catch (e) {
                    console.error("Error subscribing to future token:", e);
                }
            }
        }
    }, 100);
    
    // Subscribe to option tokens after a delay
    setTimeout(() => {
        if (optionTokens.length > 0) {
            try {
                //////console.log(`Subscribing to ${optionTokens.length} option tokens`);
                
                // Subscribe in batches of 100 to avoid overwhelming the WebSocket
                const batchSize = 100;
                for (let i = 0; i < optionTokens.length; i += batchSize) {
                    const batch = optionTokens.slice(i, i + batchSize);
                    //////console.log(`Subscribing to batch ${i/batchSize + 1}:`, batch.length, "tokens");
                    
                    // Subscribe with a small delay between batches
                    setTimeout(() => {
                        subscribeTo(batch);
                    }, (i/batchSize) * 50);
                }
            } catch (e) {
                console.error("Error subscribing to option tokens:", e);
            }
        } else {
            console.warn("No option tokens found to subscribe to!");
            
            // If we couldn't find option tokens, log details to help debug
            ////console.log("Get_Tokens value:", $("#Get_Tokens").val());
            ////console.log("Id value:", $("#Id").val());
            ////console.log("DOM CE tokens:", $('[data-ce-token]').length);
            ////console.log("DOM PE tokens:", $('[data-pe-token]').length);
        }
    }, 200);
}

// Improved subscribeTo function with better error handling
function subscribeTo(keys) {
    if (!window.ws) {
        console.error('WebSocket not initialized');
        return;
    }
    
    if (window.ws.readyState !== WebSocket.OPEN) {
        console.error('WebSocket not open, state:', window.ws.readyState);
        return;
    }
    
    if (!keys || keys.length === 0) {
        console.error('No keys provided for subscription');
        return;
    }
    
    // Make sure keys is an array of strings
    const processedKeys = keys.map(key => 
        typeof key === 'string' ? key : String(key)
    ).filter(key => key && key.trim() !== '');
    
    if (processedKeys.length === 0) {
        console.error('No valid keys after processing');
        return;
    }
    
    try {
        ////console.log(`Sending subscription for ${processedKeys.length} keys`);
        
        // Format prefix if needed
        const symbType = $("#SymbType").val() || 'NSE';
        const formattedKeys = processedKeys.map(key => {
            // Skip if it already has a prefix
            if (key.includes('_FO|')) return key;
            
            // Add prefix based on symbol type
            
            if(key.includes('NSE_INDEX')) return key;
            if (symbType === "BSE") return 'BSE_FO|' + key;
            if (symbType === "CUR") return 'NCD_FO|' + key;
            if (symbType === "MCX") return 'MCX_FO|' + key;
            return 'NSE_FO|' + key;
        });
        
        // Log sample keys for debugging
        ////console.log("Sample keys being subscribed:", formattedKeys.slice(0, 3));
        
        // Store in STATE for tracking
        if (window.STATE) {
            window.STATE.instrumentKeys = 
                window.STATE.instrumentKeys.concat(formattedKeys);
        }

        // //console.log(formattedKeys)
        // Send the subscription request
        const requestData = {
            guid: "someguid",
            method: "sub",
            data: {
                mode: "full",
                instrumentKeys: formattedKeys
            }
        };
        
        const buffer = new TextEncoder().encode(JSON.stringify(requestData)).buffer;
        //console.log(buffer)
        window.ws.send(buffer);
        
        ////console.log(`Subscription request sent for ${formattedKeys.length} keys`);
    } catch (error) {
        console.error('Error sending subscription request:', error);
    }
}

// Add this to handleOptionChainData to ensure tokens are properly formatted
function handleOptionChainData(data) {
    ////console.log('Handling option chain data');
    
    if (!data) {
        console.error('No data received from server');
        return;
    }
    
    // Extract token data with fallbacks
    const strikeArray = data.TotalATMvalues || data.strikeArray || [];
    const Id = data.Id || '';
    const Get_Tokens = data.Get_Tokens || data.tokens || '';
    const lot = data.lot || 75;
    const multiplier = data.multiplier || 1;
    const FutureToken = data.FutureToken || '';
    const CE_Tokens = data.CE_Tokens || [];
    const PE_Tokens = data.PE_Tokens || [];
    const SpotToken_upstox = data.SpotToken_upstox || data.SpotToken || '';
    const strike_diff = data.strike_diff || 50;
    const expiryWise = data.expiryWise || {};
    
    ////console.log(`Processing data: ${strikeArray.length} strikes, ${CE_Tokens.length} CE tokens, ${PE_Tokens.length} PE tokens`);
    
    // Store values in hidden fields
    $("#lot").val(lot);
    $("#multiplier").val(multiplier);
    $("#StrikePriceArray").val(Array.isArray(strikeArray) ? strikeArray.join(',') : strikeArray);
    $("#Idforstrike").val(Id);
    
    // *** THIS IS THE CRITICAL PART FOR FIXING THE SUBSCRIPTION ISSUE ***
    
    // Combine CE and PE tokens
    const allOptionTokens = [...CE_Tokens, ...PE_Tokens].filter(t => t);
    
    // //console.log(`Total option tokens: ${allOptionTokens.length}`);
    
    // Store tokens in a format that can be used for subscription
    if (allOptionTokens.length > 0) {
        $("#Get_Tokens").val(allOptionTokens);
        
        // Also store as JSON string in Id field for backward compatibility
        $("#Id").val(JSON.stringify(allOptionTokens));
        
        ////console.log(`Stored ${allOptionTokens.length} option tokens for subscription`);
    } else {
        console.warn("No option tokens found in the data!");
    }
    
    // Set spot and future tokens
    $("#SpotToken").val(SpotToken_upstox);
    
    if (FutureToken) {
        setFutureToken(FutureToken,data.FutureNames,data.FutureExpiry);
    }
    for (const [key, value] of Object.entries(expiryWise)) {
        setTimeout(() => {
                
            renderOptionsTable(value.strikes, value.ceToken, value.peToken,key,value.data);
        }, 500);
    }
    
    // Subscribe to data feeds if WebSocket is ready
    if (window.ws && window.ws.readyState === WebSocket.OPEN) {
        ////console.log("WebSocket ready, subscribing to data feeds");
        subscribeToDataFeeds();
    } else {
        ////console.log("WebSocket not ready, will subscribe when connected");
        
        // Setup a listener for when the WebSocket connects
        window.addEventListener('websocket_connected', function() {
            ////console.log("WebSocket connected event received, subscribing to data feeds");
            subscribeToDataFeeds();
        }, { once: true });
    }
    
    // Mark data as loaded
    if (window.STATE) {
        window.STATE.dataLoaded = true;
    }
    
    // Debug subscription status
    debugSubscriptions();
}

// Add this event dispatcher to connectWebSocket
function connectWebSocket(url) {
    return new Promise((resolve, reject) => {
        if (!url) {
            console.error('Invalid WebSocket URL');
            return reject(new Error("Invalid WebSocket URL"));
        }
        
        try {
            ////console.log("Connecting to WebSocket...");
            const ws = new WebSocket(url);
            
            ws.onopen = function() {
                ////console.log("WebSocket connected successfully!");
                
                // Set state and dispatch event
                if (window.STATE) {
                    window.STATE.wsReady = true;
                    window.STATE.reconnectAttempts = 0;
                }
                
                // Dispatch custom event that other functions can listen for
                window.dispatchEvent(new CustomEvent('websocket_connected'));
                
                resolve();
            };
            
            ws.onerror = function(error) {
                console.error("WebSocket error:", error);
                if (window.STATE) {
                    window.STATE.wsReady = false;
                }
                reject(error);
            };
            
            ws.onclose = function() {
                ////console.log("WebSocket closed");
                if (window.STATE) {
                    window.STATE.wsReady = false;
                }
                
                // Dispatch event
                window.dispatchEvent(new CustomEvent('websocket_disconnected'));
                
                // Schedule reconnection
                setTimeout(initializeWebSocketAsync, 1000);
            };
            
            ws.onmessage = async function(event) {
                try {
                    const buffer = new Uint8Array(await blobToArrayBuffer(event.data));
                    const response = decodeProtobuf(buffer);
                    // console.log(response)
                    if (response) {
                        // console.log(JSON.parse(JSON.stringify(response)))
                        // Process the message
                        streamCb(JSON.parse(JSON.stringify(response)));
                    }
                } catch (error) {
                    console.error('Error processing WebSocket message:', error);
                }
            };
            
            // Store WebSocket instance globally
            window.ws = ws;
        } catch (error) {
            console.error('Error creating WebSocket:', error);
            reject(error);
        }
    });
}

// Add this function to manually test the subscription
function testOptionSubscription() {
    ////console.log("Testing option subscription...");
    
    // Check if we have option tokens
    let optionTokens = [];
    
    try {
        const getTokensValue = $("#Get_Tokens").val();
        if (getTokensValue) {
            if (Array.isArray(getTokensValue)) {
                optionTokens = getTokensValue;
            } else if (typeof getTokensValue === 'string') {
                optionTokens = getTokensValue.includes(',') ? 
                    getTokensValue.split(',') : [getTokensValue];
            }
        }
        
        if (optionTokens.length === 0) {
            const idValue = $("#Id").val();
            if (idValue) {
                const parsedId = JSON.parse(idValue);
                if (Array.isArray(parsedId)) {
                    optionTokens = parsedId;
                }
            }
        }
    } catch (e) {
        console.error("Error getting option tokens:", e);
    }
    
    if (optionTokens.length === 0) {
        console.error("No option tokens found for testing!");
        
        // Create some sample tokens for testing
        const symbol = $("#symbol").val() || "NIFTY";
        const sampleTokens = [];
        
        // Generate some sample token IDs
        for (let i = 0; i < 10; i++) {
            const strike = 22500 + (i * 50);
            sampleTokens.push(`${symbol}${strike}CE`);
            sampleTokens.push(`${symbol}${strike}PE`);
        }
        
        optionTokens = sampleTokens;
        ////console.log("Created sample tokens for testing:", sampleTokens);
    }
    
    // Subscribe to the first few tokens as a test
    const testTokens = optionTokens.slice(0, 10);
    ////console.log("Subscribing to test tokens:", testTokens);
    
    if (window.ws && window.ws.readyState === WebSocket.OPEN) {
        subscribeTo(testTokens);
        ////console.log("Test subscription sent");
    } else {
        console.error("WebSocket not ready for test subscription");
    }
}

// Call this function after WebSocket is connected
window.addEventListener('websocket_connected', function() {
    // Wait a moment before running the test
    setTimeout(testOptionSubscription, 2000);
}, { once: true });

// Improved findClosestStrike function with better handling of edge cases
function findClosestStrike(strikes, targetPrice) {
    if (!strikes || !strikes.length) return 0;
    if (!targetPrice) return strikes[0];
    
    // Convert targetPrice to a number if it's not already
    targetPrice = parseFloat(targetPrice);
    
    // Sort strikes numerically (in case they're not already sorted)
    const sortedStrikes = [...strikes].sort((a, b) => parseFloat(a) - parseFloat(b));
    
    // Find the strike price that is closest to the target price
    return sortedStrikes.reduce((prev, curr) => {
        // Convert strike prices to numbers if they're strings
        prev = parseFloat(prev);
        curr = parseFloat(curr);
        
        // Return the closer strike price
        return Math.abs(curr - targetPrice) < Math.abs(prev - targetPrice) ? curr : prev;
    });
}

// Helper function to format date for display (YYYY-MM-DD to DD-MMM-YYYY)
function formatDateForDisplay(dateStr) {
    if (!dateStr) return '-';
    
    try {
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return dateStr; // Return as is if invalid
        
        const day = date.getDate().toString().padStart(2, '0');
        const month = date.toLocaleString('default', { month: 'short' }).toUpperCase();
        const year = date.getFullYear();
        
        return `${day}-${month}-${year}`;
    } catch (e) {
        console.error('Error formatting date:', e);
        return dateStr;
    }
}


// Add event handler for position checkboxes
$(document).on('change', '.position-toggle', function() {
    const index = $(this).data('index');
    const isEnabled = $(this).prop('checked');
    
    if (index >= 0 && index < STATE.positions.length) {
        STATE.positions[index].enabled = isEnabled;
        
        // Update chart and calculations when a position is toggled
        scheduleChartUpdate();
        
        // Show notification
        const status = isEnabled ? 'enabled' : 'disabled';
        const position = STATE.positions[index];
        showNotification(`${position.strike} ${position.optType} position ${status}`, 'info', 2000);
    }
});




// Helper function to format date for display (YYYY-MM-DD to DD-MMM-YYYY)
function formatDateForDisplay(dateStr) {
    if (!dateStr) return '-';
    
    try {
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return dateStr; // Return as is if invalid
        
        const day = date.getDate().toString().padStart(2, '0');
        const month = date.toLocaleString('default', { month: 'short' }).toUpperCase();
        const year = date.getFullYear();
        
        return `${day}-${month}-${year}`;
    } catch (e) {
        console.error('Error formatting date:', e);
        return dateStr;
    }
}

// Helper function to format expiry for display
function formatExpiryForDisplay(expiryStr) {
    if (!expiryStr) return '-';
    
    // If it's already in the format like "27MAR25" just return it
    if (/^\d{2}[A-Z]{3}\d{2}/.test(expiryStr)) {
        return expiryStr;
    }
    
    // Otherwise, convert from YYYY-MM-DD format
    try {
        const date = new Date(expiryStr);
        if (isNaN(date.getTime())) return expiryStr; // Return as is if invalid
        
        const day = date.getDate().toString().padStart(2, '0');
        const month = date.toLocaleString('default', { month: 'short' }).toUpperCase();
        const year = date.getFullYear().toString().slice(-2); // Last 2 digits
        
        return `${day}${month}${year}`;
    } catch (e) {
        console.error('Error formatting expiry:', e);
        return expiryStr;
    }
}
// Additional functions needed for position management

// Exit a position
function exitPosition(index,lots,price) {
    if (index < 0 || index >= STATE.positions.length) {
        console.error('Invalid position index:', index);
        return;
    }
    
    // Get current spot price or use a default
    const spotPrice = parseFloat($("#SpotPriceDataNew").text() || "0");
    
    originalPosition=STATE.positions[index]
    if(lots<originalPosition.lots){

        // Clone the position
        const position = {...STATE.positions[index]};
        
        // Change action to the opposite (Buy → Sell, Sell → Buy)
        position.lots = lots
        STATE.positions[index].lots-=lots
        
        // Use current market price as exit price
        position.exitPrice = price;
        
        // Add the exit position
        addPosition(position);
        
    }else if(lots==originalPosition.lots){
        STATE.positions[index].exitPrice = price;
        updatePositionsTable(true)
    }
    // Remove the original position (optional - you may want to keep it for history)
    // deletePosition(index);
}
function generateAreaRangeData() {
    const zeroData = generatezeros();
    const plData = generatePLData();
    const rangeData = [];

    for (let i = 0; i < plData.length; i++) {
        rangeData.push({
            x: plData[i][0],
            low: 0,
            high: plData[i][1]
        });
    }

    return rangeData;
}


function initHighcharts() {
    // Check if Highcharts is available
    if (typeof Highcharts === 'undefined') {
        console.error('Highcharts library not loaded');
        showNotification('Chart library not available', 'error');
        return;
    }
    
    // Check if the chart container exists
    const chartContainer = document.getElementById('highcharts-container');
    if (!chartContainer) {
        console.error('Chart container not found');
        return;
    }
    
    // Get current price for the initial plot line
    const currentPrice = parseFloat($("#SpotPriceDataNew").text() || 0);
    
    // Initialize the P/L chart
    Highcharts.chart('highcharts-container', {
        chart: {
            type: 'line',
            height: 300,
            zoomType: 'x',
            backgroundColor: '#2a2a2a',
            animation: false // Disable animations for better performance
        },
        title: {
            text: 'Profit/Loss at Expiry',
            style: {
                fontSize: '14px',
                color: '#ffffff'
            }
        },
        xAxis: {
            title: {
                text: 'Price',
                style: {
                    color: '#cccccc'
                }
            },
            plotLines: [{
                id: 'spot-ltp-line',
                color: '#FF9900', // Bright orange for better visibility
                width: 2,
                value: currentPrice,
                zIndex: 5,
                dashStyle: 'solid',
                label: {
                    text: `Spot LTP: ${currentPrice.toFixed(2)}`,
                    align: 'right',
                    rotation: 0,
                    y: 15,
                    style: {
                        color: '#FF9900',
                        fontWeight: 'bold'
                    }
                }
            }],
            labels: {
                style: {
                    color: '#cccccc'
                }
            },
            gridLineColor: '#3a3a3a'
        },
        yAxis: {
            title: {
                text: 'P/L (₹)',
                style: {
                    color: '#cccccc'
                }
            },
            plotLines: [{
                color: '#808080',
                width: 1,
                value: 0
            }],
            labels: {
                style: {
                    color: '#cccccc'
                },
                formatter: function() {
                    return formatIndianNumber(Math.round(this.value)); // Format to one decimal place
                }
            },
            gridLineColor: '#3a3a3a'
        },
        tooltip: {
            headerFormat: '<b>Price: {point.x:.2f}</b><br/>',
            pointFormat: '{series.name}: ₹{point.y:.2f}<br>',
            backgroundColor: '#333',
            borderColor: '#444',
            style: {
                color: '#ffffff'
            },shared:true
        },
        legend: {
            enabled: true,
            itemStyle: {
                color: '#cccccc'
            }
        },
        plotOptions: {
            line: {
                marker: {
                    enabled: false
                },
                animation: false // Disable animations for better performance
            }
        },
        series: [{
            name: 'P/L at Expiry',
            data: generatePLData(),
            zones: [{
                value: 0,
                color: '#FF6060'
            }, {
                color: '#60FF60'
            }]
        }, {
            name: 'P/L Today',
            data: generatePLDataToday(),
            dashStyle: 'shortdash',
            zones: [{
                value: 0,
                color: '#FF6060'
            }, {
                color: '#60FF60'
            }]
        }, {
            name: 'Zero',
            data: generatezeros(),
            color: '#333',
            enableMouseTracking: false,
        },{
            name: 'P/L Area',
            type: 'arearange',
            data: generateAreaRangeData(), // This function will return [{x, low, high}, ...]
            color: undefined,
            lineWidth: 0,
            enableMouseTracking: false,
            fillOpacity: 0.3,
            zIndex: 0,
            zones: [{
                value: 0,
                color: '#FF6060'
            }, {
                color: '#60FF60'
            }]
        }
        ]
    });
    
    // Store chart instance globally for easier access
    window.optionChart = Highcharts.charts[Highcharts.charts.length - 1];
}


// Enhanced function to update the spot price line whenever spot price changes
function updateSpotPriceLine() {
    // Get the current spot price
    const spotPrice = parseFloat($("#SpotPriceDataNew").text() || 0);
    
    // Check if we have a valid price and chart instance
    if (spotPrice && window.optionChart) {
        // Remove existing spot price line
        const axis = window.optionChart.xAxis[0];
        axis.removePlotLine('spot-ltp-line');
        
        // Add updated spot price line
        axis.addPlotLine({
            id: 'spot-ltp-line',
            color: '#FF9900',  // Bright orange for better visibility
            width: 2,
            value: spotPrice,
            zIndex: 5,
            dashStyle: 'solid',
            label: {
                text: `Spot LTP: ${spotPrice.toFixed(2)}`,
                align: 'right',
                rotation: 0,
                y: 15,
                style: {
                    color: '#FF9900',
                    fontWeight: 'bold'
                }
            }
        });
    }
}



// Make sure the spot price line is updated periodically even if there are no trades
setInterval(updateSpotPriceLine, 5000); // Update every 5 seconds

// Function to calculate days between two dates
function daysBetween(date1, date2) {
    // Convert both dates to milliseconds
    const date1_ms = date1.getTime();
    const date2_ms = date2.getTime();
    
    // Calculate the difference in milliseconds
    const difference_ms = Math.abs(date1_ms - date2_ms);
    
    // Convert back to days and return
    return Math.ceil(difference_ms / (1000 * 60 * 60 * 24));
  }
  
  // Function to get days until expiry
  function getDaysUntilExpiry() {
    // Get current active expiry tab
    const activeExpiry = $('.expiry-tab.active').text();
    
    if (!activeExpiry) {
      return 30; // Default to 30 days if no expiry is selected
    }
    
    // Parse the expiry date from the tab text (format like "27MAR25(M)")
    const day = parseInt(activeExpiry.substring(0, 2));
    const monthStr = activeExpiry.substring(2, 5);
    const year = parseInt("20" + activeExpiry.substring(5, 7));
    
    // Convert month string to month number (0-11)
    const months = {
      "JAN": 0, "FEB": 1, "MAR": 2, "APR": 3, "MAY": 4, "JUN": 5,
      "JUL": 6, "AUG": 7, "SEP": 8, "OCT": 9, "NOV": 10, "DEC": 11
    };
    
    const month = months[monthStr];
    
    if (isNaN(day) || month === undefined || isNaN(year)) {
      return 30; // Default to 30 days if parsing fails
    }
    
    // Create date objects
    const expiryDate = new Date(year, month, day);
    const today = new Date();
    
    // Calculate days between
    return daysBetween(today, expiryDate);
  }
  
  // Function to calculate dynamic price range
  function calculatePriceRange() {
    // Get current index LTP
    const indexLTP = parseFloat($("#SpotPriceDataNew").text() || $("#indexLTP").text() || 22900);
    
    // Get days until expiry
    const daysToExpiry = getDaysUntilExpiry();
    
    // Calculate range width based on days to expiry
    // More days means wider range to account for potential price movement
    // Scale factor: sqrt of days gives a reasonable scaling (not linear)
    const scaleFactor = Math.max(1, Math.sqrt(daysToExpiry));
    
    // Base range: 200 points * scale factor
    const rangeWidth = Math.ceil(200 * scaleFactor);
    
    // Calculate start and end prices
    const startPrice = Math.floor(indexLTP - rangeWidth);
    const endPrice = Math.ceil(indexLTP + rangeWidth);
    
    return {
      startPrice: startPrice,
      endPrice: endPrice,
      step: 1 // Adjust step size based on range width
    };
  }
  
// Generate P/L data at expiry for all strategies including calendar spreads
function generatezeros() {
   
    var data = [];
    
    // Get dynamic price range
    const { startPrice, endPrice, step } = calculatePriceRange();
    // //console.log(calculatePriceRange())
    // Group positions by expiry date to identify calendar spreads
    var expiryGroups = {};
    for (let price = startPrice; price <= endPrice; price += step) {
        let totalPL = 0;
            
    
        data.push([price, totalPL]);
    }

    return data;
}
// Generate P/L data at expiry for all strategies including calendar spreads
function generatePLData() {
    var positions = STATE.positions.filter(pos => pos.enabled !== false&pos.exitPrice==undefined); // Only use enabled positions
    var Exitedpositions = STATE.positions.filter(pos => pos.enabled !== false&pos.exitPrice!=undefined); // Only use enabled positions

    exitedPNL=0
    Exitedpositions.forEach((position)=>{
        exitedPNL+=(position.exitPrice - position.entryPrice) * position.lots * position.lotSize*(position.action === 'Buy' ? 1 : -1)
    })
    var data = [];
    // //console.log(calculatePriceRange())
    
    // Get dynamic price range
    const { startPrice, endPrice, step } = calculatePriceRange();
    
    // Group positions by expiry date to identify calendar spreads
    var expiryGroups = {};
    positions.forEach(pos => {
        if(pos.optType=='FUTURE'){

        }else{
            if (!expiryGroups[pos.expiry]) {
                expiryGroups[pos.expiry] = [];
            }
            expiryGroups[pos.expiry].push(pos);

        }
    });
    
    // Sort expiry dates
    var sortedExpiries = Object.keys(expiryGroups).sort((a, b) => {
        return new Date(a) - new Date(b);
    });
    
    // Get the earliest expiry date
    var earliestExpiry = sortedExpiries.length > 0 ? sortedExpiries[0] : null;
    
    for (let price = startPrice; price <= endPrice; price += step) {
        let totalPL = exitedPNL;
        
        // Handle each position based on expiry
        positions.forEach(position => {
            let positionPL = 0;
            
            // For positions expiring at the earliest date, calculate expiry value
            if (earliestExpiry && position.expiry === earliestExpiry) {
                if (position.optType === "CE") {
                    // For Call options
                    if (price > position.strike) {
                        positionPL = (price - position.strike) * position.lots * position.lotSize - position.entryPrice * position.lots * position.lotSize;
                    } else {
                        positionPL = -position.entryPrice * position.lots * position.lotSize;
                    }
                } else if (position.optType === "PE") {
                    // For Put options
                    if (price < position.strike) {
                        positionPL = (position.strike - price) * position.lots * position.lotSize - position.entryPrice * position.lots * position.lotSize;
                    } else {
                        positionPL = -position.entryPrice * position.lots * position.lotSize;
                    }
                } else if (position.optType === "FUTURE") {
                    // For Put options
                    positionPL = (price-position.entryPrice)* position.lots * position.lotSize
                }
            } 
            else {
                // Calculate days to expiry from earliest expiry date to this position's expiry
                var earliestDate = new Date(earliestExpiry);
                var positionDate = new Date(position.expiry);
                var daysToExpiry = Math.max(1, Math.ceil((positionDate - earliestDate) / (1000 * 60 * 60 * 24)));
                
                // Convert to years for Black-Scholes
                var T = daysToExpiry / 365;
                var r = 0.05; // Risk-free rate
                var volatility = position.IV / 100;
                
                // Use the external Black-Scholes library
                let optionValue;
                
                try {
                    var bsholder = new BSHolder(price, position.strike, r, volatility, T);
                    
                    if (position.optType === "CE") {
                        optionValue = BS.call(bsholder);
                    }  else if (position.optType === "FUTURE") {
                        // For Put options
                        optionValue=price
                    }else {
                        optionValue = BS.put(bsholder);
                    }
                } catch (e) {
                    // Fallback calculation if BS library fails
                    console.warn("BS calculation failed, using approximation", e);
                    
                    if (position.optType === "CE") {
                        optionValue = Math.max(0, price - position.strike) + 
                            Math.max(5, position.strike * 0.01 * Math.sqrt(T));
                    } else {
                        optionValue = Math.max(0, position.strike - price) + 
                            Math.max(5, position.strike * 0.01 * Math.sqrt(T));
                    }
                }
                
                // Calculate P/L: (theoretical price - entry price) * quantity
                positionPL = (optionValue - position.entryPrice) * position.lots * position.lotSize;
            }
            
            totalPL += positionPL * (position.action === 'Buy' ? 1 : -1);
            
        });
        
        data.push([price, totalPL]);
    }
    
    return data;
}

// Generate P/L data for today's prices using external Black-Scholes library
function generatePLDataToday() {
    var positions = STATE.positions.filter(pos => pos.enabled !== false&pos.exitPrice==undefined); // Only use enabled positions
    var Exitedpositions = STATE.positions.filter(pos => pos.exitPrice!=undefined); // Only use enabled positions

    exitedPNL=0
    Exitedpositions.forEach((position)=>{
        exitedPNL+=(position.exitPrice - position.entryPrice) * position.lots * position.lotSize*(position.action === 'Buy' ? 1 : -1)
    })
    var data = [];
    
    // Get dynamic price range
    const { startPrice, endPrice, step } = calculatePriceRange();
    
    // Set risk-free rate (typically government bond yield)
    var r = 0.05; // 5% annual rate (adjust as needed)
    
    // Current underlying price
    var currentUnderlyingPrice = parseFloat($("#SpotPriceDataNew").text() || $("#indexLTP").text() || 22900);
    
    for (let price = startPrice; price <= endPrice; price += step) {
        let totalPL = exitedPNL;
        
        // Calculate P/L for each position
        positions.forEach(position => {
            // Calculate days to expiry
            var today = new Date();
            var expiryDate = new Date(position.expiry);
            var daysToExpiry = Math.max(1, Math.ceil((expiryDate - today) / (1000 * 60 * 60 * 24)));
            
            // Convert to years for Black-Scholes
            var T = daysToExpiry / 365;
            
            // Use IV from the position data
            var volatility = position.IV / 100;
            
            // Calculate theoretical price using the external Black-Scholes library
            let theoreticalPrice;
            
            try {
                var bsholder = new BSHolder(price, position.strike, r, volatility, T);
                
                if (position.optType === "CE") {
                    theoreticalPrice = BS.call(bsholder);
                } else if (position.optType === "FUTURE") {
                    theoreticalPrice = price;
                }else {
                    theoreticalPrice = BS.put(bsholder);
                }
            } catch (e) {
                // Fallback calculation if BS library fails
                console.warn("BS calculation failed, using approximation", e);
                
                // Simple approximation based on intrinsic value plus time value
                if (position.optType === "CE") {
                    // Intrinsic value
                    const intrinsic = Math.max(0, price - position.strike);
                    // Time value approximation based on volatility, time and strike
                    const timeValue = position.strike * volatility * Math.sqrt(T) * 0.4;
                    theoreticalPrice = intrinsic + timeValue;
                } else if (position.optType === "FUTURE") {
                    theoreticalPrice = price;
                }else {
                    // Intrinsic value for puts
                    const intrinsic = Math.max(0, position.strike - price);
                    // Time value approximation
                    const timeValue = position.strike * volatility * Math.sqrt(T) * 0.4;
                    theoreticalPrice = intrinsic + timeValue;
                }
            }
            
            // P/L calculation = (theoretical price - entry price) * lots * lot size
            var positionPL = (theoreticalPrice - position.entryPrice) * position.lots * position.lotSize * (position.action === 'Buy' ? 1 : -1);
            
            totalPL += positionPL;
        });
        
        data.push([price, totalPL]);
    }
    
    return data;
}

  
  // Function to update chart with dynamic x-axis
  function updateChartAxis() {
    var chart = window.optionChart || Highcharts.charts[Highcharts.charts.length - 1];
    if (!chart) return;
    
    // Get current dynamic range
    const { startPrice, endPrice } = calculatePriceRange();
    
    // Update x-axis extremes
    chart.xAxis[0].setExtremes(startPrice, endPrice);
    
    // Update chart note
    if (!chart.dynamicRangeNote) {
      chart.dynamicRangeNote = chart.renderer.text(
        'Range adapts based on LTP and days to expiry',
        chart.plotLeft,
        chart.plotTop - 5
      )
      .css({
        color: '#999',
        fontSize: '10px'
      })
      .add();
    }
  }
  
  // Enhanced update chart function to update axis
  function updateChart() {
    var chart = window.optionChart || Highcharts.charts[Highcharts.charts.length - 1];
    if (chart) {
      // Generate data with dynamic range
      chart.series[0].setData(generatePLData(), false);
      chart.series[1].setData(generatePLDataToday(), false);
      chart.series[2].setData(generatezeros(), false);
      chart.series[3].setData(generateAreaRangeData(), false);

      
      // Update x-axis range
      updateChartAxis();
      
      // Make sure the spot price line is updated
      updateSpotPriceLine();
      
      chart.redraw();
      updateMetricsDisplay();
      updateDisplay();
    }
  }
  


  

  // 1. Add a new constants section for available columns
window.COLUMN_OPTIONS = {
    CALL_SIDE: [
        { id: 'call-vega', label: 'Vega', default: false },
        { id: 'call-gamma', label: 'Gamma', default: false },
        { id: 'call-theta', label: 'Theta', default: false },
        { id: 'call-delta', label: 'Delta', default: true },
        { id: 'call-iv', label: 'IV', default: true },
        { id: 'call-oi', label: 'OI', default: false },
        { id: 'call-volume', label: 'Volume', default: false },
        { id: 'call-ltp', label: 'LTP', default: true }
    ],
    PUT_SIDE: [
        { id: 'put-ltp', label: 'LTP', default: true },
        { id: 'put-volume', label: 'Volume', default: false },
        { id: 'put-oi', label: 'OI', default: false },
        { id: 'put-iv', label: 'IV', default: true },
        { id: 'put-delta', label: 'Delta', default: true },
        { id: 'put-theta', label: 'Theta', default: false },
        { id: 'put-gamma', label: 'Gamma', default: false },
        { id: 'put-vega', label: 'Vega', default: false }
    ],
    MIDDLE: [
        { id: 'strike', label: 'Strike', default: true, required: true }
    ]
};

// 2. Add user preferences to STATE object
window.STATE.userColumns = {
    callSide: COLUMN_OPTIONS.CALL_SIDE.filter(col => col.default).map(col => col.id),
    putSide: COLUMN_OPTIONS.PUT_SIDE.filter(col => col.default).map(col => col.id),
    middle: COLUMN_OPTIONS.MIDDLE.map(col => col.id) // Always include middle columns
};

// 3. Add column selection UI creation function
function createColumnSelectionUI() {
    // Create modal container if it doesn't exist
    if (!$('#columnSelectionModal').length) {
        const modalHtml = `
        `;
        $('body').append(modalHtml);
        
        // Add CSS for the modal
        const modalCss = `
        `;
        $('head').append(modalCss);
    }
    
    // Populate column options
    // populateColumnOptions();
    
    // Set up event handlers
    setupColumnSelectionEvents();
}

// 4. Function to populate column options in the modal
function populateColumnOptions() {
    // Call Side Columns
    const callContainer = $('#callColumnsContainer');
    callContainer.empty();
    
    COLUMN_OPTIONS.CALL_SIDE.forEach(column => {
        const isChecked = STATE.userColumns.callSide.includes(column.id);
        const isDisabled = column.required;
        callContainer.append(`
            <div class="column-option ${isDisabled ? 'disabled' : ''}">
                <input type="checkbox" id="${column.id}-check" ${isChecked ? 'checked' : ''} ${isDisabled ? 'disabled' : ''}>
                <label for="${column.id}-check">${column.label}</label>
            </div>
        `);
    });
    
    // Middle (Strike) Columns
    const middleContainer = $('#middleColumnsContainer');
    middleContainer.empty();
    
    COLUMN_OPTIONS.MIDDLE.forEach(column => {
        const isChecked = STATE.userColumns.middle.includes(column.id);
        const isDisabled = column.required;
        middleContainer.append(`
            <div class="column-option ${isDisabled ? 'disabled' : ''}">
                <input type="checkbox" id="${column.id}-check" ${isChecked ? 'checked' : ''} ${isDisabled ? 'disabled' : ''}>
                <label for="${column.id}-check">${column.label}</label>
            </div>
        `);
    });
    
    // Put Side Columns
    const putContainer = $('#putColumnsContainer');
    putContainer.empty();
    
    COLUMN_OPTIONS.PUT_SIDE.forEach(column => {
        const isChecked = STATE.userColumns.putSide.includes(column.id);
        const isDisabled = column.required;
        putContainer.append(`
            <div class="column-option ${isDisabled ? 'disabled' : ''}">
                <input type="checkbox" id="${column.id}-check" ${isChecked ? 'checked' : ''} ${isDisabled ? 'disabled' : ''}>
                <label for="${column.id}-check">${column.label}</label>
            </div>
        `);
    });
}

// 5. Function to set up column selection event handlers
function setupColumnSelectionEvents() {
    // Open modal
    $('.column-settings-btn').off('click').on('click', function() {
        $('#columnSelectionModal').show();
        // populateColumnOptions(); // Refresh options
    });
    
    // Close modal
    $('.close-modal, #cancelColumnSettings').off('click').on('click', function() {
        $('#columnSelectionModal').hide();
    });
    
    // Outside click
    $(window).off('click.columnModal').on('click.columnModal', function(event) {
        if (event.target === document.getElementById('columnSelectionModal')) {
            $('#columnSelectionModal').hide();
        }
    });
    
    // Save changes
    $('#saveColumnSettings').off('click').on('click', function() {
        // Collect selected columns
        const callColumns = [];
        const putColumns = [];
        const middleColumns = [];
        
        // Get checked call side columns
        COLUMN_OPTIONS.CALL_SIDE.forEach(column => {
            if ($(`#${column.id}-check`).is(':checked') || column.required) {
                callColumns.push(column.id);
            }
        });
        
        // Get checked middle columns
        COLUMN_OPTIONS.MIDDLE.forEach(column => {
            if ($(`#${column.id}-check`).is(':checked') || column.required) {
                middleColumns.push(column.id);
            }
        });
        
        // Get checked put side columns
        COLUMN_OPTIONS.PUT_SIDE.forEach(column => {
            if ($(`#${column.id}-check`).is(':checked') || column.required) {
                putColumns.push(column.id);
            }
        });
        
        // Validate at least one column selected for each side
        if (callColumns.length === 0 || putColumns.length === 0) {
            showNotification('Please select at least one column for each side', 'error');
            return;
        }
        
        // Save user preferences
        STATE.userColumns = {
            callSide: callColumns,
            putSide: putColumns,
            middle: middleColumns
        };
        
        // Save to localStorage for persistence
        try {
            localStorage.setItem('optionChain_userColumns', JSON.stringify(STATE.userColumns));
        } catch (e) {
            console.error('Failed to save column preferences to localStorage:', e);
        }
        
        // Update the option chain tables
        updateAllOptionTables();
        
        // Close modal
        $('#columnSelectionModal').hide();
        
        // Show confirmation
        showNotification('Column settings updated', 'success');
    });
    
    // Reset to default
    $('#resetColumnSettings').off('click').on('click', function() {
        // Reset to default columns
        STATE.userColumns = {
            callSide: COLUMN_OPTIONS.CALL_SIDE.filter(col => col.default).map(col => col.id),
            putSide: COLUMN_OPTIONS.PUT_SIDE.filter(col => col.default).map(col => col.id),
            middle: COLUMN_OPTIONS.MIDDLE.map(col => col.id)
        };
        
        // Update checkboxes in modal
        // populateColumnOptions();
        
        // Save to localStorage
        try {
            localStorage.setItem('optionChain_userColumns', JSON.stringify(STATE.userColumns));
        } catch (e) {
            console.error('Failed to save default column preferences to localStorage:', e);
        }
        
        // Show notification
        showNotification('Column settings reset to default', 'info');
    });
}

// 6. Function to update all option tables with selected columns
function updateAllOptionTables() {
    // Get all expiry tabs
    const expiryTabs = $('.expiry-tab');
    
    // For each expiry tab, update its table
    expiryTabs.each(function() {
        const expiryId = $(this).attr('id').replace('-tab', '');
        updateOptionTableStructure(expiryId);
    });
    
    // If data is loaded, fetch it again with the new column structure
    if (STATE.dataLoaded) {
        const symbol = DOM.symbolSelect.val() || 'NIFTY';
        // fetchOptionChainData(symbol);
    }
}

// 7. Function to update the structure of a specific option table
function updateOptionTableStructure(expiryId) {
    // Find the table for this expiry
    const tableContainer = $(`#${expiryId}`).find('.options-table');
    if (!tableContainer.length) return;
    
    // Get the table
    const table = tableContainer.find('table');
    if (!table.length) return;
    
    // Update table header
    const headerRow = table.find('thead tr');
    headerRow.empty();
    
    // Add Call side headers
    STATE.userColumns.callSide.forEach(colId => {
        const column = COLUMN_OPTIONS.CALL_SIDE.find(col => col.id === colId);
        if (column) {
            headerRow.append(`<th class="${colId}">${column.label}</th>`);
        }
    });
    
    // Add Strike header
    headerRow.append('<th class="strike">Strike</th>');
    
    // Add Put side headers
    STATE.userColumns.putSide.forEach(colId => {
        const column = COLUMN_OPTIONS.PUT_SIDE.find(col => col.id === colId);
        if (column) {
            headerRow.append(`<th class="${colId}">${column.label}</th>`);
        }
    });
    
    // Update rows if they exist (skip if no data yet)
    const rows = table.find('tbody tr');
    if (rows.length) {
        rows.each(function() {
            updateRowStructure($(this));
        });
    }
}

// 8. Function to update a specific row's structure
function updateRowStructure(row) {
    // Extract data from row
    const ceToken = row.attr('data-ce-token');
    const peToken = row.attr('data-pe-token');
    const strike = row.find('.strike').text();
    
    // Store values from existing columns
    const values = {};
    row.find('td').each(function() {
        const cellClass = $(this).attr('class').split(' ')[0]; // Get first class as column id
        values[cellClass] = $(this).html();
    });
    // console.log(values)
    
    // Clear row
    row.empty();
    
    // Add Call side cells
    STATE.userColumns.callSide.forEach(colId => {
        var cellContent = values[colId] || '-';
        
        if(cellContent=='-'){
            newColID=colId.split('-')[1]
            // console.log(newColID)
            if(newColID=='ltp'){
                cellContent=window.DataAllOptions[ceToken].market_data.ltp
            }
            if(newColID=='oi'){
                cellContent=window.DataAllOptions[ceToken].market_data.oi
            }
            if(newColID=='volume'){
                cellContent=window.DataAllOptions[ceToken].market_data.volume
            }
            if(newColID=='iv'){
                cellContent=window.DataAllOptions[ceToken].option_greeks.iv
            }
            if(newColID=='delta'){
                cellContent=window.DataAllOptions[ceToken].option_greeks.delta
            }
            if(newColID=='theta'){
                cellContent=window.DataAllOptions[ceToken].option_greeks.theta
            }
            if(newColID=='gamma'){
                cellContent=window.DataAllOptions[ceToken].option_greeks.gamma
            }
            if(newColID=='vega'){
                cellContent=window.DataAllOptions[ceToken].option_greeks.vega
            }
        }
        row.append(`<td class="${colId} ce">${cellContent}</td>`);
    });
    
    // Add Strike cell
    row.append(`<td class="strike" style="background-color:#1e3b8b;color:white !important;">${strike}</td>`);
    
    // Add Put side cells
    STATE.userColumns.putSide.forEach(colId => {
        var cellContent = values[colId] || '-';
        if(cellContent=='-'){
            newColID=colId.split('-')[1]
            // console.log(newColID)
            if(newColID=='ltp'){
                cellContent=window.DataAllOptions[peToken].market_data.ltp
            }
            if(newColID=='oi'){
                cellContent=window.DataAllOptions[peToken].market_data.oi
            }
            if(newColID=='volume'){
                cellContent=window.DataAllOptions[peToken].market_data.volume
            }
            if(newColID=='iv'){
                cellContent=window.DataAllOptions[peToken].option_greeks.iv
            }
            if(newColID=='delta'){
                cellContent=window.DataAllOptions[peToken].option_greeks.delta
            }
            if(newColID=='theta'){
                cellContent=window.DataAllOptions[peToken].option_greeks.theta
            }
            if(newColID=='gamma'){
                cellContent=window.DataAllOptions[peToken].option_greeks.gamma
            }
            if(newColID=='vega'){
                cellContent=window.DataAllOptions[peToken].option_greeks.vega
            }
        }
        row.append(`<td class="${colId} pe">${cellContent}</td>`);
    });
}

function formatIndianNumber(num) {
    let x = num.toString().split(".");
    let intPart = x[0];
    let decPart = x.length > 1 ? "." + x[1] : "";

    let lastThree = intPart.substring(intPart.length - 3);
    let otherNumbers = intPart.substring(0, intPart.length - 3);

    if (otherNumbers !== '') {
        lastThree = ',' + lastThree;
    }

    return otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree + decPart;
}
window.DataAllOptions={}
// 9. Modify renderOptionsTable to use the selected columns
function renderOptionsTable(strikeArray, CE_Tokens, PE_Tokens, expiryTable,dataAll) {
    
    // Add more detailed logging for debugging
    //console.log(`Rendering options table for ${expiryTable} with ${strikeArray.length} strikes`);
    
    if (!strikeArray || strikeArray.length === 0) {
        console.error('No strike data available');
        return;
    }

    strike=[]
    for(var i= 0;i<strikeArray.length;i++){
        strike.push(parseFloat(strikeArray[i]))
    }
    centerStrike[expiryTable]=strike
    
    // Ensure DOM access works - first make sure the tab exists
    const tabElement = document.getElementById(`${expiryTable}-tab`);
    if (!tabElement) {
        console.error(`Tab element #${expiryTable}-tab not found in DOM`);
        return;
    }
    
    // Force the tab to be active so its content is visible
    //console.log(`Activating tab ${expiryTable}`);
    tabElement.click();
    
    // Method 1: Click the tab directly
    if (typeof $(tabElement).tab === 'function') {
        $(tabElement).tab('show');
    }
    
    // Method 2: Manual class manipulation
    $('.expiry-tab').removeClass('active');
    $(tabElement).addClass('active');
    
    // Make sure the tab content is visible
    $('.tab-pane').removeClass('show active');
    $(`#${expiryTable}`).addClass('show active');
    
    // Find the table body
    let tableBody = null;
    
    // Try multiple selectors to find the table
    tableBody = $(`#${expiryTable}_optionChain table tbody`);
    if (tableBody.length === 0) {
        tableBody = $(`#${expiryTable} .options-table table tbody`);
    }
    
    if (tableBody.length === 0) {
        tableBody = $(`#${expiryTable} table tbody`);
    }
    
    if (tableBody.length === 0) {
        // Log details about what exists in the DOM
        console.error(`Cannot find options table body for ${expiryTable}`);
        
        // Create the table if it doesn't exist
        //console.log('Attempting to create missing table structure');
        const tabContent = $(`#${expiryTable}`);
        
        if (tabContent.length > 0) {
            // Generate the table header based on selected columns
            let headerHtml = '<tr>';
            
            // Add Call side headers
            STATE.userColumns.callSide.forEach(colId => {
                const column = COLUMN_OPTIONS.CALL_SIDE.find(col => col.id === colId);
                if (column) {
                    headerHtml += `<th class="${colId}">${column.label}</th>`;
                }
            });
            
            // Add Strike header
            headerHtml += '<th class="strike">Strike</th>';
            
            // Add Put side headers
            STATE.userColumns.putSide.forEach(colId => {
                const column = COLUMN_OPTIONS.PUT_SIDE.find(col => col.id === colId);
                if (column) {
                    headerHtml += `<th class="${colId}">${column.label}</th>`;
                }
            });
            
            headerHtml += '</tr>';
            
            // Create the options table structure
            const optionsTableHtml = `
                <div class="options-table" id="${expiryTable}_optionChain">
                    <table>
                        <thead>
                            ${headerHtml}
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>`;
            
            tabContent.html(optionsTableHtml);
            tableBody = $(`#${expiryTable}_optionChain table tbody`);
            
            if (tableBody.length === 0) {
                console.error(`Failed to create and find table body even after creation`);
                return;
            }
        } else {
            console.error(`Tab content #${expiryTable} not found, cannot create table`);
            return;
        }
    }
    
    //console.log(`Found table body with ${tableBody.length} elements`);
    
    // Ensure we have arrays to work with
    const strikes = Array.isArray(strikeArray) ? 
        strikeArray.filter((v, i, a) => a.indexOf(v) === i).map(Number) :
        strikeArray.split(',').filter((v, i, a) => a.indexOf(v) === i).map(Number);
    
    // Check if tokens arrays exist
    if (!CE_Tokens || !PE_Tokens) {
        console.warn('Missing CE or PE tokens, using empty arrays as fallback');
    }
    
    // Normalize token arrays
    const ceTokens = CE_Tokens || [];
    const peTokens = PE_Tokens || [];
    
    // Create fragment for better performance
    const fragment = document.createDocumentFragment();
    
    // Get current spot price
    const spotPrice = parseFloat($('#SpotPriceDataNew').text() || '22900');
    
    // Find ATM strike
    const atmStrike = findClosestStrike(strikes, spotPrice);
    
    // Create table rows
    strikes.forEach((strike, i) => {
        const classRow = strike == atmStrike? 'highlighted' : (strike > atmStrike?'aboveAtm':'belowAtm');
        
        // Create row
        const row = document.createElement('tr');
        row.className = `option-row ${classRow }`;
        
        // Store original and normalized tokens
        let ceToken = i < ceTokens.length ? ceTokens[i] : '';
        let peToken = i < peTokens.length ? peTokens[i] : '';

        let data=dataAll[i]
        
        window.DataAllOptions[ceToken]=data.call_options
        window.DataAllOptions[peToken]=data.put_options
        // Set the tokens as data attributes
        row.setAttribute('data-ce-token', ceToken);
        row.setAttribute('data-pe-token', peToken);
        
        // Also set normalized versions for better matching
        row.setAttribute('data-ce-token-norm', getNormalizedToken(ceToken));
        row.setAttribute('data-pe-token-norm', getNormalizedToken(peToken));
        
        // Create cells based on selected columns
        let rowHtml = '';
        
        // Add Call side cells
        STATE.userColumns.callSide.forEach(colId => {
            // //console.log(colId)
            // Call columns switch
            let cellContent ='-'
            switch(colId) {
                case 'call-delta':

                    cellContent = data.call_options.option_greeks.delta;
                    // Handle Delta Greek
                    break;
                    
                case 'call-iv':
                    // Handle Implied Volatility

                    cellContent = data.call_options.option_greeks.iv;
                    break;
                    
                case 'call-oi':
                    // Handle Open Interest
                    cellContent = formatIndianNumber(data.call_options.market_data.oi);
                    break;
                    
                case 'call-volume':
                    // Handle Trading Volume
                    cellContent = formatIndianNumber(data.call_options.market_data.volume);
                    break;
                    
                case 'call-theta':
                    // Handle Theta Greek
                    cellContent = data.call_options.option_greeks.theta;
                    break;
                    
                case 'call-gamma':
                    // Handle Gamma Greek
                    cellContent = data.call_options.option_greeks.gamma;
                    break;
                    
                case 'call-vega':
                    // Handle Vega Greek
                    cellContent = data.call_options.option_greeks.vega;
                    break;
                    
                default:
                    // Unknown column ID
                    break;
            }

            
            // Special case for LTP to include trade buttons
            if (colId === 'call-ltp') {
                cellContent = `${data.call_options.market_data.ltp}
                    <div class="trade-buttons">
                        <button class="trade-btn buy-btn ce" data-strike="${strike}" data-type="CE">Buy</button>
                        <button class="trade-btn sell-btn ce" data-strike="${strike}" data-type="CE">Sell</button>
                    </div>`;
            }
            
            rowHtml += `<td class="${colId} ce">${cellContent}</td>`;
        });
        
        // Add Strike cell
        rowHtml += `<td class="expiry" style="display:none">${expiryTable}</td>`;
        rowHtml += `<td class="strike" style="background-color:#1e3b8b;color:white !important;">${strike}</td>`;
        
        // Add Put side cells
        STATE.userColumns.putSide.forEach(colId => {
            let cellContent = '-';
            
            switch(colId) {
                case 'put-delta':

                    cellContent = data.put_options.option_greeks.delta;
                    // Handle Delta Greek
                    break;
                    
                case 'put-iv':
                    // Handle Implied Volatility

                    cellContent = data.put_options.option_greeks.iv;
                    break;
                    
                case 'put-oi':
                    // Handle Open Interest
                    cellContent = formatIndianNumber(data.put_options.market_data.oi);
                    break;
                    
                case 'put-volume':
                    // Handle Trading Volume
                    cellContent = formatIndianNumber(data.put_options.market_data.volume);
                    break;
                    
                case 'put-theta':
                    // Handle Theta Greek
                    cellContent = data.put_options.option_greeks.theta;
                    break;
                    
                case 'put-gamma':
                    // Handle Gamma Greek
                    cellContent = data.put_options.option_greeks.gamma;
                    break;
                    
                case 'put-vega':
                    // Handle Vega Greek
                    cellContent = data.put_options.option_greeks.vega;
                    break;
                    
                default:
                    // Unknown column ID
                    break;
            }

            
            // Special case for LTP to include trade buttons
            if (colId === 'put-ltp') {
                cellContent = `${data.put_options.market_data.ltp}
                    <div class="trade-buttons">
                        <button class="trade-btn buy-btn pe" data-strike="${strike}" data-type="PE">Buy</button>
                        <button class="trade-btn sell-btn pe" data-strike="${strike}" data-type="PE">Sell</button>
                    </div>`;
            }
            
            rowHtml += `<td class="${colId} pe">${cellContent}</td>`;
        });
        
        row.innerHTML = rowHtml;
        fragment.appendChild(row);
    });
    
    // Clear the table before appending new rows
    tableBody.empty();
    
    // Update the table
    tableBody.append(fragment);
    
    //console.log(`Options table rendered successfully with ${strikes.length} rows for ${expiryTable}`);
    
    // Set up event handlers
    setupTradeButtonDelegation(tableBody);
    $('.expiry-tabs')[0].children[2].click()

}

// 10. Load saved column preferences
function loadColumnPreferences() {
    try {
        const savedPrefs = localStorage.getItem('optionChain_userColumns');
        if (savedPrefs) {
            const parsedPrefs = JSON.parse(savedPrefs);
            
            // Validate the parsed preferences before using them
            if (parsedPrefs && 
                Array.isArray(parsedPrefs.callSide) && 
                Array.isArray(parsedPrefs.putSide) && 
                Array.isArray(parsedPrefs.middle)) {
                
                STATE.userColumns = parsedPrefs;
                //console.log('Loaded user column preferences:', STATE.userColumns);
            }
        }
    } catch (e) {
        console.error('Error loading column preferences:', e);
    }
}

// 11. Add column settings button to UI
function addColumnSettingsButton() {
    // Check if the button already exists
    if ($('.column-settings-btn').length === 0) {
        // Find a suitable place to add the button (e.g., next to refresh button)
        const refreshBtn = $('.refresh-btn');
        if (refreshBtn.length) {
            $(`<button class="column-settings-btn" title="Customize Columns">
                <i class="fa fa-columns"></i> Columns
            </button>`).insertAfter(refreshBtn);
        } else {
            // Alternative: add to header
            $('.header-right').append(`
                <button class="column-settings-btn" title="Customize Columns">
                    <i class="fa fa-columns"></i> Columns
                </button>
            `);
        }
        
        // Add button styling
        $('<style>').text(`
            .column-settings-btn {
                padding: 5px 10px;
                background-color: #444;
                color: #fff;
                border: none;
                border-radius: 3px;
                cursor: pointer;
                margin-left: 10px;
            }
            .column-settings-btn:hover {
                background-color: #555;
            }
            .column-settings-btn i {
                margin-right: 5px;
            }
        `).appendTo('head');
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Create notification container
    createNotificationContainer();
    
    // Cache DOM elements
    DOM.init();
    
    // Load saved column preferences
    loadColumnPreferences();
    
    // Initialize UI first (fast)
    initUI();
    
    // Create column selection UI
    createColumnSelectionUI();
    
    
    // Load initial data (medium speed)
    loadInitialData();
    
    // Set up event handlers (fast)
    setupEventHandlers();
    
    // Initialize Highcharts (slower, but user doesn't need it immediately)
    setTimeout(initHighcharts, 100);
    
    // Initialize WebSocket connection (slowest, defer until everything else is ready)
    setTimeout(initializeWebSocketAsync, 500);
    
    // Set up fallback mechanism in case data doesn't load
    setTimeout(checkDataLoaded, 5000);
});

// Separated UI initialization 
function initUI() {
    // Initialize expiry tabs with mock data initially
    setupExpiryTabs(getAvailableExpiries());
    
    // Set up tab switching functionality
    initializeTabs();
    
    // Add event listeners for header buttons (without complex logic yet)
    setupActionButtons();
    
    // Show loading indicators
    updateLoadingState(true);
    
    // Initialize empty tables with placeholder data
    initializeTables();
    
    // Initialize column settings event handlers
    setupColumnSelectionEvents();
}


// 1. Create a mapping between option identifiers and position indexes
function updatePositionMap() {
    // Clear any existing position map
    window.STATE.positionMap = {};
    
    // Build a map of option identifiers to position indexes
    STATE.positions.forEach((position, index) => {
        const key = `${position.strike}${position.optType}${position.expiry}`;
        if (!window.STATE.positionMap[key]) {
            window.STATE.positionMap[key] = [];
        }
        window.STATE.positionMap[key].push(index);
    });
}

// 2. Add this function to update position current prices based on LTP changes
function updatePositionCurrentPrices(strikePrice, optionType, newPrice,expiry) {
    if (!window.STATE.positionMap) {
        updatePositionMap();
    }
    
    const key = `${strikePrice}${optionType}${expiry}`;
    
    // If we have positions matching this option
    if (window.STATE.positionMap[key] && window.STATE.positionMap[key].length > 0) {
        let updatedPositions = false;
        
        // Update all positions that match this option
        window.STATE.positionMap[key].forEach(index => {
            if (index >= 0 && index < STATE.positions.length) {
                // Only update if price actually changed
                if (STATE.positions[index].currentPrice !== newPrice) {
                    STATE.positions[index].currentPrice = newPrice;
                    updatedPositions = true;
                }
            }
        });
        
        // If we updated any positions, refresh the positions table
        if (updatedPositions) {
            debouncePositionsTableUpdate();
        }
    }
}



// 3. Modify the batchProcessOptionData function to check for positions that need updating
function batchProcessOptionData(updates) {
    // console.log(updates)
    if (!updates || updates.length === 0) {
        return;
    }
    
    // Create a map for tokens for faster lookups
    const tokenMap = {};
    
    // Build a token map to handle different formats
    $('[data-ce-token]').each(function() {
        const domToken = $(this).attr('data-ce-token');
        if (domToken) {
            // Store both the original token and a normalized version
            tokenMap[domToken] = $(this);
            tokenMap[getNormalizedToken(domToken)] = $(this);
            
            // Also store with exchange prefix variations
            ['NSE_FO|', 'BSE_FO|', 'MCX_FO|', 'NCD_FO|'].forEach(prefix => {
                tokenMap[prefix + domToken] = $(this);
            });
        }
    });
    
    $('[data-pe-token]').each(function() {
        const domToken = $(this).attr('data-pe-token');
        if (domToken) {
            // Store both the original token and a normalized version
            tokenMap[domToken] = $(this);
            tokenMap[getNormalizedToken(domToken)] = $(this);
            
            // Also store with exchange prefix variations
            ['NSE_FO|', 'BSE_FO|', 'MCX_FO|', 'NCD_FO|'].forEach(prefix => {
                tokenMap[prefix + domToken] = $(this);
            });
        }
    });
    
    // Process updates
    updates.forEach(({token, data, digiToShow}) => {
        // console.log(data)
        if (!data.fullFeed?.marketFF) return;
        
        const marketData = data.fullFeed.marketFF;
        const optionGreeks = marketData.optionGreeks;
        
        // Extract data
        const ltp = marketData.ltpc?.ltp?.toFixed(digiToShow) || "";
        const oi = marketData.eFeedDetails?.oi || "-";
        const volume = marketData?.marketOHLC?.ohlc?.[0]?.vol ?? "-";
        
        // Try various versions of the token to find a match
        const tokenVariations = [
            token,
            getNormalizedToken(token),
            token.replace('NSE_FO|', ''),
            token.replace('BSE_FO|', ''),
            token.replace('MCX_FO|', ''),
            token.replace('NCD_FO|', '')
        ];
        
        let matchedRow = null;
        let isCE = false;
        
        // Try all token variations to find a match
        for (const tokenVar of tokenVariations) {
            if (tokenMap[tokenVar]) {
                const element = tokenMap[tokenVar];
                
                // Check if this is a CE or PE row
                if (element.attr('data-ce-token') === tokenVar || 
                    element.attr('data-ce-token') === token) {
                    matchedRow = element;
                    isCE = true;
                    break;
                } else if (element.attr('data-pe-token') === tokenVar || 
                          element.attr('data-pe-token') === token) {
                    matchedRow = element;
                    isCE = false;
                    break;
                }
            }
        }
        
        // console.log(matchedRow)
        // If no match was found, try traditional lookup
        if (!matchedRow) {
            const ceRow = $(`[data-ce-token="${token}"]`);
            const peRow = $(`[data-pe-token="${token}"]`);
            
            if (ceRow.length > 0) {
                matchedRow = ceRow;
                isCE = true;
            } else if (peRow.length > 0) {
                matchedRow = peRow;
                isCE = false;
            } else {
                // More fallbacks with normalized token
                const normToken = getNormalizedToken(token);
                const ceRowNorm = $(`[data-ce-token-norm="${normToken}"]`);
                const peRowNorm = $(`[data-pe-token-norm="${normToken}"]`);
                
                if (ceRowNorm.length > 0) {
                    matchedRow = ceRowNorm;
                    isCE = true;
                } else if (peRowNorm.length > 0) {
                    matchedRow = peRowNorm;
                    isCE = false;
                }
            }
        }
        
        // If we found a match, update the fields
        if (matchedRow && matchedRow.length > 0) {
            const strike = matchedRow.find('.strike').text();
            const expiry = matchedRow.find('.expiry').text();
            const prefix = isCE ? 'call' : 'put';
            
            // Update each field based on what's available in the selected columns
            
            // LTP
            if (matchedRow.find(`.${prefix}-ltp`).length > 0) {
                matchedRow.find(`.${prefix}-ltp`).html(`${ltp}<div class="trade-buttons">
                    <button class="trade-btn buy-btn ${isCE ? 'ce' : 'pe'}" data-strike="${strike}" data-type="${isCE ? 'CE' : 'PE'}">Buy</button>
                    <button class="trade-btn sell-btn ${isCE ? 'ce' : 'pe'}" data-strike="${strike}" data-type="${isCE ? 'CE' : 'PE'}">Sell</button>
                </div>`);
                
                // NEW CODE: Update positions' current prices if we have matching positions
                // Only update if LTP is a valid number
                if (ltp && !isNaN(parseFloat(ltp))) {
                    updatePositionCurrentPrices(
                        strike, 
                        isCE ? 'CE' : 'PE', 
                        parseFloat(ltp),
                        expiry
                    );
                }
            }
            
            // Rest of the function remains the same
            // Greeks
            if (optionGreeks) {
                // Delta
                if (matchedRow.find(`.${prefix}-delta`).length > 0) {
                    matchedRow.find(`.${prefix}-delta`).text(optionGreeks.delta?.toFixed(2) || "-");
                }
                
                // IV
                if (matchedRow.find(`.${prefix}-iv`).length > 0) {
                    matchedRow.find(`.${prefix}-iv`).text(marketData.iv ? (marketData.iv * 100).toFixed(2) : "-");
                }
                
                // Additional Greeks if selected
                if (matchedRow.find(`.${prefix}-theta`).length > 0) {
                    matchedRow.find(`.${prefix}-theta`).text(optionGreeks.theta?.toFixed(2) || "-");
                }
                
                if (matchedRow.find(`.${prefix}-gamma`).length > 0) {
                    matchedRow.find(`.${prefix}-gamma`).text(optionGreeks.gamma?.toFixed(4) || "-");
                }
                
                if (matchedRow.find(`.${prefix}-vega`).length > 0) {
                    matchedRow.find(`.${prefix}-vega`).text(optionGreeks.vega?.toFixed(2) || "-");
                }
            }
            
            // OI and Volume
            if (matchedRow.find(`.${prefix}-oi`).length > 0) {
                matchedRow.find(`.${prefix}-oi`).text(formatIndianNumber(oi));
            }
            
            if (matchedRow.find(`.${prefix}-volume`).length > 0) {
                matchedRow.find(`.${prefix}-volume`).text(formatIndianNumber(volume));
            }
        }
    });
}



function updatePositionRaw(index,updateType,id){
    valueToUpdate=$('#'+id)[0].value
    if(updateType=='action'){
        updatePosition(index,{
            action:valueToUpdate
        })
    }else if(updateType=='lots'){
        updatePosition(index,{
            lots: parseFloat(valueToUpdate)
        })
    }else if(updateType=='optType'){
        updatePosition(index,{
            optType:valueToUpdate
        })
    }else if(updateType=='entryPrice'){
        updatePosition(index,{
            entryPrice: parseFloat(valueToUpdate),
        })
    }else if(updateType=='exitPrice'){
        updatePosition(index,{
            exitPrice: parseFloat(valueToUpdate),
        })
    }
    
    
}

// 4. Update the updatePositionsTable function to ensure PnL is calculated correctly
function updatePositionsTable(resetEveryting) {
    if (!DOM.positionsTable) {
        console.error('Positions table DOM element not found');
        return;
    }
    
    if(resetEveryting){

        // Clear current table
        DOM.positionsTable.empty();
    }
    
    // If no positions, show empty message
    if (STATE.positions.length === 0) {
        DOM.positionsTable.html('<tr><td colspan="12" class="text-center">No positions added yet</td></tr>');
        return;
    }
    
    // Rebuild the position map to ensure it's up to date
    updatePositionMap();
    
    // Add rows for each position
    STATE.positions.forEach(function(position, index) {
        if(position.exitPrice==undefined){
             pnl = (position.currentPrice - position.entryPrice) * position.lots * position.lotSize * (position.action === 'Buy' ? 1 : -1);
        }else{
             pnl = (position.exitPrice - position.entryPrice) * position.lots * position.lotSize * (position.action === 'Buy' ? 1 : -1);
        }
        const pnlClass = pnl >= 0 ? 'profit' : 'loss';
        
        // Format the date
        const entryDate = position.date ? position.date : new Date().toISOString().split('T')[0];
        const formattedEntryDate = formatDateForDisplay(entryDate);
        
        // Format the expiry
        const formattedExpiry = formatExpiryForDisplay(position.expiry);
        if(position.action=='Buy'){
            actionOptions='<option value="Buy" selected>Buy</option><option value="Sell">Sell</option>'
        }else{
            actionOptions='<option value="Buy" >Buy</option><option value="Sell" selected>Sell</option>'
        }
        if(position.optType=='CE'){
            optOptions='<option value="CE" selected>CE</option><option value="PE">PE</option>'
        }else if(position.optType=='FUTURE'){
            optOptions='<option value="Future" >Future</option>'
        }else {
            optOptions='<option value="CE" >CE</option><option value="PE" selected>PE</option>'
        }
        currentPriceVal=position.currentPrice.toFixed(2)
        if(position.exitPrice!=undefined){
            currentPriceVal=`<input type="number" id='${index}_exitPrice'class='form-control' style='width: 100%;'onchange="updatePositionRaw(${index},'exitPrice','${index}_exitPrice')" value="${position.exitPrice}"/>`
        }
        
        additionalClass=''
        if(position.exitPrice!=undefined){
            additionalClass='exitedPosition'
        }
        // //console.log(position.exitPrice)
        // Create row HTML
        const row = $(`
            <tr class='${additionalClass}'>
                <td><input type="checkbox" class="position-toggle" data-index="${index}" checked></td>
                <td><select id='${index}_Action'class='form-control'onchange="updatePositionRaw(${index},'action','${index}_Action')">${actionOptions}</select></td>
                <td><input type="number" id='${index}_Lots'class='form-control' style='width: 100%;'onchange="updatePositionRaw(${index},'lots','${index}_Lots')" value="${position.lots}"/></td>
                <td>${formattedEntryDate}</td>
                <td>${formattedExpiry}</td>
                <td>${position.strike}</td>
                <td><select id='${index}_OptType'class='form-control'onchange="updatePositionRaw(${index},'optType','${index}_OptType')">${optOptions}</select></td>
                <td><input type="number" id='${index}_EntryPrice' class='form-control' style='width: 100%;'onchange="updatePositionRaw(${index},'entryPrice','${index}_EntryPrice')" value="${position.entryPrice.toFixed(2)}"/></td>
                <td id='current${index}' class='${position.FutureID}'>${currentPriceVal}</td>
                <td class="${pnlClass}" id='pnl${index}'>${pnl.toFixed(2)}</td>
                <td>${position.IV.toFixed(2)}%</td>
                <td>
                    <button class="exit-btn" data-index="${index}"><i class="fas fa-sign-out-alt"></i></button>
                    <button class="delete-btn" data-index="${index}"><i class="fas fa-trash"></i></button>
                </td>
            </tr>
        `);
        

        if(resetEveryting){
            
            // Add row to table
            DOM.positionsTable.append(row);
        }else{
            $(`#pnl${index}`)[0].classList.remove("profit");
            $(`#pnl${index}`)[0].classList.remove("loss");
            $(`#pnl${index}`)[0].classList.add(pnlClass);
            $(`#pnl${index}`)[0].innerHTML=pnl.toFixed(2);
            $(`#current${index}`)[0].innerHTML=currentPriceVal;
        }
    });
    
    // Trigger an update to the chart/metrics since PnL changed
    scheduleChartUpdate();
}
// 6. Initialize the position map whenever positions change
function addPosition(position) {
    // console.log(position)
    // Validate required fields
    if (!position.strike || !position.optType || !position.action) {
        console.error('Position is missing required fields:', position);
        showNotification('Position data is incomplete', 'error');
        return;
    }
    
    // if(sta)
    // Add the position to our state
    STATE.positions.push({
        action: position.action,
        lots: position.lots || 1,
        date: position.date || new Date().toISOString().split('T')[0],
        expiry: position.expiry || $('.expiry-tab.active').text(),
        strike: parseFloat(position.strike),
        optType: position.optType,
        entryPrice: parseFloat(position.entryPrice) || 0,
        currentPrice: parseFloat(position.currentPrice) || parseFloat(position.entryPrice) || 0,
        IV: parseFloat(position.IV) || 0,
        lotSize: parseInt(position.lotSize) || parseInt($('#lot').val()) || 75,
        exitPrice: position.exitPrice,
        instrumentToken:position.instrumentToken,
        enabled: true,
        deltaOriginal:window.DataAllOptions[position.instrumentToken].option_greeks.delta,
        gammaOriginal:window.DataAllOptions[position.instrumentToken].option_greeks.gamma,
        ivOriginal:window.DataAllOptions[position.instrumentToken].option_greeks.iv,
        thetaOriginal:window.DataAllOptions[position.instrumentToken].option_greeks.theta,
        vegaOriginal:window.DataAllOptions[position.instrumentToken].option_greeks.vega,

        //// ###########################################################################3 NEEDS UPDATE###########################################################################
        delta:window.DataAllOptions[position.instrumentToken].option_greeks.delta*(position.action=='Buy'?1:-1)*position.lots,
        gamma:window.DataAllOptions[position.instrumentToken].option_greeks.gamma*(position.action=='Buy'?1:-1)*position.lots,
        iv:window.DataAllOptions[position.instrumentToken].option_greeks.iv*(position.action=='Buy'?1:-1)*position.lots,
        theta:window.DataAllOptions[position.instrumentToken].option_greeks.theta*(position.action=='Buy'?1:-1)*position.lots,
        vega:window.DataAllOptions[position.instrumentToken].option_greeks.vega*(position.action=='Buy'?1:-1)*position.lots
    });

    
    // Update the position map after adding a new position
    updatePositionMap();
    
    // Update the positions table
    updatePositionsTable(true);
    
    // Update metrics calculations
    updateMetricsDisplay();
    updateGreeksTableFromState();
    updateChart()
    
    // Return the index of the newly added position
    return STATE.positions.length - 1;
}
function updateGreeksTableFromState() {
    const tbody = document.getElementById('options-greeks-tbody');
    tbody.innerHTML = ''; // Clear existing rows

    // Totals for Portfolio Summary
    let netDelta = 0, netGamma = 0, netTheta = 0, netVega = 0, netRho = 0;

    STATE.positions
        .filter(pos => pos.enabled) // Only include enabled positions
        .forEach(pos => {
            const { action, lots, strike, optType, delta, gamma, theta, vega,iv } = pos;
            const positionSign = action.toLowerCase() === 'buy' ? 1 : -1;
            const qty = lots * pos.lotSize;

            // Calculate net Greeks
            netDelta += delta ;
            netGamma += gamma ;
            netTheta += theta; // Theta is per lot
            netVega  += vega;
            symbols=`₹${strike} ${optType === 'CE' ? 'CALL' : 'PUT'}`
            if(optType=='FUTURE'){
                symbols='Future'
            }
            // Build row
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><input type="checkbox" class="options-greek-checkbox"></td>
                <td><span class="action-${action.toLowerCase()}">${action.toUpperCase()}</span> ${lots} Lots</td>
                <td>${symbols}</td>
                <td class="greek-value">${iv.toFixed(2)}</td>
                <td class="greek-value ${delta >= 0 ? 'greek-positive' : 'greek-negative'}">${formatGreek(delta)}</td>
                <td class="greek-value ${gamma >= 0 ? 'greek-positive' : 'greek-negative'}">${formatGreek(gamma)}</td>
                <td class="greek-value ${theta >= 0 ? 'greek-positive' : 'greek-negative'}">${formatGreek(theta)}</td>
                <td class="greek-value ${vega  >= 0 ? 'greek-positive' : 'greek-negative'}">${formatGreek(vega)}</td>
                <td>₹${formatNumber(pos.currentPrice)}</td>
                <td>${calculateDaysToExpiry(pos.expiry)}</td>
            `;
            tbody.appendChild(row);
        });

    // console.log(netDelta)
    // Update Portfolio Greeks Summary
    document.querySelector('#netDelta').textContent = formatGreek(netDelta);
    document.querySelector('#netGamma').textContent = formatGreek(netGamma);
    document.querySelector('#netTheta').textContent = formatGreek(netTheta);
    document.querySelector('#netVega').textContent  = formatGreek(netVega);
}

// Utility: Format Greeks to 4 decimal places with +/-
function formatGreek(val) {
    const rounded = parseFloat(val).toFixed(4);
    return (val >= 0 ? '+' : '') + rounded;
}

// Utility: Format numbers (₹, etc.)
function formatNumber(num) {
    return parseFloat(num).toFixed(2);
}

// Utility: Days between today and expiry
function calculateDaysToExpiry(expiryStr) {
    const today = new Date();
    const expiry = new Date(expiryStr);
    const diff = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    return Math.max(diff, 0);
}

// 6. Initialize the position map whenever positions change
function buyFuture() {
    
    // if(sta)
    var selectedExpiry = $('#FuturePrices option:selected').attr('expiry');
    // console.log()
    
    FuturePrice=parseFloat($(".price-info div:nth-child(3)").text().split(': ')[1]);
    // Add the position to our state
    STATE.positions.push({
        action: 'Buy',
        lots: 1,
        date: new Date().toISOString().split('T')[0],
        expiry: selectedExpiry || $('.expiry-tab.active').text(),
        strike: '',
        optType: 'FUTURE',
        FutureID: $('#FuturePrices').val(),
        entryPrice: FuturePrice,
        currentPrice: FuturePrice,
        IV: 0,
        lotSize: parseInt($('#lot').val()) || 75,
        exitPrice: undefined,
        enabled: true,
        instrumentToken:'NSE_FO|'+$('#FuturePrices option:selected').attr('value'),
        delta:1,
        gamma:0,
        iv:0,
        theta:0,
        vega:0,
        deltaOriginal:1,
        gammaOriginal:0,
        ivOriginal:0,
        thetaOriginal:0,
        vegaOriginal:0
    });
    
    // Update the position map after adding a new position
    updatePositionMap();
    
    // Update the positions table
    updatePositionsTable(true);
    
    // Update metrics calculations
    updateMetricsDisplay();
    updateGreeksTableFromState();
    updateChart()
    // updateChart()
    // Return the index of the newly added position
    return STATE.positions.length - 1;
}

// 6. Initialize the position map whenever positions change
function sellFuture() {
    
    // if(sta)
    var selectedExpiry = $('#FuturePrices option:selected').attr('expiry');
    
    FuturePrice=parseFloat($(".price-info div:nth-child(3)").text().split(': ')[1]);
    // Add the position to our state
    STATE.positions.push({
        action: 'Sell',
        lots: 1,
        date: new Date().toISOString().split('T')[0],
        expiry: selectedExpiry || $('.expiry-tab.active').text(),
        strike: '',
        optType: 'FUTURE',
        FutureID: $('#FuturePrices').val(),
        entryPrice: FuturePrice,
        currentPrice: FuturePrice,
        IV: 0,
        lotSize: parseInt($('#lot').val()) || 75,
        exitPrice: undefined,
        enabled: true,
        instrumentToken:'NSE_FO|'+$('#FuturePrices option:selected').attr('value'),
        delta:-1,
        gamma:0,
        iv:0,
        theta:0,
        vega:0,
        deltaOriginal:-1,
        gammaOriginal:0,
        ivOriginal:0,
        thetaOriginal:0,
        vegaOriginal:0
    });
    
    // Update the position map after adding a new position
    updatePositionMap();
    
    // Update the positions table
    updatePositionsTable(true);
    
    // Update metrics calculations
    updateMetricsDisplay();
    updateGreeksTableFromState();
    
    updateChart()
    // Return the index of the newly added position
    return STATE.positions.length - 1;
}

// 7. Also update the map when positions are deleted
function deletePosition(index) {
    if (index < 0 || index >= STATE.positions.length) {
        console.error('Invalid position index:', index);
        return;
    }
    
    // Remove position from array
    STATE.positions.splice(index, 1);
    
    // Update position map after deleting a position
    updatePositionMap();
    
    // Update UI
    updatePositionsTable(true);
}

// 8. And when positions are updated
function updatePosition(index, updates) {
    if (index < 0 || index >= STATE.positions.length) {
        console.error('Invalid position index:', index);
        return;
    }
    
    // Apply updates to the position
    Object.assign(STATE.positions[index], updates);
    Object.assign(STATE.positions[index], {
        delta:STATE.positions[index].deltaOriginal*(STATE.positions[index].action=='Buy'?1:-1)*STATE.positions[index].lots,
        gamma:STATE.positions[index].gammaOriginal*(STATE.positions[index].action=='Buy'?1:-1)*STATE.positions[index].lots,
        iv:STATE.positions[index].ivOriginal*(STATE.positions[index].action=='Buy'?1:-1)*STATE.positions[index].lots,
        theta:STATE.positions[index].thetaOriginal*(STATE.positions[index].action=='Buy'?1:-1)*STATE.positions[index].lots,
        vega:STATE.positions[index].vegaOriginal*(STATE.positions[index].action=='Buy'?1:-1)*STATE.positions[index].lots
    });

    updateGreeksTableFromState()
    // Update position map if strike or optType changed
    if (updates.strike || updates.optType) {
        updatePositionMap();
    }
    
    // Update UI
    updatePositionsTable(true);
    updateChart()
}

// 9. Add periodic update for all positions to keep them aligned with market data
function periodicPositionsUpdate() {
    if (STATE.positions.length === 0) return;
    
    // For each position, try to find the current LTP in the options table
    STATE.positions.forEach((position, index) => {
        const strike = position.strike;
        const optType = position.optType;
        
        // Find the corresponding row in the options table
        const selector = optType === 'CE' ? 
            `.option-row .strike:contains(${strike})`.closest('tr').find('.call-ltp') :
            `.option-row .strike:contains(${strike})`.closest('tr').find('.put-ltp');
        
        const ltpElements = $(selector);
        
        if (ltpElements.length > 0) {
            // Extract the LTP from the cell (first part before the buttons)
            const ltpText = ltpElements.text().trim().split('\n')[0];
            const ltp = parseFloat(ltpText);
            
            // If we found a valid LTP, update the position
            if (!isNaN(ltp) && ltp > 0 && position.currentPrice !== ltp) {
                position.currentPrice = ltp;
                // Mark this position as needing an update
                STATE.positions[index].needsUpdate = true;
            }
        }
    });
    
    // If any positions need updates, refresh the positions table
    if (STATE.positions.some(pos => pos.needsUpdate)) {
        // Clear the update flags
        STATE.positions.forEach(pos => { pos.needsUpdate = false; });
        // Update the table
        debouncePositionsTableUpdate();
    }
}

// 10. Add periodic update to document.ready
document.addEventListener('DOMContentLoaded', function() {
    // ... existing code ...
    
    // Set up periodic positions update
    setInterval(periodicPositionsUpdate, 5000); // Check every 5 seconds
});

// 1. First, let's add CSS for the new classes
function addAtmStyles() {
    // Create a style element if it doesn't exist
    if (!document.getElementById('atm-highlight-styles')) {
      const styleEl = document.createElement('style');
      styleEl.id = 'atm-highlight-styles';
      
        // Using your existing CSS variables approach:
        styleEl.textContent = `
        .belowAtm td.ce{
            background-color:var(--belowAtm-color) !important;
            color:var(--fin-text-color);
        }
        .belowAtm td.pe{
            background-color:var(--aboveAtm-color) !important;
            color:var(--fin-text-color);
        
        }
    .highlighted td{
            background-color:var(--highlighted-color) !important;
            color:var(--fin-text-color);

}
        
        .aboveAtm td.ce{
            background-color:var(--aboveAtm-color) !important;
            color:var(--fin-text-color);

        }
        .aboveAtm td.pe{
            background-color:var(--belowAtm-color) !important;
            color:var(--fin-text-color);
        }
        td{
        
            text-align:center;
            }
        th{
        
            text-align:center;
            }
        `;
      
      document.head.appendChild(styleEl);
      //console.log('Added ATM highlighting styles');
    }
  }
  
  // 2. Update updateATMStrikeHighlight function to add aboveAtm and belowAtm classes
  function updateATMStrikeHighlight() {
    const atmStrike = parseFloat($("#strikePriceATM").val());
    window.atm = atmStrike;
    
    if (!atmStrike) return;
    
    // Remove all highlight classes from option rows
    $(".option-row").removeClass("highlighted aboveAtm belowAtm");
    
    // Find all rows and apply appropriate classes
    $(".option-row").each(function() {
      const rowStrike = parseFloat($(this).find(".strike").text());
      
      if (rowStrike === atmStrike) {
        // This is the ATM row
        $(this).addClass("highlighted");
      } else if (rowStrike > atmStrike) {
        // This row is above ATM
        $(this).addClass("aboveAtm");
      } else {
        // This row is below ATM
        $(this).addClass("belowAtm");
      }
    });
    
    // Optional: scroll to make ATM strike visible if needed
    const atmRow = $(`.option-row .strike:contains(${atmStrike})`).closest("tr");
    if (atmRow.length > 0) {
      const tableContainer = atmRow.closest('.options-table');
      if (tableContainer.length) {
        const containerTop = tableContainer.offset().top;
        const containerHeight = tableContainer.height();
        const rowTop = atmRow.offset().top;
        const rowHeight = atmRow.height();
        
        // Check if row is outside visible area
        if (rowTop < containerTop || rowTop + rowHeight > containerTop + containerHeight) {
          // Calculate scroll position to center the row
          const scrollTop = rowTop - containerTop - (containerHeight / 2) + (rowHeight / 2);
          tableContainer.animate({
            scrollTop: scrollTop
          }, 300); // Smooth scroll animation
        }
      }
    } else {
      console.warn(`Could not find option row with ATM strike ${atmStrike}`);
    }
  }
  
  // 4. Updated processSpotData function to update ATM highlighting when spot changes
  function processSpotData(data, symbType, digiToShow) {
    let spotPrice, changeValue, changePercent, timestamp;
    
    // Extract data based on feed type
    if (data.fullFeed?.indexFF) {
      const indexData = data.fullFeed.indexFF;
      spotPrice = indexData.ltpc?.ltp?.toFixed(digiToShow) || "";
      timestamp = indexData.ltpc?.ltt ? formatTimestamp(indexData.ltpc.ltt) : "";
      
      if (indexData.ltpc?.ltp && indexData.ltpc?.cp) {
        changeValue = (indexData.ltpc.ltp - indexData.ltpc.cp).toFixed(digiToShow);
        changePercent = ((changeValue / indexData.ltpc.cp) * 100).toFixed(2);
      }
    } else if (data.fullFeed?.marketFF) {
      const marketData = data.fullFeed.marketFF;
      spotPrice = marketData.ltpc?.ltp?.toFixed(digiToShow) || "";
      timestamp = marketData.ltpc?.ltt ? formatTimestamp(marketData.ltpc.ltt) : "";
      
      if (marketData.ltpc?.ltp && marketData.ltpc?.cp) {
        changeValue = (marketData.ltpc.ltp - marketData.ltpc.cp).toFixed(digiToShow);
        changePercent = ((changeValue / marketData.ltpc.cp) * 100).toFixed(2);
      }
    }
    
    // Update UI elements
    if (spotPrice) {
      // Hidden fields for option chain 
      $("#SpotPriceDataNew").html(spotPrice);
      $("#indexLTP").html(spotPrice);
      
      // Update price info in header
      updateFairPrice(spotPrice);
      
      // Update the vertical line in the chart
      updateSpotPriceLine();
      
      // Find closest strike to current spot price
      const strikeArray = $("#StrikePriceArray").val().split(',').map(Number);
      const closestStrike = findClosestStrike(strikeArray, spotPrice);
      
      // Update the ATM strike
      const previousATM = $("#strikePriceATM").val();
      if (previousATM != closestStrike) {
        // Only update if ATM strike has changed
        $("#strikePriceATM").val(closestStrike);
        $("#GetNewSpotPrice").val(closestStrike);
        
        // Update the ATM highlighting in the table with our new function
        updateATMStrikeHighlight();
      }
    }
    
    if (changeValue && changePercent) {
      $("#SpotChangeDataNew").html(changeValue);
      $("#SpotChangePerDataNew").html(changePercent);
    }
    
    if (timestamp) {
      $("#SpotTime").html(timestamp);
    }
    
    updatePriceArrows();
  }
  
  // 5. Override the original processSpotData function
//   window.processSpotData = processSpotData;
  
  // 6. Initialize the new styles and apply ATM highlighting to existing tables
  function initializeAtmHighlighting() {
    // Add the CSS styles
    addAtmStyles();
    
    // Apply the highlighting to existing tables
    updateATMStrikeHighlight();
    
    //console.log('Initialized ATM highlighting with above/below classes');
  }
  
  // 7. Run once when loaded and after expiry tabs are changed
  $(document).ready(function() {
    // Run once on page load
    setTimeout(initializeAtmHighlighting, 1000);
    
    // Also run when expiry tabs change
    $(document).on('shown.bs.tab', function(event) {
      setTimeout(updateATMStrikeHighlight, 100);
    });
  });
  
  // 8. Also enhance the renderOptionsTable function to apply classes when creating rows
  const originalRenderOptionsTable = window.renderOptionsTable;
  window.renderOptionsTable = function(strikeArray, CE_Tokens, PE_Tokens, expiryTable, dataAll) {
    // Call the original function first
    originalRenderOptionsTable(strikeArray, CE_Tokens, PE_Tokens, expiryTable, dataAll);
    
    // Then apply our highlighting
    setTimeout(updateATMStrikeHighlight, 100);
  };