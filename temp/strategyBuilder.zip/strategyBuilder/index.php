
<?php
    include '../includes/session.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Options Trading Platform</title>
    <!-- Include Highcharts -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/data.js"></script>
    <script src="https://code.highcharts.com/highcharts-more.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    
    <script src="https://unpkg.com/mithril/mithril.js"></script>
    <style>
        .time-box {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            padding: 10px;
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .arrow-button {
            padding: 5px 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .arrow-button:hover {
            background-color: #0056b3;
        }
        .current-date {
            font-size: 1rem;
            padding: 5px 10px;
            border: 1px solid #ccc;
            background-color: #fff;
            border-radius: 5px;
        }
        select {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .auto-play {
            background-color: #28a745;
        }
        .auto-play:hover {
            background-color: #218838;
        }
    </style>
    <style>
        .options-tab-container {
            background: var(--fin-bg-color);
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .options-tab-buttons {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
            border-bottom: 1px solid #333;
            padding-bottom: 12px;
        }

        .options-tab-btn {
            background:  var(--fin-card-bg);
            color:  var(--fin-text-color);
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .options-tab-btn:hover {
            background:  var(--fin-hover-color);
            color:  var(--fin-text-color);
        }

        .options-tab-btn.active {
            background:  var(--fin-accent-color);
            color:  var(--fin-text-color);
        }

        .options-tab-content {
            display: none;
            overflow-x:auto;
        }

        .options-tab-content.active {
            display: block;
        }

        .positions-table, .greeks-table {
            width: 100%;
            border-collapse: collapse;
            background:  var(--fin-bg-color);
            border-radius: 8px;
            overflow: hidden;
        }

        .positions-table th, .positions-table td,
        .greeks-table th, .greeks-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #333;
        }

        .positions-table th, .greeks-table th {
            background:  var(--fin-bg-color);
            font-weight: 600;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .positions-table td, .greeks-table td {
            font-size: 14px;
        }

        .positions-table tr:hover, .greeks-table tr:hover {
            background: #252525;
        }

        .profit {
            color: #00ff88 !important;
        }

        .loss {
            color: #ff4444 !important;
        }

        .neutral {
            color: #888;
        }

        input[type="checkbox"] {
            accent-color: #007aff;
        }

        .action-buy {
            color: #00ff88;
            font-weight: 500;
        }

        .action-sell {
            color: #ff4444;
            font-weight: 500;
        }

        .btn {
            background:  var(--fin-bg-color);
            color:  var(--fin-text-color);
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            transition: background 0.2s ease;
        }

        .btn:hover {
            background: #444;
        }

        .btn-danger {
            background: #ff4444;
        }

        .btn-danger:hover {
            background: #ff3333;
        }

        .greek-value {
            font-family: 'Monaco', 'Menlo', monospace;
        }

        .greek-positive {
            color: #00ff88;
        }

        .greek-negative {
            color: #ff4444;
        }

        .no-data {
            text-align: center;
            padding: 40px;
            color: #666;
            font-style: italic;
        }
        th,td{
            padding:10px !important;
            color:var(--fin-text-color) !important;
        }
        </style>
        <style>
              #columnSelectionModal {
                position: fixed !important;
                top: 0;
                left: 0;
                width: 100% !important;
                height: 100%;
                background: rgba(0, 0, 0, 0.7);
                backdrop-filter: blur(6px);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 1000;
                padding: 20px;
            }

            #columnSelectionModal .modal-content {
                background: #1a2332;
                border-radius: 12px;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
                max-width: 800px;
                width: 100%;
                max-height: 90vh;
                overflow: hidden;
                animation: optionsModalSlideIn 0.3s ease-out;
                border: 1px solid #2d3f52;
            }

            @keyframes optionsModalSlideIn {
                from {
                    opacity: 0;
                    transform: translateY(-30px) scale(0.95);
                }
                to {
                    opacity: 1;
                    transform: translateY(0) scale(1);
                }
            }

            /* Header Styles */
            #columnSelectionModal .modal-header {
                background: #0f1419;
                color: #ffffff;
                padding: 20px 24px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 1px solid #2d3f52;
            }

            #columnSelectionModal .modal-header h3 {
                margin: 0;
                font-size: 18px;
                font-weight: 600;
                letter-spacing: -0.5px;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            }

            #columnSelectionModal .close-modal {
                font-size: 24px;
                cursor: pointer;
                width: 32px;
                height: 32px;
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: 50%;
                transition: all 0.2s ease;
                opacity: 0.7;
                border: none;
                background: none;
                color: #ffffff;
            }

            #columnSelectionModal .close-modal:hover {
                background: rgba(255, 255, 255, 0.1);
                opacity: 1;
                transform: scale(1.1);
            }

            /* Body Styles */
            #columnSelectionModal .modal-body {
                padding: 24px;
                max-height: 60vh;
                overflow-y: auto;
                display: grid;
                grid-template-columns: 1fr auto 1fr;
                gap: 32px;
                background: #1a2332;
            }

            #columnSelectionModal .modal-body::-webkit-scrollbar {
                width: 6px;
            }

            #columnSelectionModal .modal-body::-webkit-scrollbar-track {
                background: #0f1419;
                border-radius: 3px;
            }

            #columnSelectionModal .modal-body::-webkit-scrollbar-thumb {
                background: #2d3f52;
                border-radius: 3px;
            }

            #columnSelectionModal .modal-body::-webkit-scrollbar-thumb:hover {
                background: #4a5f7f;
            }

            /* Column Section Styles */
            #columnSelectionModal .column-section {
                min-width: 200px;
            }

            #columnSelectionModal .column-section h4 {
                margin: 0 0 16px 0;
                font-size: 13px;
                font-weight: 700;
                color: #8b9ab8;
                text-transform: uppercase;
                letter-spacing: 1px;
                border-bottom: 2px solid #2d3f52;
                padding-bottom: 8px;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            }

            /* Call Side Specific Styling */
            #callColumnsContainer {
                display: flex;
                flex-direction: column;
                gap: 2px;
            }

            #callColumnsContainer ~ h4,
            #columnSelectionModal .column-section:first-child h4 {
                color: #10b981;
                border-bottom-color: #10b981;
            }

            /* Put Side Specific Styling */
            #putColumnsContainer {
                display: flex;
                flex-direction: column;
                gap: 2px;
            }

            #putColumnsContainer ~ h4,
            #columnSelectionModal .column-section:last-child h4 {
                color: #ef4444;
                border-bottom-color: #ef4444;
            }

            /* Strike Section Specific Styling */
            #middleColumnsContainer {
                display: flex;
                flex-direction: column;
                gap: 12px;
            }

            #columnSelectionModal .column-section:nth-child(2) {
                display: flex;
                flex-direction: column;
                align-items: center;
                min-width: 120px;
            }

            #columnSelectionModal .column-section:nth-child(2) h4 {
                color: #0ea5e9;
                border-bottom-color: #0ea5e9;
                text-align: center;
                width: 100%;
            }

            /* Column Option Styles */
            #columnSelectionModal .column-option {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 2px 4px;
                border: 2px solid #2d3f52;
                border-radius: 8px;
                transition: all 0.2s ease;
                background: #0f1419;
                cursor: pointer;
                user-select: none;
            }

            #columnSelectionModal .column-option:hover {
                border-color: #4a5f7f;
                background: #151d2a;
                transform: translateY(-1px);
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            }

            #columnSelectionModal .column-option:has(input:checked) {
                border-color: #0ea5e9;
                background: rgba(14, 165, 233, 0.1);
                box-shadow: 0 4px 12px rgba(14, 165, 233, 0.2);
            }

            /* Call side checked styling */
            #callColumnsContainer .column-option:has(input:checked) {
                border-color: #10b981 !important;
                background: rgba(16, 185, 129, 0.1) !important;
                box-shadow: 0 4px 12px rgba(16, 185, 129, 0.2) !important;
            }

            /* Put side checked styling */
            #putColumnsContainer .column-option:has(input:checked) {
                border-color: #ef4444 !important;
                background: rgba(239, 68, 68, 0.1) !important;
                box-shadow: 0 4px 12px rgba(239, 68, 68, 0.2) !important;
            }

            #columnSelectionModal .column-option.disabled {
                opacity: 0.5;
                cursor: not-allowed;
                background: #0f1419;
                border-style: dashed;
            }

            #columnSelectionModal .column-option.disabled:hover {
                transform: none;
                box-shadow: none;
                border-color: #2d3f52;
            }

            /* Checkbox Styles */
            #columnSelectionModal .column-option input[type="checkbox"] {
                width: 18px;
                height: 18px;
                accent-color: #0ea5e9;
                cursor: pointer;
            }

            #callColumnsContainer input[type="checkbox"] {
                accent-color: #10b981;
            }

            #putColumnsContainer input[type="checkbox"] {
                accent-color: #ef4444;
            }

            #columnSelectionModal .column-option input[type="checkbox"]:disabled {
                cursor: not-allowed;
            }

            /* Label Styles */
            #columnSelectionModal .column-option label {
                font-size: 14px;
                font-weight: 500;
                color: #e5e7eb;
                cursor: pointer;
                flex: 1;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            }

            #columnSelectionModal .column-option.disabled label {
                cursor: not-allowed;
                color: #6b7280;
            }

            /* Footer Styles */
            #columnSelectionModal .modal-footer {
                background: #0f1419;
                padding: 20px 24px;
                display: flex;
                gap: 12px;
                justify-content: flex-end;
                border-top: 1px solid #2d3f52;
            }

            /* Button Styles */
            #columnSelectionModal .btn {
                padding: 10px 20px;
                border: none;
                border-radius: 6px;
                font-size: 14px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.2s ease;
                display: inline-flex;
                align-items: center;
                gap: 8px;
                text-decoration: none;
                min-width: 100px;
                justify-content: center;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            }

            #columnSelectionModal .btn:focus {
                outline: 2px solid #0ea5e9;
                outline-offset: 2px;
            }

            #saveColumnSettings.btn-primary {
                background: #0ea5e9;
                color: #ffffff;
                box-shadow: 0 4px 12px rgba(14, 165, 233, 0.3);
            }

            #saveColumnSettings.btn-primary:hover {
                background: #0284c7;
                box-shadow: 0 6px 16px rgba(14, 165, 233, 0.4);
                transform: translateY(-1px);
            }

            #saveColumnSettings.btn-primary:active {
                transform: translateY(0);
                box-shadow: 0 2px 8px rgba(14, 165, 233, 0.3);
            }

            #cancelColumnSettings.btn,
            #resetColumnSettings.btn {
                background: #2d3f52;
                color: #e5e7eb;
                border: 1px solid #4a5f7f;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            }

            #cancelColumnSettings.btn:hover,
            #resetColumnSettings.btn:hover {
                background: #3d4f62;
                border-color: #6b7f9a;
                transform: translateY(-1px);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            }

            /* Responsive Design */
            @media (max-width: 768px) {
                #columnSelectionModal .modal-body {
                    grid-template-columns: 1fr;
                    gap: 24px;
                }

                #columnSelectionModal .column-section:nth-child(2) {
                    order: -1;
                }

                #columnSelectionModal .modal-footer {
                    flex-direction: column-reverse;
                }

                #columnSelectionModal .btn {
                    width: 100%;
                }
            }

            @media (max-width: 480px) {
                #columnSelectionModal {
                    padding: 10px;
                }

                #columnSelectionModal .modal-header {
                    padding: 16px 20px;
                }

                #columnSelectionModal .modal-body {
                    padding: 20px;
                }

                #columnSelectionModal .modal-footer {
                    padding: 16px 20px;
                }
            }

            /* Fallback for browsers that don't support :has() selector */
            #columnSelectionModal .column-option.checked {
                border-color: #0ea5e9;
                background: rgba(14, 165, 233, 0.1);
                box-shadow: 0 4px 12px rgba(14, 165, 233, 0.2);
            }

            #callColumnsContainer .column-option.checked {
                border-color: #10b981 !important;
                background: rgba(16, 185, 129, 0.1) !important;
                box-shadow: 0 4px 12px rgba(16, 185, 129, 0.2) !important;
            }

            #putColumnsContainer .column-option.checked {
                border-color: #ef4444 !important;
                background: rgba(239, 68, 68, 0.1) !important;
                box-shadow: 0 4px 12px rgba(239, 68, 68, 0.2) !important;
            }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            background-color:  var(--fin-bg-color) !important;
            color:  var(--fin-text-color);
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color:  var(--fin-bg-color);
            border-bottom: 1px solid #3a3a3a;
            color:  var(--fin-text-color) !important;
        }
        .selector {
            display: flex;
            gap: 10px;
        }
        .selector select {
            padding: 8px;
            border-radius: 4px;
            background-color: #fff;
        }
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        .action-buttons button {
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            border: none;
        }
        .save-btn {
            background-color: #d4ecd4;
            color: #2a2a2a;
        }
        .export-btn {
            background-color: #ffe0e0;
            color: #2a2a2a;
        }
        .refresh-btn {
            background-color: #e0e0ff;
            color: #2a2a2a;
        }
        .new-btn {
            background-color: #007bff;
            color: white;
        }
        .copy-btn {
            background-color: #2a76b9;
            color: white;
        }
        .price-info {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .price-badge {
            padding: 5px 15px;
            border-radius: 4px;
            font-weight: bold;
        }
        .buy {
            background-color: #28a745;
            color: white;
        }
        .sell {
            background-color: #dc3545;
            color: white;
        }
        .status-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #2a2a2a;
            color: #cccccc;
            font-size: 14px;
        }
        .expiry-tabs {
            display: flex;
            background-color:  var(--fin-bg-color);
            overflow-x: auto;
            border-bottom: 1px solid #3a3a3a;
            font-size:12px !important;
        }
        .expiry-tab {
            padding: 12px 20px;
            background-color:  var(--fin-bg-color);
            border: none;
            color:  var(--fin-text-color);
            cursor: pointer;
            white-space: nowrap;
            border-right: 1px solid #3a3a3a;
            transition: background-color 0.2s;
        }
        .expiry-tab:hover {
            background-color: var(--fin-hover-color);
        }
        .expiry-tab.active {
            background-color: var(--fin-accent-color);
            color: white;
            font-weight: bold;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap; /* allows children to wrap */
            padding: 10px;
            font-size: 16px; /* default font size */
        }

        .selector, .action-buttons, .price-info {
            margin: 5px;
        }

        /* Make selector and action-buttons share space on desktop */
        .selector {
            flex: 1;
        }
        .action-buttons {
            flex: 2;
            display: flex;
            flex-wrap: wrap;
            gap: 5px;
        }
        .price-info {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
        }

        /* Mobile styles */
        @media (max-width: 767px) {
            .header {
                flex-direction: column;
                font-size: 14px; /* smaller font for mobile */
                align-items: flex-start;
            }

            .selector,
            .action-buttons,
            .price-info {
                width: 100%;
            }

            .price-info {
                order: 3; /* ensure it's at the bottom */
                flex-wrap: wrap;
                font-size: 14px;
            }

            .price-info > div,
            .price-info select {
                margin-bottom: 5px;
            }

            .action-buttons {
                order: 2;
                justify-content: flex-start;
            }

            .selector {
                order: 1;
            }
        }
        .nav-arrow {
            padding: 12px 15px;
            background-color: var(--fin-bg-color);
            border: none;
            color: #ccc;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .nav-arrow:hover {
            background-color: var(--fin-hover-color);
        }
        .main-content {
            /* height: calc(100vh - 160px); */
        }

        /* Apply flex only on screens wider than 768px (desktop/tablet) */
        @media (min-width: 768px) {
            .main-content {
                display: flex;
            }
        }

        .tab-content {
            overflow-y: scroll;
            max-height:80vh;
            border-right: 1px solid #3a3a3a;
        }
        /* Default for mobile: full width or unset */
        .chart-panel {
            width: 90%;
            margin:20px 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            background-color: var(--fin-bg-color);
            padding: 8px;
            text-align: center;
            position: sticky;
            top: -10px;
            z-index: 10;
        }
        td {
            padding: 8px;
            text-align: center;
            border-bottom: 1px solid #3a3a3a;
        }
        tr:hover {
            background-color: var(--fin-bg-color);
        }
        .chart-container {
            height: 300px;
            background-color: var(--fin-bg-color);
            border-radius: 4px;
            padding: 10px;
            margin-bottom: 10px;
        }
        .metrics {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 10px;
        }
        .metric-card {
            background-color: var(--fin-card-bg);
            border-radius: 4px;
            padding: 10px;
        }
        .metric-title {
            font-size: 12px;
            color: var(--fin-muted-color);
        }
        .metric-value {
            font-size: 14px;
            font-weight: bold;
        }
        .profit {
            color: #28a745;
        }
        .loss {
            color: #dc3545;
        }
        .controls {
            background-color: #2a2a2a;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        .control-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .control-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .control-item input {
            padding: 5px;
            border-radius: 4px;
            background-color: #3a3a3a;
            color: white;
            border: 1px solid #4a4a4a;
        }
        .reset-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
        .tab-container {
            margin-bottom: 10px;
        }
        .tab-buttons {
            display: flex;
            border-bottom: 1px solid #3a3a3a;
        }
        .tab-btn {
            padding: 10px 20px;
            background-color: transparent;
            border: none;
            color: #cccccc;
            cursor: pointer;
        }
        .tab-btn.active {
            background-color: var(--fin-bg-color);
            color: white;
            border-bottom: 2px solid #007bff;
        }
        .tab-content {
            padding: 10px;
            background-color: var(--fin-bg-color);
            border-radius: 0 0 4px 4px;
        }
        .positions-table {
            font-size: 10px;
            width: 100%;
        }
        
        /* New styles for hover trade buttons */
        .option-row {
            position: relative;
        }
        
        
        .trade-buttons {
            display: none;
            position: absolute;
            top: 5px;
        }
        
        .option-row:hover .trade-buttons {
            display: flex;
            gap: 5px;
        }
        
        .trade-btn {
            font-size:10px;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            border: none;
            font-weight: bold;
        }
        
        .buy-btn {
            background-color: #28a745;
            color: white;
        }
        
        .sell-btn {
            background-color: #dc3545;
            color: white;
        }
        
        /* Notification System Styles */
        .notification-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }

        .notification {
            background-color: #333;
            color: white;
            padding: 12px 20px;
            margin-bottom: 10px;
            border-radius: 4px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 300px;
            opacity: 0;
            transform: translateX(50px);
            transition: opacity 0.3s, transform 0.3s;
            display: flex;
            align-items: center;
        }

        .notification.success {
            background-color: #28a745;
            border-left: 4px solid #1e7e34;
        }

        .notification.error {
            background-color: #dc3545;
            border-left: 4px solid #bd2130;
        }

        .notification.info {
            background-color: #17a2b8;
            border-left: 4px solid #138496;
        }

        .notification.warning {
            background-color: #ffc107;
            color: #212529;
            border-left: 4px solid #d39e00;
        }

        .notification.show {
            opacity: 1;
            transform: translateX(0);
        }

        .notification-icon {
            margin-right: 10px;
            font-size: 16px;
        }

        .notification-message {
            flex-grow: 1;
        }

        .notification-close {
            background: none;
            border: none;
            color: rgba(255, 255, 255, 0.7);
            cursor: pointer;
            font-size: 16px;
            margin-left: 10px;
            padding: 0;
        }

        .notification-close:hover {
            color: white;
        }
    </style>
    
    <style>
                
                .modal-content {
                    background-color: #2a2a2a;
                    margin: 5% auto;
                    padding: 20px;
                    border: 1px solid #888;
                    width: 80%;
                    max-width: 800px;
                    border-radius: 5px;
                    color: #cccccc;
                }
                
                .modal-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding-bottom: 10px;
                    border-bottom: 1px solid #444;
                }
                
                .modal-header h3 {
                    margin: 0;
                    color: #fff;
                }
                
                .close-modal {
                    color: #aaa;
                    font-size: 28px;
                    font-weight: bold;
                    cursor: pointer;
                }
                
                .close-modal:hover {
                    color: #fff;
                }
                
                .modal-body {
                    justify-content: space-between;
                    padding: 20px 0;
                }
                
                .column-section {
                    flex: 1;
                    padding: 0 10px;
                }
                
                .column-section h4 {
                    margin-top: 0;
                    color: #fff;
                }
                
                .columns-container {
                    display: flex;
                    flex-direction: column;
                }
                
                .column-option {
                    margin: 5px 0;
                    display: flex;
                    align-items: center;
                }
                
                .column-option input[type="checkbox"] {
                    margin-right: 8px;
                }
                
                .column-option.disabled {
                    opacity: 0.5;
                    pointer-events: none;
                }
                
                .modal-footer {
                    padding-top: 15px;
                    border-top: 1px solid #444;
                    text-align: right;
                }
                
                .btn {
                    padding: 8px 15px;
                    margin-left: 10px;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    background-color: #444;
                    color: #fff;
                }
                
                .btn-primary {
                    background-color: #0078D7;
                }
                
                .btn:hover {
                    opacity: 0.9;
                }
                th,td{
                    font-size:10px;
                }
            </style>
    
    <!-- 2. Add this CSS to the head section -->
    <style>
        /* Loading overlay */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(26, 26, 26, 0.8);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }
        
        .spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #3a3a3a;
            border-radius: 50%;
            border-top-color: #007bff;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        }
        
        .loading-text {
            color: white;
            font-size: 18px;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Improve tooltip performance */
        .notification {
            will-change: transform, opacity;
        }
        
        /* Optimize trade buttons */
        .trade-buttons {
            transition: opacity 0.15s;
        }
        
        /* Optimize table performance */
        .option-row {
            contain: layout style;
        }
        
        /* Hardware acceleration for animations */
        .notification,
        .expiry-tab,
        .nav-arrow,
        .option-row:hover,
        .trade-buttons {
            transform: translateZ(0);
        }
        /* Hide all tab panes by default */
        .tab-pane {
        display: none;
        }

        /* Only show the tab pane when it has both active and show classes */
        .tab-pane.active.show {
        display: block;
        }
        /* Default for mobile: full width or unset */
        #nav-tabContent {
            width: 100%;
        }

        /* On desktop only: 50% width */
        @media (min-width: 768px) {
            #nav-tabContent {
                width: 100%;
            }
        }
        
        /* Modal backdrop */
        .modal-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.5);
        z-index: 1000;
        justify-content: center;
        align-items: center;
        }

        /* Modal box */
        .modal {
        width: 400px !important;
        background: #333;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        padding: 20px;
        position: relative !important;
        color:white;
        }

        .modal-header {
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 15px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        }

        .modal-header .close {
        cursor: pointer;
        font-size: 24px;
        }

        .modal-body {
        background: #2d2d2d;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 15px;
        }

        .modal-body input,
        .modal-body select {
        width: 100%;
        padding: 10px;
        margin: 8px 0;
        border-radius: 6px;
        border: none;
        }

        .modal-footer {
        display: flex;
        justify-content: space-between;
        }

        .btn {
        padding: 10px 15px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        color: #fff;
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: 14px;
        }

        .btn.saveas { background-color: #007bff; }
        .btn.save { background-color: #60a5fa; }
        .btn.cancel { background-color: #1e3a8a; }
        .btn i { font-style: normal; }
        
        .modal-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.5);
        z-index: 1000;
        justify-content: center;
        align-items: center;
        overflow: auto;
        }

        .modal-large {
        background: #333;
        border-radius: 10px;
        width: 90%;
        max-width: 900px;
        padding: 20px;
        max-height: 90vh;
        overflow-y: auto;
        position: relative;
        }

        .modal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 15px;
        }

        .filters {
        display: flex;
        gap: 10px;
        margin-bottom: 15px;
        }

        .filters button {
        padding: 6px 14px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
        color: white;
        }

        .filters .all { background-color: #2563eb; }
        .filters .live { background-color: gray; }
        .filters .paper { background-color: gray; }
        .filters .misc { background-color: gray; }

        table {
        width: 100%;
        border-collapse: collapse;
        }

        th, td {
        padding: 10px;
        text-align: left;
        border: 1px solid #333;
        /* color: white; */
        }

        thead {
        background-color: #1e1e1e;
        }

        tbody {
        background-color: #2d2d2d;
        }

        .expired-badge {
        background-color: red;
        color: white;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 12px;
        }

        .delete-icon {
        cursor: pointer;
        color: white;
        font-size: 16px;
        }

        .delete-icon:hover {
        color: red;
        }
        .form-control {
            display: block;
            /* width: 100%; */
            height: 34px;
            /* padding: 6px 12px; */
            font-size: 10px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
            -webkit-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
            -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
            -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
            transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
            transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
            transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
        }
        
        .edit-btn {
        background-color: #3498db;
        padding:0.2rem;
        border-radius:1rem;
        }
        
        .edit-btn:hover {
        background-color: #2980b9;
        }
        
        .exit-btn {
        background-color: #f39c12;
        padding:0.2rem;
        border-radius:1rem;
        }
        
        .exit-btn:hover {
        background-color: #d68910;
        }
        
        .delete-btn {
        background-color: #e74c3c;
        padding:0.2rem;
        border-radius:1rem;
        }
        
        .delete-btn:hover {
        background-color: #c0392b;
        }
        /* Modal Background */
        #exit-dialog.modal {
            display: none;
            position: fixed !important;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100% !important;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            overflow: auto;
        }

        /* Modal Content */
        #exit-dialog .modal-content {
            position: relative;
            background-color: #ffffff;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 400px;
            max-width: 90%;
            border-radius: 6px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            animation: modalFadeIn 0.3s ease-out;
        }

        @keyframes modalFadeIn {
            from {opacity: 0; transform: translateY(-20px);}
            to {opacity: 1; transform: translateY(0);}
        }

        /* Modal Header */
        #exit-dialog .modal-content h4 {
            margin-top: 0;
            color: #333;
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }

        /* Form Group */
        #exit-dialog .form-group {
            margin-bottom: 20px;
        }

        #exit-dialog .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #444;
        }

        #exit-dialog .form-control:focus {
            border-color: #4a90e2;
            outline: none;
            box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
        }

        /* Position Information */
        #exit-dialog .modal-content p {
            margin-bottom: 20px;
            font-size: 14px;
            color: #555;
            background-color: #f7f9fc;
            padding: 12px;
            border-radius: 4px;
            border-left: 3px solid #4a90e2;
        }

        /* Button Group */
        #exit-dialog .button-group {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 25px;
        }

        #exit-dialog .btn {
            padding: 10px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s;
        }

        #exit-dialog .btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        #exit-dialog .btn-primary {
            background-color: #4a90e2;
            color: white;
        }

        #exit-dialog .btn-primary:hover {
            background-color: #3a7bc8;
        }

        #exit-dialog .btn-secondary {
            background-color: #f0f0f0;
            color: #333;
        }

        #exit-dialog .btn-secondary:hover {
            background-color: #e4e4e4;
        }

        /* For mobile devices */
        @media screen and (max-width: 480px) {
            #exit-dialog .modal-content {
                width: 90%;
                margin: 30% auto;
                padding: 15px;
            }
            
            #exit-dialog .button-group {
                flex-direction: column;
            }
            
            #exit-dialog .btn {
                width: 100%;
                margin-bottom: 8px;
            }
        }

        /* Input number arrows styling */
        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button { 
            opacity: 1;
            height: 30px;
        }
        .exitedPosition td{
            background-color:#444;
        }
    </style>
    
    <style>

        /* Strategy Selection Header */
        .strategy-header {
            display: flex;
            gap: 10px;
            margin: 10px 20px;
            flex-wrap: wrap;
            align-items: center;
        }

        .strategy-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn-category {
            padding: 8px 16px;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.3s ease;
            background: #1a1a1a;
            color: #999;
            border: 1px solid #333;
        }

        .btn-category.active {
            background: #1976D2;
            color: white;
            border-color: #1976D2;
        }

        .btn-category:hover {
            border-color: #444;
        }

        .expiry-selector {
            margin-left: auto;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 13px;
        }

        .expiry-selector select {
            background: #1a1a1a;
            color: #e0e0e0;
            border: 1px solid #333;
            padding: 6px 10px;
            border-radius: 6px;
            cursor: pointer;
        }

        /* Empty State Styles */
        .empty-state {
            padding: 10px 20px;
            max-height: 500px;
            overflow-y: scroll;
        }

        #emptyState.hidden {
            display: none;
        }

        .strategy-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .strategy-card {
            background: #1a1a1a;
            border: 1px solid #333;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 180px;
        }

        .strategy-card:hover {
            border-color: #1976D2;
            background: #262626;
            transform: translateY(-2px);
        }

        .strategy-card.hidden {
            display: none;
        }

        .strategy-chart {
            width: 100%;
            height: 80px;
            margin-bottom: 10px;
            background: #0f0f0f;
            border-radius: 8px;
            position: relative;
            display: flex;
            align-items: flex-end;
            justify-content: center;
            gap: 1px;
            padding: 8px;
        }

        .chart-bar {
            background: linear-gradient(to top, #1976D2, #42a5f5);
            width: 3px;
            border-radius: 2px;
        }

        .strategy-name {
            font-size: 12px;
            color: #e0e0e0;
            margin-top: 10px;
            font-weight: 500;
        }

        /* Chart Panel Styles */
        .chart-panel {
            display: none;
        }

        .chart-panel.visible {
            display: block;
        }

        .metrics {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }

        .metric-card {
            background: #1a1a1a;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #1976D2;
        }

        .metric-title {
            font-size: 11px;
            color: #999;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .metric-value {
            font-size: 16px;
            font-weight: 600;
            color: #e0e0e0;
        }

        .metric-value.profit {
            color: #4caf50;
        }

        .metric-value.loss {
            color: #f44336;
        }

        .chart-container {
            width: 100%;
            height: 300px;
            background: #1a1a1a;
            border: 1px solid #333;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #666;
            margin-bottom: 20px;
        }

        /* Button Styles */
        .btn-primary {
            background: #1976D2;
            color: white;
        }

        .btn-primary:hover {
            background: #1565C0;
        }

        .btn-secondary {
            background: #1a1a1a;
            color: #e0e0e0;
            border: 1px solid #333;
        }

        .btn-secondary:hover {
            border-color: #1976D2;
            background: #262626;
        }

        button {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .clear-btn {
            display: flex;
            gap: 10px;
            justify-content: center;
            margin-top: 20px;
        }
    </style>
      <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <?php
        include '../includes/navbar.php';
    ?>
    <div class="header">
        <div class="selector">
            <select id="symbol" name="symbol">
                <?php
                    $symbol = $_GET['symbol'] ?? 'Nifty 50';

                    $symbols = [
                        'Nifty 50' => 'NIFTY',
                        'Nifty Bank' => 'BANKNIFTY',
                        'Nifty Fin Service' => 'FINNIFTY'
                    ];

                    foreach ($symbols as $value => $label) {
                        $selected = ($symbol === $value) ? 'selected' : '';
                        echo "<option value=\"$value\" $selected>$label</option>";
                    }
                ?>
            </select>
        </div>
        <div class="action-buttons">
            <button class="save-btn">
                <i class="fas fa-save"></i>
            </button>
            <button class="export-btn">
                <i class="fas fa-download"></i>
            </button>
            <button class="refresh-btn">
                <i class="fas fa-sync"></i>
            </button>
            <button class="new-btn">New</button>
            <button class="copy-btn">
                <i class="fas fa-copy"></i>
            </button>
            <button class="column-settings-btn" title="Customize Columns">Columns</button>

        </div>
        <div class="price-info">
            <div>Fair Price: 22933.5</div>
            <div><select class='form-control' id='FuturePrices'></select></div>
            <div>Price: </div>
            <div>Lot Size: 75</div>
            <div>IV: 12.08</div>
            <div class="price-badge buy" onclick='buyFuture()'>B</div>
            <div class="price-badge sell" onclick='sellFuture()'>S</div>
        </div>
    </div>


    
    <div class="expiry-tabs">
        <button class="nav-arrow">←</button>
        <button class="expiry-tab">20MAR25(W)</button>
        <button class="expiry-tab active">27MAR25(M)</button>
        <button class="expiry-tab">03APR25(W)</button>
        <button class="expiry-tab">09APR25(W)</button>
        <button class="expiry-tab">17APR25(W)</button>
        <button class="nav-arrow">→</button>
    </div>

    <div class="main-content"style='display: grid;grid-template-columns: 60% 40%;'>
        <div class="tab-content" id="nav-tabContent">
        </div>

        <div  id="emptyState">
            <!-- Strategy Header -->
            <div class="strategy-header">
                <div class="strategy-buttons">
                    <button class="btn-category active" onclick="filterStrategies('bullish')" id='bullishFilterBtn'>Bullish</button>
                    <button class="btn-category" onclick="filterStrategies('bearish')" id='bearishFilterBtn'>Bearish</button>
                    <button class="btn-category" onclick="filterStrategies('neutral')" id='neutralFilterBtn'>Neutral</button>
                    <button class="btn-category" onclick="filterStrategies('others')" id='othersFilterBtn'>Others</button>
                </div>
            </div>

            <!-- Empty State (shown when no positions) -->
            <div class="empty-state">
                <div class="strategy-grid" id="strategyGrid">
                    <div class="strategy-card bullish" onclick="addPositionStrategy('buy-call')" data-category="bullish">
                        <svg class="strategy-chart" viewBox="0 0 100 60" style="width: 100%; height: 80px;">
                            <polyline points="10,50 30,40 50,25 70,15 90,5" stroke="#1976D2" stroke-width="2" fill="none"/>
                            <polyline points="10,50 30,50 50,50 70,50 90,50" stroke="#f44336" stroke-width="2" fill="none" stroke-dasharray="3,3"/>
                        </svg>
                        <div class="strategy-name">Buy Call</div>
                    </div>

                    <div class="strategy-card bearish" onclick="addPositionStrategy('sell-put')" data-category="bearish">
                        <svg class="strategy-chart" viewBox="0 0 100 60" style="width: 100%; height: 80px;">
                            <polyline points="10,20 30,30 50,40 70,50 90,50" stroke="#1976D2" stroke-width="2" fill="none"/>
                            <polyline points="10,50 30,50 50,50 70,50 90,50" stroke="#f44336" stroke-width="2" fill="none" stroke-dasharray="3,3"/>
                        </svg>
                        <div class="strategy-name">Sell Put</div>
                    </div>

                    <div class="strategy-card bullish" onclick="addPositionStrategy('bull-call-spread')" data-category="bullish">
                        <svg class="strategy-chart" viewBox="0 0 100 60" style="width: 100%; height: 80px;">
                            <polyline points="10,50 30,35 50,25 70,25 90,25" stroke="#1976D2" stroke-width="2" fill="none"/>
                            <polyline points="10,50 30,50 50,50 70,50 90,50" stroke="#f44336" stroke-width="2" fill="none" stroke-dasharray="3,3"/>
                        </svg>
                        <div class="strategy-name">Bull Call Spread</div>
                    </div>

                    <div class="strategy-card bullish" onclick="addPositionStrategy('bull-put-spread')" data-category="bullish">
                        <svg class="strategy-chart" viewBox="0 0 100 60" style="width: 100%; height: 80px;">
                            <polyline points="10,40 30,35 50,30 70,30 90,30" stroke="#1976D2" stroke-width="2" fill="none"/>
                            <polyline points="10,50 30,50 50,50 70,50 90,50" stroke="#f44336" stroke-width="2" fill="none" stroke-dasharray="3,3"/>
                        </svg>
                        <div class="strategy-name">Bull Put Spread</div>
                    </div>

                    <div class="strategy-card bullish" onclick="addPositionStrategy('call-ratio-spread')" data-category="bullish">
                        <svg class="strategy-chart" viewBox="0 0 100 60" style="width: 100%; height: 80px;">
                            <polyline points="10,50 25,40 40,30 55,35 70,45 90,50" stroke="#1976D2" stroke-width="2" fill="none"/>
                            <polyline points="10,50 30,50 50,50 70,50 90,50" stroke="#f44336" stroke-width="2" fill="none" stroke-dasharray="3,3"/>
                        </svg>
                        <div class="strategy-name">Call Ratio Back Spread</div>
                    </div>

                    <div class="strategy-card neutral" onclick="addPositionStrategy('long-calendar')" data-category="neutral">
                        <svg class="strategy-chart" viewBox="0 0 100 60" style="width: 100%; height: 80px;">
                            <polyline points="10,35 30,25 50,30 70,25 90,35" stroke="#1976D2" stroke-width="2" fill="none"/>
                            <polyline points="10,50 30,50 50,50 70,50 90,50" stroke="#f44336" stroke-width="2" fill="none" stroke-dasharray="3,3"/>
                        </svg>
                        <div class="strategy-name">Long Calendar with Calls</div>
                    </div>

                    <div class="strategy-card neutral" onclick="addPositionStrategy('bull-condor')" data-category="neutral">
                        <svg class="strategy-chart" viewBox="0 0 100 60" style="width: 100%; height: 80px;">
                            <polyline points="10,50 20,35 40,30 60,30 80,35 90,50" stroke="#1976D2" stroke-width="2" fill="none"/>
                            <polyline points="10,50 30,50 50,50 70,50 90,50" stroke="#f44336" stroke-width="2" fill="none" stroke-dasharray="3,3"/>
                        </svg>
                        <div class="strategy-name">Bull Condor</div>
                    </div>

                    <div class="strategy-card bullish" onclick="addPositionStrategy('bull-butterfly')" data-category="bullish">
                        <svg class="strategy-chart" viewBox="0 0 100 60" style="width: 100%; height: 80px;">
                            <polyline points="10,50 25,30 45,25 50,30 55,25 75,30 90,50" stroke="#1976D2" stroke-width="2" fill="none"/>
                            <polyline points="10,50 30,50 50,50 70,50 90,50" stroke="#f44336" stroke-width="2" fill="none" stroke-dasharray="3,3"/>
                        </svg>
                        <div class="strategy-name">Bull Butterfly</div>
                    </div>

                    <div class="strategy-card others" onclick="addPositionStrategy('range-forward')" data-category="others">
                        <svg class="strategy-chart" viewBox="0 0 100 60" style="width: 100%; height: 80px;">
                            <polyline points="10,45 50,35 90,25" stroke="#1976D2" stroke-width="2" fill="none"/>
                            <polyline points="10,50 30,50 50,50 70,50 90,50" stroke="#f44336" stroke-width="2" fill="none" stroke-dasharray="3,3"/>
                        </svg>
                        <div class="strategy-name">Range Forward</div>
                    </div>

                    <div class="strategy-card others" onclick="addPositionStrategy('long-synthetic')" data-category="others">
                        <svg class="strategy-chart" viewBox="0 0 100 60" style="width: 100%; height: 80px;">
                            <polyline points="10,40 50,25 90,10" stroke="#1976D2" stroke-width="2" fill="none"/>
                            <polyline points="10,50 30,50 50,50 70,50 90,50" stroke="#f44336" stroke-width="2" fill="none" stroke-dasharray="3,3"/>
                        </svg>
                        <div class="strategy-name">Long Synthetic Future</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="chart-panel" id='chartPanel'>
            <div class="metrics" style='zoom:80%'>
                <div class="metric-card">
                    <div class="metric-title">Max Profit:</div>
                    <div class="metric-value profit">₹ 0.00</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Max Loss:</div>
                    <div class="metric-value loss">₹ 0.00 (0.0%)</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">R:R:</div>
                    <div class="metric-value">NA</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Net Credit:</div>
                    <div class="metric-value">₹ 0.0</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Margin Required:</div>
                    <div class="metric-value" id='margin'>₹ 0.0</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Funds Required:</div>
                    <div class="metric-value">₹ 0.00</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Breakeven (Expiry):</div>
                    <div class="metric-value">0.00 (0.0%)</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Breakeven (T+0):</div>
                    <div class="metric-value">0.00 (0.0%)</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Current P/L:</div>
                    <div class="metric-value profit">₹ 0.00 (0.0%)</div>
                </div>
            </div>
            
            <div class="chart-container" id="highcharts-container">
                <!-- Highcharts will be inserted here -->
            </div>
            
            
        </div>
    </div>
    
    <div class="options-tab-container">
        <div class="options-tab-buttons">
            <button class="options-tab-btn active" data-options-tab="legs">Legs</button>
            <button class="options-tab-btn" data-options-tab="greeks">Greeks</button>
        </div>

        <!-- Legs Tab Content -->
        <div class="options-tab-content active" id="options-legs-tab">
            <table class="positions-table">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="options-select-all-legs"></th>
                        <th>Action</th>
                        <th>Lots</th>
                        <th>Date</th>
                        <th>Expiry</th>
                        <th>Strike</th>
                        <th>Opt Type</th>
                        <th>Entry Price</th>
                        <th>Curr/Exit Price</th>
                        <th>Current P/L</th>
                        <th>IV</th>
                        <th>Exit/Delete</th>
                    </tr>
                </thead>
                <tbody id="options-legs-tbody">
                    <!-- Sample data -->
                    <tr>
                        <td><input type="checkbox" class="options-leg-checkbox"></td>
                        <td><span class="action-buy">BUY</span></td>
                        <td>10</td>
                        <td>2025-05-28</td>
                        <td>2025-06-20</td>
                        <td>$420.00</td>
                        <td>CALL</td>
                        <td>$5.25</td>
                        <td>$7.80</td>
                        <td class="profit">+$2,550.00</td>
                        <td>28.5%</td>
                        <td>
                            <button class="btn">Exit</button>
                            <button class="btn btn-danger">Delete</button>
                        </td>
                    </tr>
                    <tr>
                        <td><input type="checkbox" class="options-leg-checkbox"></td>
                        <td><span class="action-sell">SELL</span></td>
                        <td>5</td>
                        <td>2025-05-30</td>
                        <td>2025-06-13</td>
                        <td>$430.00</td>
                        <td>PUT</td>
                        <td>$3.10</td>
                        <td>$1.85</td>
                        <td class="profit">+$625.00</td>
                        <td>22.1%</td>
                        <td>
                            <button class="btn">Exit</button>
                            <button class="btn btn-danger">Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Greeks Tab Content -->
        <div class="options-tab-content" id="options-greeks-tab">
            <table class="greeks-table">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="options-select-all-greeks"></th>
                        <th>Position</th>
                        <th>Strike/Type</th>
                        <th>IV</th>
                        <th>Delta</th>
                        <th>Gamma</th>
                        <th>Theta</th>
                        <th>Vega</th>
                        <th>Current Price</th>
                        <th>Days to Exp</th>
                    </tr>
                </thead>
                <tbody id="options-greeks-tbody">
                    <!-- Sample Greeks data -->
                    <tr>
                        <td><input type="checkbox" class="options-greek-checkbox"></td>
                        <td><span class="action-buy">BUY</span> 10 Lots</td>
                        <td>$420 CALL</td>
                        <td class="greek-value greek-positive">+0.6582</td>
                        <td class="greek-value greek-positive">+0.0145</td>
                        <td class="greek-value greek-negative">-0.0825</td>
                        <td class="greek-value greek-positive">+0.1250</td>
                        <td class="greek-value greek-positive">+0.0089</td>
                        <td>$7.80</td>
                        <td>19</td>
                    </tr>
                    <tr>
                        <td><input type="checkbox" class="options-greek-checkbox"></td>
                        <td><span class="action-sell">SELL</span> 5 Lots</td>
                        <td>$430 PUT</td>
                        <td class="greek-value greek-negative">-0.3215</td>
                        <td class="greek-value greek-positive">+0.0092</td>
                        <td class="greek-value greek-negative">-0.0512</td>
                        <td class="greek-value greek-positive">+0.0890</td>
                        <td class="greek-value greek-negative">-0.0034</td>
                        <td>$1.85</td>
                        <td>12</td>
                    </tr>
                </tbody>
            </table>
            
            <div style="margin-top: 20px; padding: 15px; background: #2a2a2a; border-radius: 8px;">
                <h3 style="margin-bottom: 10px; color: #fff;">Portfolio Greeks Summary</h3>
                <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 15px;">
                    <div>
                        <div style="font-size: 12px; color: #888; margin-bottom: 5px;">Net Delta</div>
                        <div class="greek-value greek-positive" style="font-size: 16px; font-weight: bold;" id='netDelta'>+4.95</div>
                    </div>
                    <div>
                        <div style="font-size: 12px; color: #888; margin-bottom: 5px;">Net Gamma</div>
                        <div class="greek-value greek-positive" style="font-size: 16px; font-weight: bold;" id='netGamma'>+0.19</div>
                    </div>
                    <div>
                        <div style="font-size: 12px; color: #888; margin-bottom: 5px;">Net Theta</div>
                        <div class="greek-value greek-negative" style="font-size: 16px; font-weight: bold;" id='netTheta'>-1.08</div>
                    </div>
                    <div>
                        <div style="font-size: 12px; color: #888; margin-bottom: 5px;">Net Vega</div>
                        <div class="greek-value greek-positive" style="font-size: 16px; font-weight: bold;" id='netVega'>+1.69</div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal -->
    <div class="modal-overlay" id="portfolioModal">
        <div class="modal" id='portfolioModalModal'>
            <div class="modal-header">
            <span>Portfolio Manager</span>
            <span class="close" onclick="closeModal()">&times;</span>
            </div>
            
            <div class="modal-body">
                <label style="color:white;">Save Strategy</label>
                <input type="text" placeholder="New strategy name" id='strategyName'>
                <input type="text" placeholder="Portfolio description"id='strategyDesc'>
                <select id='strategyType'>
                    <option>Paper Trades</option>
                    <option>Live Trades</option>
                </select>
            </div>
            
            <div class="modal-footer" >
            <button class="btn save"style='font-size:12px;' onclick="saveStrategy()"><i>💾</i> Save As New</button>
            <button class="btn save" style='font-size:12px;'onclick="saveStrategyOld()" style='display:none' id='SaveOld'><i>💾</i> Save As Old</button>
            <button class="btn cancel"style='font-size:12px;' onclick="closeModal()"><i>❌</i> Cancel</button>
            </div>
        </div>
    </div>

    
    <!-- Modal -->
    <div class="modal-overlay" id="loadStrategyModal">
    <div class="modal-large">
        <div class="modal-header">
        <span>All Strategies</span>
        <span class="close" onclick="closeStrategyModal()">&times;</span>
        </div>

        <!-- Strategy Table -->
        <table>
        <thead>
            <th>Name</th>
            <th>Strategy Category</th>
            <th>Strategy Description</th>
            <th></th>
            <th></th>
            </tr>
        </thead>
        <tbody id='Strategies'>
            <!-- Add more rows as needed -->
        </tbody>
        </table>
    </div>
</div>

        
    <input type="hidden" id="SpotPriceDataNew" value="0">
    <input type="hidden" id="indexLTP" value="0">
    <input type="hidden" id="strikePriceATM" value="0">
    <input type="hidden" id="GetNewSpotPrice" value="0">
    <input type="hidden" id="Id" value="">
    <input type="hidden" id="Get_Tokens" value="">
    <input type="hidden" id="FutureToken" value="">
    <input type="hidden" id="SpotToken" value="">
    <input type="hidden" id="Access_Token" value="">
    <input type="hidden" id="lot" value="75">
    <input type="hidden" id="multiplier" value="1">
    <input type="hidden" id="StrikePriceArray" value="">
    <input type="hidden" id="Idforstrike" value="">
    <input type="hidden" id="SymbType" value="NSE">
    <div id="editPositionModal" class="modal" style="display: none; position: fixed; z-index: 100; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.7);">
        <div class="modal-content" style="background-color: #2a2a2a; margin: 10% auto; padding: 20px; border-radius: 8px; width: 400px; box-shadow: 0 4px 8px rgba(0,0,0,0.2);">
            <span class="close-modal" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
            <h3 style="margin-bottom: 20px; color: white;">Edit Position</h3>
            <form id="editPositionForm">
                <input type="hidden" id="edit-row-index">
                <div style="margin-bottom: 15px;">
                    <label for="edit-action" style="display: block; margin-bottom: 5px; color: #ccc;">Action:</label>
                    <select id="edit-action" style="width: 100%; padding: 8px; background-color: #3a3a3a; color: white; border: 1px solid #4a4a4a; border-radius: 4px;">
                        <option value="Buy">Buy</option>
                        <option value="Sell">Sell</option>
                    </select>
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="edit-lots" style="display: block; margin-bottom: 5px; color: #ccc;">Lots:</label>
                    <input type="number" id="edit-lots" min="1" style="width: 100%; padding: 8px; background-color: #3a3a3a; color: white; border: 1px solid #4a4a4a; border-radius: 4px;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="edit-strike" style="display: block; margin-bottom: 5px; color: #ccc;">Strike:</label>
                    <input type="number" id="edit-strike" step="50" style="width: 100%; padding: 8px; background-color: #3a3a3a; color: white; border: 1px solid #4a4a4a; border-radius: 4px;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="edit-opt-type" style="display: block; margin-bottom: 5px; color: #ccc;">Option Type:</label>
                    <select id="edit-opt-type" style="width: 100%; padding: 8px; background-color: #3a3a3a; color: white; border: 1px solid #4a4a4a; border-radius: 4px;">
                        <option value="CE">CE</option>
                        <option value="PE">PE</option>
                    </select>
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="edit-entry-price" style="display: block; margin-bottom: 5px; color: #ccc;">Entry Price:</label>
                    <input type="number" id="edit-entry-price" step="0.05" style="width: 100%; padding: 8px; background-color: #3a3a3a; color: white; border: 1px solid #4a4a4a; border-radius: 4px;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="edit-iv" style="display: block; margin-bottom: 5px; color: #ccc;">IV:</label>
                    <input type="number" id="edit-iv" step="0.01" style="width: 100%; padding: 8px; background-color: #3a3a3a; color: white; border: 1px solid #4a4a4a; border-radius: 4px;">
                </div>
                <div style="text-align: right; margin-top: 20px;">
                    <button type="button" id="cancel-edit" style="background-color: #555; color: white; border: none; padding: 8px 15px; margin-right: 10px; border-radius: 4px; cursor: pointer;">Cancel</button>
                    <button type="submit" style="background-color: #007bff; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer;">Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    <!-- 1. Add a loading overlay to improve perceived performance -->
    <div id="loader" class="loading-overlay">
        <div class="spinner"></div>
        <div class="loading-text">Loading Options Trading Platform...</div>
    </div>

    <div id="columnSelectionModal" class="modal"style="display: none;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Select Columns to Display</h3>
                        <span class="close-modal">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div class="column-section">
                            <h4>Call Side</h4>
                            <div id="callColumnsContainer" class="columns-container">
                                <div class="column-option ">
                                    <input type="checkbox" id="call-ltp-check" checked="">
                                    <label for="call-ltp-check">LTP</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="call-volume-check">
                                    <label for="call-volume-check">Volume</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="call-oi-check">
                                    <label for="call-oi-check">OI</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="call-iv-check" checked="">
                                    <label for="call-iv-check">IV</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="call-delta-check" checked="">
                                    <label for="call-delta-check">Delta</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="call-theta-check">
                                    <label for="call-theta-check">Theta</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="call-gamma-check">
                                    <label for="call-gamma-check">Gamma</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="call-vega-check">
                                    <label for="call-vega-check">Vega</label>
                                </div>
                            </div>
                        </div>
                        <div class="column-section">
                            <h4>Strike</h4>
                            <div id="middleColumnsContainer" class="columns-container">
                                <div class="column-option disabled">
                                    <input type="checkbox" id="strike-check" checked="" disabled="">
                                    <label for="strike-check">Strike</label>
                                </div>
                            </div>
                        </div>
                        <div class="column-section">
                            <h4>Put Side</h4>
                            <div id="putColumnsContainer" class="columns-container">
                                <div class="column-option ">
                                    <input type="checkbox" id="put-ltp-check" checked="">
                                    <label for="put-ltp-check">LTP</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="put-volume-check">
                                    <label for="put-volume-check">Volume</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="put-oi-check">
                                    <label for="put-oi-check">OI</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="put-iv-check" checked="">
                                    <label for="put-iv-check">IV</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="put-delta-check" checked="">
                                    <label for="put-delta-check">Delta</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="put-theta-check">
                                    <label for="put-theta-check">Theta</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="put-gamma-check">
                                    <label for="put-gamma-check">Gamma</label>
                                </div>
                                <div class="column-option ">
                                    <input type="checkbox" id="put-vega-check">
                                    <label for="put-vega-check">Vega</label>
                                </div>
                            </div>
                        </div>
                        </div>
                    <div class="modal-footer">
                        <button id="saveColumnSettings" class="btn btn-primary">Save Changes</button>
                        <button id="cancelColumnSettings" class="btn">Cancel</button>
                        <button id="resetColumnSettings" class="btn">Reset to Default</button>
                    </div>
                </div>
            </div>
    <script src="https://black-scholes-js.netlify.app/js/blackscholes.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/protobufjs@7.X.X/dist/protobuf.min.js"></script>
    <?php
        $upstoxToken=fread(fopen('../DoNotTouch/upstox.txt','r'),filesize('../DoNotTouch/upstox.txt'));
        echo "<script>var accessToken = '".$upstoxToken."';</script>"
    ?>
    
    <script>
        setInterval(() => {
            $.get('/DoNotTouch/upstox.txt',(data)=>{
                var accessToken = data
            })
        }, 10000);
        </script>
        
    <!-- 3. Modify script loading strategy - Add this before the existing scripts -->
    <script>
        // Set up some globals before scripts load
        window.performance_metrics = {
            init_start: Date.now(),
            data_loaded: false,
            ui_ready: false
        };
        
        // Preload critical data
        const preloadData = {
            expiries: [
                "20MAR25(W)",
                "27MAR25(M)",
                "03APR25(W)",
                "09APR25(W)",
                "17APR25(W)"
            ]
        };
    </script>
    <script src='script.js'>


    </script>
    <script>
        $.get('../strategyBuilderWAutoPlay/StrategySVGData.json',(data)=>{
            // console.log()
            html=''
            
            for (const [key, value] of Object.entries(data)) {
                html+= `<div class="strategy-card ${value.type}" onclick="addPositionStrategy('${key}')" data-category="${value.type}">
                        <img src='../strategyBuilderWAutoPlay/svg/${value.svg}' height='90px'/>
                        <div class="strategy-name">${key.replaceAll('-',' ').replace(/\b\w/g, char => char.toUpperCase())}</div>
                    </div>`
            }
            $('#strategyGrid')[0].innerHTML=html
            filterStrategies('neutral')
        })


        
        function longIronCondor(offset=0,optType=''){
            const strike = $("#strikePriceATM").val();
            const strikeCE = parseFloat($("#strikePriceATM").val())+(4+offset)*window.strike_diff;
            const strikePE = parseFloat($("#strikePriceATM").val())-(4-offset)*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+(8+offset)*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-(8-offset)*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCE=window.OptionData[expiryDate].strikes.indexOf(strikeCE.toFixed(0)+'.0000')
            indexPE=window.OptionData[expiryDate].strikes.indexOf(strikePE.toFixed(0)+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            // console.log(strikeCEHedge)
            
            if(optType==''){
                callOption=window.OptionData[expiryDate].data[indexCE].call_options
                putOption=window.OptionData[expiryDate].data[indexPE].put_options

                
                callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            }else{

                if(optType=='CE'){
                    callOption=window.OptionData[expiryDate].data[indexCE].call_options
                    putOption=window.OptionData[expiryDate].data[indexPE].call_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].call_options

                }else{
                    callOption=window.OptionData[expiryDate].data[indexCE].put_options
                    putOption=window.OptionData[expiryDate].data[indexPE].put_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].put_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options

                }
            }
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCE,
                optType:optType==''?'CE':optType,
                entryPrice: callOption.market_data.ltp,
                currentPrice: callOption.market_data.ltp,
                IV: callOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
            addPosition({
                action:"Buy",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePE,
                optType:optType==''?'PE':optType,
                entryPrice: putOption.market_data.ltp,
                currentPrice: putOption.market_data.ltp,
                IV: putOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });

            
            addPosition({
                action:'Sell',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:optType==''?'CE':optType,
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
            addPosition({
                action:"Sell",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:optType==''?'PE':optType,
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }
        
        function shortIronCondor(offset=0,optType=''){
            const strike = $("#strikePriceATM").val();
            const strikeCE = parseFloat($("#strikePriceATM").val())+(4+offset)*window.strike_diff;
            const strikePE = parseFloat($("#strikePriceATM").val())-(4-offset)*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+(8+offset)*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-(8-offset)*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCE=window.OptionData[expiryDate].strikes.indexOf(strikeCE.toFixed(0)+'.0000')
            indexPE=window.OptionData[expiryDate].strikes.indexOf(strikePE.toFixed(0)+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            if(optType==''){
                callOption=window.OptionData[expiryDate].data[indexCE].call_options
                putOption=window.OptionData[expiryDate].data[indexPE].put_options

                
                callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            }else{

                if(optType=='CE'){
                    callOption=window.OptionData[expiryDate].data[indexCE].call_options
                    putOption=window.OptionData[expiryDate].data[indexPE].call_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].call_options

                }else{
                    callOption=window.OptionData[expiryDate].data[indexCE].put_options
                    putOption=window.OptionData[expiryDate].data[indexPE].put_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].put_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options

                }
            }
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            
            addPosition({
                action:'Sell',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCE,
                optType:optType==''?'CE':optType,
                entryPrice: callOption.market_data.ltp,
                currentPrice: callOption.market_data.ltp,
                IV: callOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
            addPosition({
                action:"Sell",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePE,
                optType:optType==''?'PE':optType,
                entryPrice: putOption.market_data.ltp,
                currentPrice: putOption.market_data.ltp,
                IV: putOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });

            
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:optType==''?'CE':optType,
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
            addPosition({
                action:"Buy",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:optType==''?'PE':optType,
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }

        
        function bearCallSpread(offset=0,optType=''){
            const strike = $("#strikePriceATM").val();
            const strikeCE = parseFloat($("#strikePriceATM").val())+(4+offset)*window.strike_diff;
            const strikePE = parseFloat($("#strikePriceATM").val())-(4-offset)*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+(8+offset)*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-(8-offset)*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCE=window.OptionData[expiryDate].strikes.indexOf(strikeCE.toFixed(0)+'.0000')
            indexPE=window.OptionData[expiryDate].strikes.indexOf(strikePE.toFixed(0)+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            if(optType==''){
                callOption=window.OptionData[expiryDate].data[indexCE].call_options
                putOption=window.OptionData[expiryDate].data[indexPE].put_options

                
                callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            }else{

                if(optType=='CE'){
                    callOption=window.OptionData[expiryDate].data[indexCE].call_options
                    putOption=window.OptionData[expiryDate].data[indexPE].call_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].call_options

                }else{
                    callOption=window.OptionData[expiryDate].data[indexCE].put_options
                    putOption=window.OptionData[expiryDate].data[indexPE].put_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].put_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options

                }
            }
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            
            addPosition({
                action:'Sell',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCE,
                optType:optType==''?'CE':optType,
                entryPrice: callOption.market_data.ltp,
                currentPrice: callOption.market_data.ltp,
                IV: callOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
            
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:optType==''?'CE':optType,
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
        }
        
        function bullCallSpread(offset=0,optType=''){
            const strike = $("#strikePriceATM").val();
            const strikeCE = parseFloat($("#strikePriceATM").val())+(4+offset)*window.strike_diff;
            const strikePE = parseFloat($("#strikePriceATM").val())-(4-offset)*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+(8+offset)*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-(8-offset)*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCE=window.OptionData[expiryDate].strikes.indexOf(strikeCE.toFixed(0)+'.0000')
            indexPE=window.OptionData[expiryDate].strikes.indexOf(strikePE.toFixed(0)+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            if(optType==''){
                callOption=window.OptionData[expiryDate].data[indexCE].call_options
                putOption=window.OptionData[expiryDate].data[indexPE].put_options

                
                callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            }else{

                if(optType=='CE'){
                    callOption=window.OptionData[expiryDate].data[indexCE].call_options
                    putOption=window.OptionData[expiryDate].data[indexPE].call_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].call_options

                }else{
                    callOption=window.OptionData[expiryDate].data[indexCE].put_options
                    putOption=window.OptionData[expiryDate].data[indexPE].put_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].put_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options

                }
            }
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCE,
                optType:optType==''?'CE':optType,
                entryPrice: callOption.market_data.ltp,
                currentPrice: callOption.market_data.ltp,
                IV: callOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
            
            addPosition({
                action:'Sell',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:optType==''?'CE':optType,
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
        }

        
        function bullPutSpread(offset=0,optType=''){
            const strike = $("#strikePriceATM").val();
            const strikeCE = parseFloat($("#strikePriceATM").val())+(4+offset)*window.strike_diff;
            const strikePE = parseFloat($("#strikePriceATM").val())-(4-offset)*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+(8+offset)*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-(8-offset)*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCE=window.OptionData[expiryDate].strikes.indexOf(strikeCE.toFixed(0)+'.0000')
            indexPE=window.OptionData[expiryDate].strikes.indexOf(strikePE.toFixed(0)+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            if(optType==''){
                callOption=window.OptionData[expiryDate].data[indexCE].call_options
                putOption=window.OptionData[expiryDate].data[indexPE].put_options

                
                callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            }else{

                if(optType=='CE'){
                    callOption=window.OptionData[expiryDate].data[indexCE].call_options
                    putOption=window.OptionData[expiryDate].data[indexPE].call_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].call_options

                }else{
                    callOption=window.OptionData[expiryDate].data[indexCE].put_options
                    putOption=window.OptionData[expiryDate].data[indexPE].put_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].put_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options

                }
            }
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            addPosition({
                action:"Sell",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePE,
                optType:optType==''?'PE':optType,
                entryPrice: putOption.market_data.ltp,
                currentPrice: putOption.market_data.ltp,
                IV: putOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });

            
            addPosition({
                action:"Buy",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:optType==''?'PE':optType,
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }
        function bearPutSpread(offset=0,optType=''){
            const strike = $("#strikePriceATM").val();
            const strikeCE = parseFloat($("#strikePriceATM").val())+(4+offset)*window.strike_diff;
            const strikePE = parseFloat($("#strikePriceATM").val())-(4-offset)*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+(8+offset)*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-(8-offset)*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCE=window.OptionData[expiryDate].strikes.indexOf(strikeCE.toFixed(0)+'.0000')
            indexPE=window.OptionData[expiryDate].strikes.indexOf(strikePE.toFixed(0)+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            if(optType==''){
                callOption=window.OptionData[expiryDate].data[indexCE].call_options
                putOption=window.OptionData[expiryDate].data[indexPE].put_options

                
                callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            }else{

                if(optType=='CE'){
                    callOption=window.OptionData[expiryDate].data[indexCE].call_options
                    putOption=window.OptionData[expiryDate].data[indexPE].call_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].call_options

                }else{
                    callOption=window.OptionData[expiryDate].data[indexCE].put_options
                    putOption=window.OptionData[expiryDate].data[indexPE].put_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].put_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options

                }
            }
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            addPosition({
                action:"Buy",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePE,
                optType:optType==''?'PE':optType,
                entryPrice: putOption.market_data.ltp,
                currentPrice: putOption.market_data.ltp,
                IV: putOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });

            
            addPosition({
                action:"Sell",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:optType==''?'PE':optType,
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }


        
        function batman(){
            const strike = $("#strikePriceATM").val();
            const strikeCE = parseFloat($("#strikePriceATM").val())+6*window.strike_diff;
            const strikePE = parseFloat($("#strikePriceATM").val())-6*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+5*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-5*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCE=window.OptionData[expiryDate].strikes.indexOf(strikeCE.toFixed(0)+'.0000')
            indexPE=window.OptionData[expiryDate].strikes.indexOf(strikePE.toFixed(0)+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            // console.log(strikeCEHedge)
            callOption=window.OptionData[expiryDate].data[indexCE].call_options
            putOption=window.OptionData[expiryDate].data[indexPE].put_options

            
            callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
            putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            
            addPosition({
                action:'Sell',
                lots: 2,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCE,
                optType:'CE',
                entryPrice: callOption.market_data.ltp,
                currentPrice: callOption.market_data.ltp,
                IV: callOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
            addPosition({
                action:"Sell",
                lots: 2,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePE,
                optType:'PE',
                entryPrice: putOption.market_data.ltp,
                currentPrice: putOption.market_data.ltp,
                IV: putOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });

            
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:'CE',
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
            addPosition({
                action:"Buy",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:'PE',
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }

                
        function ratioSpreadCall(){
            const strike = $("#strikePriceATM").val();
            const strikeCE = parseFloat($("#strikePriceATM").val())+4*window.strike_diff;
            const strikePE = parseFloat($("#strikePriceATM").val())-4*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val());
            const strikePEHedge = parseFloat($("#strikePriceATM").val());

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCE=window.OptionData[expiryDate].strikes.indexOf(strikeCE.toFixed(0)+'.0000')
            indexPE=window.OptionData[expiryDate].strikes.indexOf(strikePE.toFixed(0)+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            // console.log(strikeCEHedge)
            callOption=window.OptionData[expiryDate].data[indexCE].call_options
            putOption=window.OptionData[expiryDate].data[indexPE].put_options

            
            callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
            putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            
            addPosition({
                action:'Sell',
                lots: 2,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCE,
                optType:'CE',
                entryPrice: callOption.market_data.ltp,
                currentPrice: callOption.market_data.ltp,
                IV: callOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });

            
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:'CE',
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
        }
        
               
        function ratioSpreadPut(){
            const strike = $("#strikePriceATM").val();
            const strikeCE = parseFloat($("#strikePriceATM").val())+4*window.strike_diff;
            const strikePE = parseFloat($("#strikePriceATM").val())-4*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val());
            const strikePEHedge = parseFloat($("#strikePriceATM").val());

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCE=window.OptionData[expiryDate].strikes.indexOf(strikeCE.toFixed(0)+'.0000')
            indexPE=window.OptionData[expiryDate].strikes.indexOf(strikePE.toFixed(0)+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            // console.log(strikeCEHedge)
            callOption=window.OptionData[expiryDate].data[indexCE].call_options
            putOption=window.OptionData[expiryDate].data[indexPE].put_options

            
            callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
            putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            
            addPosition({
                action:"Sell",
                lots: 2,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePE,
                optType:'PE',
                entryPrice: putOption.market_data.ltp,
                currentPrice: putOption.market_data.ltp,
                IV: putOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });

            addPosition({
                action:"Buy",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:'PE',
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }

         
        function ratioBackSpreadCall(){
            const strike = $("#strikePriceATM").val();
            const strikeCE = parseFloat($("#strikePriceATM").val())+4*window.strike_diff;
            const strikePE = parseFloat($("#strikePriceATM").val())-4*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val());
            const strikePEHedge = parseFloat($("#strikePriceATM").val());

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCE=window.OptionData[expiryDate].strikes.indexOf(strikeCE.toFixed(0)+'.0000')
            indexPE=window.OptionData[expiryDate].strikes.indexOf(strikePE.toFixed(0)+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            // console.log(strikeCEHedge)
            callOption=window.OptionData[expiryDate].data[indexCE].call_options
            putOption=window.OptionData[expiryDate].data[indexPE].put_options

            
            callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
            putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            
            addPosition({
                action:'Buy',
                lots: 2,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCE,
                optType:'CE',
                entryPrice: callOption.market_data.ltp,
                currentPrice: callOption.market_data.ltp,
                IV: callOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });

            
            addPosition({
                action:'Sell',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:'CE',
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
        }
        
               
        function ratioBackSpreadPut(){
            const strike = $("#strikePriceATM").val();
            const strikeCE = parseFloat($("#strikePriceATM").val())+4*window.strike_diff;
            const strikePE = parseFloat($("#strikePriceATM").val())-4*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val());
            const strikePEHedge = parseFloat($("#strikePriceATM").val());

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCE=window.OptionData[expiryDate].strikes.indexOf(strikeCE.toFixed(0)+'.0000')
            indexPE=window.OptionData[expiryDate].strikes.indexOf(strikePE.toFixed(0)+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            // console.log(strikeCEHedge)
            callOption=window.OptionData[expiryDate].data[indexCE].call_options
            putOption=window.OptionData[expiryDate].data[indexPE].put_options

            
            callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
            putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            
            addPosition({
                action:"Buy",
                lots: 2,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePE,
                optType:'PE',
                entryPrice: putOption.market_data.ltp,
                currentPrice: putOption.market_data.ltp,
                IV: putOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });

            addPosition({
                action:"Sell",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:'PE',
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }
        function doublePlateu(){
            shortIronCondor(9,'CE')
            shortIronCondor(-9,'PE')
        }
        
        function longStrangle(){
            const strike = $("#strikePriceATM").val();
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+4*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-4*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            // console.log(strikeCEHedge)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options

            
            callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
            putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:'CE',
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
            addPosition({
                action:"Buy",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:'PE',
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }

        function shortStrangle(){
            const strike = $("#strikePriceATM").val();
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+4*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-4*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            // console.log(strikeCEHedge)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options

            
            callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
            putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            
            addPosition({
                action:'Sell',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:'CE',
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
            addPosition({
                action:"Sell",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:'PE',
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }

        
        
        function shortButterfly(offset=0,optType=''){
            const strike = parseFloat($("#strikePriceATM").val())+(offset)*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+(4+offset)*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-(4-offset)*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            // const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')



            
            if(optType==''){
                callOption=window.OptionData[expiryDate].data[index].call_options
                putOption=window.OptionData[expiryDate].data[index].put_options

                
                callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            }else{

                if(optType=='CE'){
                    callOption=window.OptionData[expiryDate].data[index].call_options
                    putOption=window.OptionData[expiryDate].data[index].call_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].call_options

                }else{
                    callOption=window.OptionData[expiryDate].data[index].put_options
                    putOption=window.OptionData[expiryDate].data[index].put_options

                    
                    callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].put_options
                    putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options

                }
            }
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action:'Sell',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:optType==''?'CE':optType,
                entryPrice: priceCE,
                currentPrice: priceCE,
                IV: ivCE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
            addPosition({
                action:"Sell",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:optType==''?'PE':optType,
                entryPrice: pricePE,
                currentPrice: pricePE,
                IV: ivPE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });


            
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:optType==''?'CE':optType,
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
            addPosition({
                action:"Buy",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:optType==''?'PE':optType,
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }



        
        function longButterfly(){
            const strike = $("#strikePriceATM").val();
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+4*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-4*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Buy';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            // console.log(strikeCEHedge)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options

            
            callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
            putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'CE',
                entryPrice: priceCE,
                currentPrice: priceCE,
                IV: ivCE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
            addPosition({
                action:"Buy",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'PE',
                entryPrice: pricePE,
                currentPrice: pricePE,
                IV: ivPE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });


            
            addPosition({
                action:'Sell',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:'CE',
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
            addPosition({
                action:"Sell",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:'PE',
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }

        function shortStraddle(){
            const strike = $("#strikePriceATM").val();

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            console.log(index)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action,
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'CE',
                entryPrice: priceCE,
                currentPrice: priceCE,
                IV: ivCE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
            addPosition({
                action,
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'PE',
                entryPrice: pricePE,
                currentPrice: pricePE,
                IV: ivPE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });
        }
        function longStraddle(){
            const strike = $("#strikePriceATM").val();

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Buy';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            console.log(index)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action,
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'CE',
                entryPrice: priceCE,
                currentPrice: priceCE,
                IV: ivCE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
            addPosition({
                action,
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'PE',
                entryPrice: pricePE,
                currentPrice: pricePE,
                IV: ivPE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });
        }
        function buyCall(){
            const strike = $("#strikePriceATM").val();

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Buy';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            console.log(index)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const price = optType === 'CE' 
                ? callOption.market_data.ltp 
                : putOption.market_data.ltp;
            
            // Get IV value
            const iv = optType === 'CE'
                ? callOption.option_greeks.iv 
                : putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action,
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType,
                entryPrice: price,
                currentPrice: price,
                IV: iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
        }
        function buyPut(){
            const strike = $("#strikePriceATM").val();

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'PE'; // 'CE' or 'PE'
            const action = 'Buy';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            console.log(index)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const price = optType === 'CE' 
                ? callOption.market_data.ltp 
                : putOption.market_data.ltp;
            
            // Get IV value
            const iv = optType === 'CE'
                ? callOption.option_greeks.iv 
                : putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action,
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType,
                entryPrice: price,
                currentPrice: price,
                IV: iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });
        }
        function sellCall(){
            const strike = $("#strikePriceATM").val();

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            console.log(index)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const price = optType === 'CE' 
                ? callOption.market_data.ltp 
                : putOption.market_data.ltp;
            
            // Get IV value
            const iv = optType === 'CE'
                ? callOption.option_greeks.iv 
                : putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action,
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType,
                entryPrice: price,
                currentPrice: price,
                IV: iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
        }
        function sellPut(){
            const strike = $("#strikePriceATM").val();

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'PE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            console.log(index)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const price = optType === 'CE' 
                ? callOption.market_data.ltp 
                : putOption.market_data.ltp;
            
            // Get IV value
            const iv = optType === 'CE'
                ? callOption.option_greeks.iv 
                : putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action,
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType,
                entryPrice: price,
                currentPrice: price,
                IV: iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });
        }

        
        function strap(){
            const strike = $("#strikePriceATM").val();

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Buy';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            console.log(index)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action,
                lots: 2,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'CE',
                entryPrice: priceCE,
                currentPrice: priceCE,
                IV: ivCE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
            addPosition({
                action,
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'PE',
                entryPrice: pricePE,
                currentPrice: pricePE,
                IV: ivPE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });
        }
        function strip(){
            const strike = $("#strikePriceATM").val();

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Buy';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            console.log(index)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action,
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'CE',
                entryPrice: priceCE,
                currentPrice: priceCE,
                IV: ivCE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
            addPosition({
                action,
                lots: 2,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'PE',
                entryPrice: pricePE,
                currentPrice: pricePE,
                IV: ivPE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });
        }

        
        function jadeLizard(){
            const strike = parseFloat($("#strikePriceATM").val())-5*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+15*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())+11*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Buy';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            // console.log(strikeCEHedge)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options

            
            callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
            putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].call_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action:"Sell",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'PE',
                entryPrice: pricePE,
                currentPrice: pricePE,
                IV: ivPE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });


            
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:'CE',
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
            addPosition({
                action:"Sell",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:'CE',
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }
        function reverseJadeLizard(){
            const strike = parseFloat($("#strikePriceATM").val())+5*window.strike_diff;
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())-15*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-11*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Buy';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            // console.log(strikeCEHedge)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].call_options

            
            callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].put_options
            putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action:"Sell",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'CE',
                entryPrice: pricePE,
                currentPrice: pricePE,
                IV: ivPE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });


            
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:'PE',
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
            addPosition({
                action:"Sell",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:'PE',
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }

        
        
        function sellSyntheticFuture(){
            const strike = $("#strikePriceATM").val();

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            console.log(index)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action:'Sell',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'CE',
                entryPrice: priceCE,
                currentPrice: priceCE,
                IV: ivCE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'PE',
                entryPrice: pricePE,
                currentPrice: pricePE,
                IV: ivPE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });
        }
        function buySyntheticFuture(){
            const strike = $("#strikePriceATM").val();

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Buy';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            console.log(index)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                
            // Get current date
            
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'CE',
                entryPrice: priceCE,
                currentPrice: priceCE,
                IV: ivCE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callOption['instrument_key']
            });
            addPosition({
                action:'Sell',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike,
                optType:'PE',
                entryPrice: pricePE,
                currentPrice: pricePE,
                IV: ivPE,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putOption['instrument_key']
            });
        }
        
        function rangeForward(){
            const strike = $("#strikePriceATM").val();
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+4*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-4*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            // console.log(strikeCEHedge)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options

            
            callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
            putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            
            addPosition({
                action:'Buy',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:'CE',
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
            addPosition({
                action:"Sell",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:'PE',
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }
        function riskForward(){
            const strike = $("#strikePriceATM").val();
            const strikeCEHedge = parseFloat($("#strikePriceATM").val())+4*window.strike_diff;
            const strikePEHedge = parseFloat($("#strikePriceATM").val())-4*window.strike_diff;

            const today = new Date();
            const currentDate = today.toISOString().split('T')[0];
            
            // Get expiry date from active tab
            const activeExpiry = $('.expiry-tab.active').text().trim();
            // //console.log(activeExpiry)
            const expiryDate = formatExpiryDate(activeExpiry);

            const optType = 'CE'; // 'CE' or 'PE'
            const action = 'Sell';
            
            index=window.OptionData[expiryDate].strikes.indexOf(strike+'.0000')
            indexCEHedge=window.OptionData[expiryDate].strikes.indexOf(strikeCEHedge.toFixed(0)+'.0000')
            indexPEHedge=window.OptionData[expiryDate].strikes.indexOf(strikePEHedge.toFixed(0)+'.0000')


            // console.log(strikeCEHedge)
            callOption=window.OptionData[expiryDate].data[index].call_options
            putOption=window.OptionData[expiryDate].data[index].put_options

            
            callHedgeOption=window.OptionData[expiryDate].data[indexCEHedge].call_options
            putHedgeOption=window.OptionData[expiryDate].data[indexPEHedge].put_options
            // console.log(callOption)
            // Get price from the correct cell
            const priceCE = callOption.market_data.ltp;
            const ivCE = callOption.option_greeks.iv;

            const pricePE = putOption.market_data.ltp;
            const ivPE = putOption.option_greeks.iv;
                

            
            addPosition({
                action:'Sell',
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikeCEHedge,
                optType:'CE',
                entryPrice: callHedgeOption.market_data.ltp,
                currentPrice: callHedgeOption.market_data.ltp,
                IV: callHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:callHedgeOption['instrument_key']
            });
            addPosition({
                action:"Buy",
                lots: 1,
                date: currentDate,
                expiry: expiryDate,
                strike:strikePEHedge,
                optType:'PE',
                entryPrice: putHedgeOption.market_data.ltp,
                currentPrice: putHedgeOption.market_data.ltp,
                IV: putHedgeOption.option_greeks.iv,
                lotSize: parseInt($('#lot').val() || 75),
                instrumentToken:putHedgeOption['instrument_key']
            });
        }
        

        function addPositionStrategy(strategy){
            if(strategy=='long-synthetic-fut'){
                buySyntheticFuture()
            }
            // console.log(strategy)
            if(strategy=='short-synthetic-future'){
                sellSyntheticFuture()
            }
            if(strategy=='range-forward'){
                rangeForward()
            }
            // console.log(strategy)
            if(strategy=='risk-reversal'){
                riskForward()
            }
            if(strategy=='buy-call'){
                buyCall()
            }
            if(strategy=='buy-put'){
                buyPut()
            }

            if(strategy=='buy-futures'){
                buyFuture()
            }
            if(strategy=='sell-futures'){
                sellFuture()
            }

            if(strategy=='sell-call'){
                sellCall()
            }
            if(strategy=='sell-put'){
                sellPut()
            }
            if(strategy=='short-straddle'){
                shortStraddle()
            }
            if(strategy=='long-straddle'){
                longStraddle()
            }
            
            if(strategy=='short-strangle'){
                shortStrangle()
            }
            if(strategy=='long-strangle'){
                longStrangle()
            }
            if(strategy=='iron-butterfly'){
                shortButterfly()
            }
            if(strategy=='long-iron-butterfly'){
                longButterfly()
            }
            if(strategy=='long-iron-condor'){
                longIronCondor()
            }
            if(strategy=='short-iron-condor'){
                shortIronCondor()
            }

            
            if(strategy=='batman'){
                batman()
            }
            
            if(strategy=='double-plateu'){
                doublePlateu()
            }
            
            if(strategy=='strap'){
                strap()
            }
            
            if(strategy=='strip'){
                strip()
            }

            if(strategy=='jade-lizard'){
                jadeLizard()
            }
            if(strategy=='reverse-jade-lizard'){
                reverseJadeLizard()
            }

            if(strategy=='call-ratio-spread'){
                ratioSpreadCall()
            }
            if(strategy=='put-ratio-spread'){
                ratioSpreadPut()
            }
            
            if(strategy=='call-ratio-back-spread'){
                ratioBackSpreadCall()
            }
            if(strategy=='put-ratio-back-spread'){
                ratioBackSpreadPut()
            }
            
            if(strategy=='bull-butterfly'){
                shortButterfly(5)
            }
            if(strategy=='bear-butterfly'){
                shortButterfly(-5)
            }
            
            if(strategy=='bull-condor'){
                shortIronCondor(5)
            }
            if(strategy=='bear-condor'){
                shortIronCondor(-5)
            }

            
        
        
        
        
            if(strategy=='bear-call-spread'){
                bearCallSpread(-4)
            }
            if(strategy=='bear-put-spread'){
                bearPutSpread(4)
            }
            
            if(strategy=='bull-call-spread'){
                bullCallSpread(-4)
            }
            if(strategy=='bull-put-spread'){
                bullPutSpread(4)
            }
            
            
        }
        
        // Toggle visibility based on positions
        function updateDisplay() {
            const emptyState = document.getElementById('emptyState');
            const chartPanel = document.getElementById('chartPanel');

            if (STATE.positions.length === 0) {
                emptyState.classList.remove('hidden');
                chartPanel.classList.remove('visible');
            } else {
                emptyState.classList.add('hidden');
                chartPanel.classList.add('visible');
            }
        }

        // Filter strategies by category
        function filterStrategies(category) {
            document.querySelectorAll('.btn-category').forEach(btn => {
                btn.classList.remove('active');
            });
            $('#'+category+'FilterBtn')[0].classList.add('active');

            const cards = document.querySelectorAll('.strategy-card');
            cards.forEach(card => {
                if (category === 'all') {
                    card.classList.remove('hidden');
                } else if (card.classList.contains(category)) {
                    card.classList.remove('hidden');
                } else {
                    card.classList.add('hidden');
                }
            });
            console.log('Filtered by:', category);
        }
    </script>
    
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const tabButtons = document.querySelectorAll(".options-tab-btn");
            const tabContents = document.querySelectorAll(".options-tab-content");

            tabButtons.forEach(button => {
                button.addEventListener("click", () => {
                    const targetTab = button.getAttribute("data-options-tab");

                    // Remove active class from all buttons and contents
                    tabButtons.forEach(btn => btn.classList.remove("active"));
                    tabContents.forEach(content => content.classList.remove("active"));

                    // Activate clicked tab button
                    button.classList.add("active");

                    // Activate corresponding tab content
                    const contentToShow = document.getElementById(`options-${targetTab}-tab`);
                    if (contentToShow) {
                        contentToShow.classList.add("active");
                    }
                });
            });
        });

        // Update prices every 5 seconds (uncomment to enable)
        // setInterval(simulatePriceUpdates, 5000);
    </script>
    </body>
    </html>