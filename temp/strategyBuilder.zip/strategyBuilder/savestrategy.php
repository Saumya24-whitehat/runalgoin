<?php
    session_start();
    $strategyFiles = './strategy/' . $_SESSION['user'] . '.txt';

    if (!file_exists($strategyFiles)) {
        // Create the file if it doesn't exist
        file_put_contents($strategyFiles, '[]');
    }

    $strategyData=json_decode(fread(fopen($strategyFiles,'r'),filesize($strategyFiles)),true);

    $strategyName=$_POST['strategyName'];
    $strategyDataNew=[];
    foreach ($strategyData as $value){
        if($value['strategyName']==$strategyName){
            echo 'Please use a different strategy name';
            die;
        }
    }
    $strategyDetails=[
        'strategyName'=> $_POST['strategyName'],
        'strategyDesc'=> $_POST['strategyDesc'],
        'strategyType'=> $_POST['strategyType'],
        'positions'=>$_POST['positions']
    ];

    $strategyData[]=$strategyDetails;
    fwrite(fopen($strategyFiles,'w'),json_encode($strategyData));

    echo "Done";

    

    // print_r($_POST);

?>